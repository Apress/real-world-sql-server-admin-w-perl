EXEC byroyalty 25
EXEC byroyalty 45
EXEC byroyalty 55
waitfor delay '00:00:02'
EXEC byroyalty 65
EXEC byroyalty 95
waitfor delay '00:00:02'

EXEC pubs.dbo.reptq3 2, 10, 'business'
EXEC [pubs].[dbo].[reptq3] 10, 20, 'business'

sp_help reptq3

DELETE titleauthor
FROM titleauthor INNER JOIN titles 
    ON titleauthor.title_id = titles.title_id
WHERE titles.title LIKE '%computers%'


SELECT pub_name, au_lname, title, SUM(qty) AS 'SUM'
FROM authors INNER JOIN titleauthor 
    ON authors.au_id = titleauthor.au_id INNER JOIN titles 
    ON titles.title_id = titleauthor.title_id INNER JOIN publishers 
    ON publishers.pub_id = titles.pub_id INNER JOIN sales 
    ON sales.title_id = titles.title_id
GROUP BY pub_name, au_lname, title
WITH ROLLUP

drop table junk
go
create table junk (i int, j int, k int, primary key(i,j))

drop trigger triJunk
go
create trigger triJunk
on junk
for insert
as
   insert junk_audit(i, j, ModifyType)
   select i, j, 'I'
     from inserted
go

drop trigger trdJunk
go
create trigger trdJunk
on junk
for delete
as
   insert junk_audit(i, j, ModifyType)
   select i, j, 'D'
     from deleted
go

drop trigger truJunk
go
create trigger truJunk
on junk
for update
as
   insert junk_audit(i, j, ModifyType)
   select i, j, 'U'
     from deleted
   union
   select i, j, 'U'
     from inserted
go

select * from junk
update junk
   set i = 1000, j = 200
 where  i = 1

delete junk
insert junk values(1,2, 3)
insert junk values(4,2, 3)

select * from junk_audit
drop table junk_audit
go
create table junk_audit ( mid int identity, i int, j int, 
   modifyType char(1) NOT NULL CHECK (modifyType in ('U', 'I', 'D')),
   modifyBy varchar(128) NOT NULL DEFAULT (suser_sname()),
   modifyDate datetime NOT NULL DEFAULT (getdate()))

sp_help parent_audit

drop table trash
go
create table trash (i int, j int)

# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use SQLDBA::Utility qw( dbaRunOsql dbaGetTableStruct_sp_help );

Main : {
   my %opts;
   getopts('S:d:t:', \%opts);
   my ($server, $dbName, $tbName) = ($opts{S}, $opts{d}, $opts{t});
   (defined $server && defined $dbName) or printUsage();

   my @tbNames = getTableNames($server, $dbName, $tbName);
   foreach my $tb (@tbNames) {
      generateAuditTrigger($server, $dbName, $tb);
   }
} # Main

sub getTableNames {
   my ($server, $dbName, $tbName) = @_;
   
   my @tbNames;
   if ( defined $tbName ) {
      @tbNames = ($tbName);
   }
   else {
      my $optRef = { '-E' => undef, '-n' => undef,
                     '-w' => '5000', '-d' => $dbName };
      my $tbList = dbaRunOsql($server, 
                              "set nocount on
                               select name 
                                 from $dbName\.dbo\.sysobjects 
                                where type=\'U\'",
                              $optRef);
      @tbNames = split /\n/, $tbList;
   }
   foreach my $tb (@tbNames) {
      $tb =~ s/^\s*//; $tb =~ s/\s*$//;
   }
   return @tbNames;
} # getTableNames

sub generateAuditTrigger {
   my ($server, $dbName, $tbName) = @_;

   my $optRef = { '-E' => undef, '-n' => undef,
                  '-w' => '5000', '-d' => $dbName };
   my $spHelp = dbaRunOsql($server, "sp_help \'$tbName\'", $optRef);
   my $tbRef = dbaGetTableStruct_sp_help($spHelp);
   unless ($tbRef) {
      print "\n***Err: dbaGetTableStruct_sp_help() failed to get ";
      print "structure info for table $tbName.\n";
      return;
   }
   my @columns = split /\s*,\s*/, 
                  $tbRef->{Constraints}->{PrimaryKey}->{Constraint};
   unless (@columns) {
      print "\n***Err: table $tbName doesn't have the primary key.\n";
      return;
   }
   my $pkColStr = shift @columns;
   foreach my $column (@columns) {
      $column =~ s/\s*//; $column =~ s/\s*$//; $pkColStr .= ", $column";
   }
   print scriptTriggerSQL($tbName, 'insert', $pkColStr);
   print scriptTriggerSQL($tbName, 'delete', $pkColStr);
   print scriptTriggerSQL($tbName, 'update', $pkColStr);
} # generateAuditTriggers

sub scriptTriggerSQL {
   my ($tbName, $type, $pkColStr) = @_;
   unless ($type =~ /^( insert | delete | update )$/ix) {
      die "***Err: the type paramter of function scriptTriggerSQL " .
            "expects one of insert, delete, and insert.\n";
      
   }
   
   my $sql;
   if (lc($type) eq 'insert') {
      $sql  =<<"__INSERT_TRIGGER__";
      CREATE TRIGGER tri_$tbName
      ON $tbName
      FOR INSERT
      AS
         INSERT ${tbName}_audit($pkColStr, ModifyType)
         SELECT $pkColStr, 'I'
           FROM inserted
      GO
__INSERT_TRIGGER__
   }
   elsif (lc($type) eq 'delete') {
      $sql  =<<"__DELETE_TRIGGER__";
      CREATE TRIGGER trd_$tbName
      ON $tbName
      FOR DELETE
      AS
         INSERT ${tbName}_audit($pkColStr, ModifyType)
         SELECT $pkColStr, 'D'
           FROM deleted
      GO
__DELETE_TRIGGER__
   }
   elsif (lc($type) eq 'update') {
      $sql  =<<"__UPDATE_TRIGGER__";
      CREATE TRIGGER tru_$tbName
      ON $tbName
      FOR UPDATE
      AS
         INSERT ${tbName}_audit($pkColStr, ModifyType)
         SELECT $pkColStr, 'U'
           FROM deleted
         UNION
         SELECT $pkColStr, 'U'
           FROM inserted
      GO
__UPDATE_TRIGGER__
   }
   $sql =~ s/(^|\n)\s{6}/$1/g;
   return $sql;
} # scriptTriggerSQL

sub printUsage {
    print << '--Usage--';
Usage:    
   cmd>perl GenerateAuditTriggers.pl  -S <SQL server or instance> 
                                      -d <database name>
                                      [ -t <table name> ]
--Usage--
exit;
} # printUsage


__END__

=head1 NAME

generateAuditTrigger - Generating audit triggers

=head1 SYNOPSIS

   cmd>perl GenerateAuditTriggers.pl  -S <SQL server or instance> 
                                      -d <database name>
                                      [ -t <table name> ]

=head1 DESCRIPTION

This script generates an INSERT, a DELETE, and an UPDATE triggers for a given table whose name
is specified with the -t option. If no table name is specified after the -t option, the
script generates these audit triggers for every user table in the database.

The main body of the script first gets the names of the tables for which the 
triggers will be generated. This could be a single table specified on the command 
line with the parameter -t, or it could be all the user tables in the database when 
the -t parameter isn't specified. 

Then, for each table, it calls the function I<generateAuditTrigger()> to perform the real 
task -- generating the SQL code for the INSERT trigger, the DELETE trigger, and the UPDATE trigger.

The crux of the task is to find the columns in the primary key of the user table. This script
uses the function I<dbaGetTableStruct_sp_help()> from the module SQLDBA::Utility to parse the 
output of I<sp_help>. Note that if the table has a primary key, the list of the columns in 
the primary key is recorded in the following hash where I<$tbRef> is the reference 
returned by the function I<dbaGetTableStruct_sp_help()>:

 $tbRef->{Constraints}->{PrimaryKey}->{Constraint}

With the primary key columns in hand, you're ready to generate the code for the audit 
triggers on the user table. You do this with the function I<scriptTriggerSQL()>, which takes 
the table name, the trigger type (in other words, DELETE, INSERT, or UPDATE), and the 
comma-separated list of the primary key columns. For each trigger type, a I<here document> 
is the template for the trigger code. 

For instance, the following is the here document for the insert trigger:

      $sql  =<<"__INSERT_TRIGGER__";
      CREATE TRIGGER tri_$tbName
      ON $tbName FOR INSERT
      AS
         INSERT ${tbName}_audit($pkColStr, ModifyType)
         SELECT $pkColStr, 'I' FROM inserted
      GO
 __INSERT_TRIGGER__


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

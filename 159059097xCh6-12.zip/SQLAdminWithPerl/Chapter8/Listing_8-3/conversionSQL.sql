USE pubs
GO
CREATE TABLE dbo.authors_new (
   id int NOT NULL IDENTITY (1, 1) ,
   au_id id NOT NULL,
   au_lname varchar ( 40 )  NOT NULL,
   au_fname varchar ( 30 )  NOT NULL,
   phone char ( 12 )  NOT NULL,
   address varchar ( 40 )  NULL,
   city varchar ( 20 )  NULL,
   state char ( 2 )  NULL,
   zip char ( 5 )  NULL,
)
GO
SET IDENTITY_INSERT dbo.authors_new ON
GO
IF EXISTS (SELECT * FROM dbo.authors)
    INSERT INTO dbo.authors_new (
	id,
	au_id,
	au_lname,
	au_fname,
	phone,
	address,
	city,
	state,
	zip
    )
    SELECT ?,
           au_id,
           au_lname,
           au_fname,
           phone,
           address,
           city,
           state,
           zip
      FROM dbo.authors
GO
SET IDENTITY_INSERT dbo.authors_new OFF
GO
DROP TABLE dbo.authors
GO

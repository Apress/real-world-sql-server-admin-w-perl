drop procedure generateAuditTable
go
create procedure generateAuditTable
    @tbName varchar(128)
as
  declare @cname varchar(128)
  declare col_cr cursor for
   select name from syscolumns
    where id = object_id(@tbName)
   order by colid
  open col_cr
  fetch col_cr into @cname
  while (@@fetch_status = 0)
  begin
      @cname
      fetch col_cr into @cname
  end
  close col_cr
  deallocate col_cr
go

EXEC generateAuditTable 'parent'

select c.*
  from information_schema.table_constraints tc join
       information_schema.constraint_column_usage ccu
    on tc.constraint_name = ccu.constraint_name join
       information_schema.columns c
    on ccu.table_name = c.table_name and
       ccu.column_name = c.column_name
 where constraint_type = 'PRIMARY KEY'
order by c.table_name, c.ordinal_position

select c.* 
  from INFORMATION_SCHEMA.KEY_COLUMN_USAGE k, 
       sysobjects o,
       INFORMATION_SCHEMA.COLUMNS c
 where o.name = k.CONSTRAINT_NAME
   and o.xtype = 'PK'
   and k.COLUMN_NAME = c.COLUMN_NAME
   and c.TABLE_NAME = k.table_name
order by c.table_name, c.ORDINAL_POSITION

select * from sysobjects
 where parent_obj = object_id('parent')



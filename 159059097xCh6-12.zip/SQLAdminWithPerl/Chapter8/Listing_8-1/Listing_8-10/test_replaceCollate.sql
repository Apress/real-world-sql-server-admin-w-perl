/** changed from collate SQL_Latin1_General_Cp850_CS_AS to collate SQL_Latin1_General_CP1_CI_AS */
CREATE TABLE [authors] (
	[au_id] [id] NOT NULL ,
	[au_lname] [varchar] (40) COLLATE Latin1_General_CI_AS NOT NULL ,
	[au_fname] [varchar] (20) COLLATE Latin1_General_CI_AS NOT NULL ,
	[phone] [char] (12) COLLATE Latin1_General_CI_AS NOT NULL CONSTRAINT [DF__authors__phone__78B3EFCA] DEFAULT ('UNKNOWN'),
	[address] [varchar] (40) COLLATE Latin1_General_CI_AS NULL ,
	[city] [varchar] (20) COLLATE Latin1_General_CI_AS NULL ,
	[state] [char] (2) COLLATE Latin1_General_CI_AS NULL ,
	[zip] [char] (5) COLLATE Latin1_General_CI_AS NULL ,
	[contract] [bit] NOT NULL ,
	CONSTRAINT [UPKCL_auidind] PRIMARY KEY  CLUSTERED 
	(
		[au_id]
	)  ON [PRIMARY] ,
	 CHECK ([au_id] like '[0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]'),
	 CHECK ([zip] like '[0-9][0-9][0-9][0-9][0-9]')
) ON [PRIMARY]
GO



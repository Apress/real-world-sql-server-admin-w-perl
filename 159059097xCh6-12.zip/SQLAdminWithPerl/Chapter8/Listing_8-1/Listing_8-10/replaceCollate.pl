# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use SQLDBA::ParseSQL qw( dbaNormalizeSQL dbaRestoreSQL );
my %opts;
getopts('s:o:n:', \%opts);
my ($sqlFile, $old, $new) = ($opts{s}, $opts{o}, $opts{n});
(defined $sqlFile && defined $old) or printUsage();

Main: {
   # read the T-SQL script into a variable first   
   my $sql;
   open(FL, $sqlFile) or die "***Err: could not open $sqlFile for read.";
   read(FL, $sql, -s FL);
   close(FL);
   
   # replace comments, strings, and delimited identifiers
   # with unique string tokens
   my $sqlRef = dbaNormalizeSQL($sql, 1);
 
   $new = "COLLATE $new" if $new =~ /\w+/;
   $sqlRef->{code} =~ s/\bCOLLATE\s+$old\b/$new/ig;
   
   # restore the original comments, strings, and delimited identifiers
   $sqlRef = dbaRestoreSQL($sqlRef);
   print $sqlRef->{code};
}  # Main

sub printUsage {
    print << '--Usage--';
Usage:    
   cmd>perl replaceCollate.pl  -s <script file> 
                               -o <old collate>
                               -n [<new colate> ]
--Usage--
exit;
} # printUsage


__END__

=head1 NAME

replaceCollate - Replacing one collation with another

=head1 SYNOPSIS

 cmd>perl replaceCollate.pl  -s <script file> 
                             -o <old collate>
                             -n [<new colate> ]

=head1 USAGE EXAMPLE

To change the collation I<Latin1_General_CI_AS> with the collation I<Latin1_General_BIN> in the 
T-SQL script file I<tradeRelease.SQL>, run the script as follows:

 cmd>perl replaceCollate.pl -s tradeRelease.SQL 
                            -o Latin1_General_CI_AS 
                            -n Latin1_General_BIN

=head1 DESCRIPTION

This script scans a T-SQL script file, and replace a given collation with another. It proceeds in four 
steps:

=over

=item *

The script reads the T-SQL script into the variable I<$sql>.

=item *

The script then calls the function I<dbaNormalizeSQL()> to replace comments, strings, and 
delimited identifiers with unique string tokens.

=item *

The script then performs a global search and replace with the following code segment:

  $new = "COLLATE $new" if $new =~ /\w+/;
  $sqlRef->{code} =~ s/\bCOLLATE\s+$old\b/$new/ig;

=item *

The script restores the original comments, strings, and delimited identifiers. This is 
done by calling the function I<dbaRestoreSQL()>.

=back

If you don't specify a collation name after the -n option, the script simply removes
the current collation.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

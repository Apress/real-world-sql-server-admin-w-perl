
USE master
GO
DECLARE @spid smallint, 
       @sql varchar(255)

DECLARE c_spid CURSOR FOR
 SELECT req_spid FROM master..syslockinfo 
  WHERE rsc_dbid = db_id('Orders')
 ORDER BY req_spid
 FOR READ ONLY

OPEN c_spid
FETCH c_spid INTO @spid
WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN
       SELECT @sql = 'KILL ' + CONVERT(varchar(3), @spid)
       EXECUTE(@sql)
   END
   FETCH c_spid INTO @spid
END
CLOSE c_spid
DEALLOCATE c_spid
GO
-- Drop the database if it already exists
IF db_id('Orders') IS NOT NULL
   DROP DATABASE Orders
GO
-- plug in the database creation here
CREATE DATABASE Orders
   ON PRIMARY
      ( NAME='Orders_dat1', 
        FILENAME='E:\mssql\data\Orders_dat1.mdf', 
        SIZE=100, FILEGROWTH=0),
      ( NAME='Orders_dat2', 
        FILENAME='E:\mssql\data\Orders_dat2.ndf', 
        SIZE=100, FILEGROWTH=0)
   LOG ON
      ( NAME = 'Orders_log1', 
        FILENAME = 'F:\mssql\data\Orders_log1.ldf', 
        SIZE = 50, FILEGROWTH=0),
      ( NAME = 'Orders_log2', 
        FILENAME = 'F:\mssql\data\Orders_log2.ldf', 
        SIZE = 50, FILEGROWTH=0)
GO
ALTER DATABASE Orders SET RECOVERY SIMPLE
GO


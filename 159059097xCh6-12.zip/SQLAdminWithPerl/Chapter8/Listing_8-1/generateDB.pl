# See the embedded POD or the HTML documentation

use strict;
use SQLDBA::Utility qw( dbaReadINI );  # import the function from the SQLDBA::Utility module

my $configFile = shift or
   die "***Err: generateDBCreate.pl expects a config file.\n";
Main: {
   my $configRef = dbaReadINI($configFile);
   # DB options are specified in the CONTROL section
   generateCreateDB($configRef->{CONTROL});
} # Main

##########################
sub generateCreateDB {
   my $cRef = shift or
      die "***Err: generateCreateDB() expects a reference.";

   # get the database and file names
   my $db = $cRef->{DB};
   my @dataFiles = split /\s*[,;]\s*/, $cRef->{DATAFILE};
   my @logFiles = split /\s*[,;]\s*/, $cRef->{LOGFILE};
   # get the file sizes
   my ($dataFileSize, $logFileSize) = 
                  ( int($cRef->{DATASIZE}/scalar(@dataFiles)),
                    int($cRef->{LOGSIZE}/scalar(@logFiles)));

   my $createDB = "CREATE DATABASE $db\n   ON PRIMARY";
   my $i = 0;
   foreach my $dataFile (@dataFiles) {
      $createDB .= ( (++$i-1) ? ',' : ' ' ) . "
            ( NAME=\'$db\_dat$i\', 
              FILENAME=\'$dataFile\', 
              SIZE=$dataFileSize, FILEGROWTH=0)";
   }
   $createDB .= "\n   LOG ON"; 
   $i = 0;
   foreach my $logFile (@logFiles) {
      $createDB .= ( (++$i-1) ? ',' : ' ' ) . "
            ( NAME = \'$db\_log$i\', 
              FILENAME = \'$logFile\', 
              SIZE = $logFileSize, FILEGROWTH=0)";
   }
   my $sql = useCreateDBTemplate($db, $createDB);
   print $sql, "\n";
} # generateCreateDB

#############################
sub useCreateDBTemplate {
   my ($db, $createDB) = @_;
   
   my $sql = <<"__CREATEDB_TEMPLATE";
      USE master
      GO
      DECLARE \@spid smallint, \@sql varchar(255)

      DECLARE c_spid CURSOR FOR
       SELECT req_spid FROM master..syslockinfo 
        WHERE rsc_dbid = db_id(\'$db\')
       ORDER BY req_spid
       FOR READ ONLY

      OPEN c_spid
      FETCH c_spid INTO \@spid
      WHILE (\@\@FETCH_STATUS <> -1)
      BEGIN
         IF (\@\@FETCH_STATUS <> -2)
         BEGIN
             SELECT \@sql = 'KILL ' + CONVERT(varchar(3), \@spid)
             EXECUTE(\@sql)
         END
         FETCH c_spid INTO \@spid
      END
      CLOSE c_spid
      DEALLOCATE c_spid
      GO
      -- Drop the database if it already exists
      IF db_id(\'$db\') IS NOT NULL
         DROP DATABASE $db
      GO
      -- plug in the database creation here
      $createDB
      GO
      ALTER DATABASE $db SET RECOVERY SIMPLE
      GO
__CREATEDB_TEMPLATE
   $sql =~ s/(^|\n)      /\n/g;  # remove the indented spaces in $sql
   return $sql;
} # useCreateDBTemplate


__END__

=head1 NAME

generateDB - Generating T-SQL code to create databases

=head1 SYNOPSIS

   cmd>perl generateDB.pl <config file> 

=head1 USAGE EXAMPLE

Assume that you have specify the following options in a configuration file, I<config.txt>:

 [Control]
 Server=SQL01\APOLLO
 DB=Orders
 DataFile=E:\mssql\data\Orders_dat1.mdf,E:\mssql\data\Orders_dat2.ndf 
 LogFile=F:\mssql\data\Orders_log1.ldf,F:\mssql\data\Orders_log2.ldf
 DataSize=200  # in MB
 LogSize=100   # in MB

In this configuration file, the name of the database is Orders specified with the option I<DB>. 
The data files including their complete paths are listed in a comma-separated format 
for the option I<DataFile>, and the transaction log files are specified with the option 
I<LogFile> in a similar fashion. The size of the database is 200MB for data and 100MB for log. 

Save the configuration options in I<config.txt>, and then run the Perl script I<generateDB.pl> 
with this configuration file to produce the T-SQL code shown below:

 cmd>perl generateDB.pl config.txt
 USE master
 GO
 DECLARE @spid smallint, 
        @sql varchar(255)
 
 DECLARE c_spid CURSOR FOR
  SELECT req_spid FROM master..syslockinfo 
   WHERE rsc_dbid = db_id('Orders')
  ORDER BY req_spid
  FOR READ ONLY
 
 OPEN c_spid
 FETCH c_spid INTO @spid
 WHILE (@@FETCH_STATUS <> -1)
 BEGIN
    IF (@@FETCH_STATUS <> -2)
    BEGIN
        SELECT @sql = 'KILL ' + CONVERT(varchar(3), @spid)
        EXECUTE(@sql)
    END
    FETCH c_spid INTO @spid
 END
 CLOSE c_spid
 DEALLOCATE c_spid
 GO
 -- Drop the database if it already exists
 IF db_id('Orders') IS NOT NULL
    DROP DATABASE Orders
 GO
 -- plug in the database creation here
 CREATE DATABASE Orders
    ON PRIMARY
       ( NAME='Orders_dat1', 
         FILENAME='E:\mssql\data\Orders_dat1.mdf', 
         SIZE=100, FILEGROWTH=0),
       ( NAME='Orders_dat2', 
         FILENAME='E:\mssql\data\Orders_dat2.ndf', 
         SIZE=100, FILEGROWTH=0)
    LOG ON
       ( NAME = 'Orders_log1', 
         FILENAME = 'F:\mssql\data\Orders_log1.ldf', 
         SIZE = 50, FILEGROWTH=0),
       ( NAME = 'Orders_log2', 
         FILENAME = 'F:\mssql\data\Orders_log2.ldf', 
         SIZE = 50, FILEGROWTH=0)
 GO
 ALTER DATABASE Orders SET RECOVERY SIMPLE
 GO


=head1 DESCRIPTION

The script I<generateDB.pl> reads the database name, the complete data file paths, and the complete 
log file paths from a configuration file. The script then constructs a CREATE DATABASE statement 
and plugs it into a SQL template that includes additional code for preparation and cleanup.

The bulk of the code is in the function I<generateCreateDB()>, which generates the SQL Server 
CREATE DATABASE statement using the information read from the options in the configuration file. 
The complete CREATE DATABASE statement is stored as a string in the I<$createDB> variable. 
Toward the end of the function, it calls another function, I<useCreateDBTemplate()>, and passes it 
the database name in I<$db> and the CREATE DATABASE statement in I<$createDB>. 

The function I<useCreateDBTemplate()> contains a template -- in a I<here document> -- for creating a 
database. The here document is introduced with a pair of double quotation marks, and therefore 
it'll interpolate its embedded variables, $db and $createDB. These variables serve as placeholders 
for the template. Note that in the here document, every T-SQL local variable is escaped with a 
backslash; otherwise, the T-SQL local variable -- prefixed with the @ character -- will be treated 
by Perl as an array variable and the variable interpolation will kick in, which isn't the behavior 
you want to see.

The function I<generateCreateDB()> is also like a template because it freely mixes Perl code with 
blocks of strings that represent SQL statement fragments. The function uses Perl code to control 
the repeating elements -- data file and log file specifications -- and relies on Perl's handy variable 
interpolation to handle the changing database and filenames. For instance, the data file specifications 
are controlled by this loop in the function:

 my $i = 0;
 foreach my $dataFile (@dataFiles) {
    $createDB .= ( (++$i-1) ? ',' : ' ' ) . "
          ( NAME=\'$db\_dat$i\', 
            FILENAME=\'$dataFile\', 
            SIZE=$dataSize, 
            FILEGROWTH=0)";  # you may set it to a different value
 }


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


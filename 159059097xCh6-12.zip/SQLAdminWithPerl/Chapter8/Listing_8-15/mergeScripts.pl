use strict;

my $dir = shift or die "***Err: $0 expects a folder name.\n";
(-d $dir) or die "***Err: Folder $dir does not exist.\n";

my $time = localtime();

# read the file names in the directory
my @fileNames = glob("$dir\\*.*");

# read each line from the each of the files and writes
# the line to the merged file
foreach my $sqlFile (sort @fileNames) {
   open(SQL, "$sqlFile") or die "***Err: couldn't open $sqlFile.\n";

   # add the header first
   print "/**** Script from file $sqlFile on $time ****/\n";
   # write the rest of the lines unchanged
   print while(<SQL>);
   close(SQL);
   print "\n\n";
}

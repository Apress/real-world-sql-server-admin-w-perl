# See the embedded POD or the HTML documentation

use strict;

# import functions from the SQLDBA::ParseSQL module
use SQLDBA::ParseSQL qw( dbaNormalizeSQL dbaRestoreSQL $TSQLReservedWords );

my $sqlFile = shift or die "***Err: $0 expects a SQL script.";

Main: {
   # read the T-SQL script into a variable first
   my $sql;
   open(FL, $sqlFile) or die "***Err: could not open $sqlFile for read.";
   read(FL, $sql, -s FL);
   close(FL);
    
   # replace comments, strings, and delimited identifiers
   # with unique string tokens
   my $sqlRef = dbaNormalizeSQL($sql, 1);
   
   # Convert the T-SQL reserved words into uppercase
   $sqlRef = upperCaseReserved($sqlRef);
   
   # Restore the T-SQL comments, delimited identifiers, and quoted strings to their originals
   $sqlRef = dbaRestoreSQL($sqlRef);
   print $sqlRef->{code};
} # Main

########################
sub upperCaseReserved {
   my ($sqlRef) = shift or
      die "***Err: upperCaseReserved() expects a reference.";
   
   # replace any reserved word with its upper case
   $sqlRef->{code} =~ s/($TSQLReservedWords)/uc($1)/eg;
   return $sqlRef;
} # upperCaseReserved


__END__

=head1 NAME

UpperCaseReserved - Capitalizing the T-SQL reserved words

=head1 SYNOPSIS

   cmd>perl UpperCaseReserved.pl <SQL script file>

=head1 DESCRIPTION

This script scans a T-SQL script file and converts all the T-SQL reserved words used in that script into
uppercase.

The complicating factors are T-SQL comments, delimited identifiers, and quoted strings. They all 
can have embedded words that look like the T-SQL reserved words, but are not.

This script applies the "replace-match-restore" strategy introduced in 
the section "Implementing the Replace-Match-Restore Strategy" in Chapter 3. 
The script proceeds as follows:

=over

=item *

The script I<UpperCaseReserved.pl> first reads the T-SQL script into a Perl variable I<$sql>.

=item *

It calls the function I<dbaNormalizeSQL()> to replace comments, quoted strings, and delimited 
identifiers with unique string tokens.

=item *

The script then calls the function I<upperCaseReserved()> to convert the T-SQL reserved words 
into uppercase. The function I<upperCaseReserved()> is defined in the script.

=item *

Finally, the script calls the function I<dbaRestoreSQL()> to restore the T-SQL comments, delimited 
identifiers, and quoted strings to their originals.

=back


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


# See the embedded POD or the HTML documentation

use strict;

my ($infile, $outfile) = @ARGV;
die "***Err: need an input file $infile." unless (-e $infile); 

# the name can be a simple identifier and a delimited identifier
my $name = q/(?:  
               [\w@#]+  |                    # regular identifer
               \" (?: [^"] | \"\" )+ \"  |  # double-quoted id
               \[ (?: [^]] | \]\] )+ \]      # bracket-quoted id
            )/;
# the proc name may be prefixed with owner
my $re = qr{ (?: $name          # one-part name with no owner
               | $name\.$name ) # two-part name with owner
           }ix;

my $spName;   
unless (open(OUT, ">$outfile")) {
   warn "***Msg: couldn't open $outfile for write." if $outfile;
   open(OUT, ">&STDOUT");
}   
open(IN, "<$infile") or die "***Err: could not open $infile for read.";
while(<IN>) {
   if (/^\s*create\s+proc(edure)?\s+(.*)$/i) {
      my $proc = $2;
      my $sql = $_;
      if ($proc =~ /^($re)(\s+.*)?$/) { $spName = $1; }
      else {
         while (<IN>) {
            $sql .= $_;
            if (/^\s*($re)(\s+.*)?$/) { $spName = $1; last; }
         }
      }
      if ($spName =~ /$re/) { # by now $spName should have the proc name
         $sql = getSPDrop($spName) . $sql; # add a DROP PROC clause
      }
      else { die "***Err: failed to grab the proc name."; }
      print OUT $sql;
   } else { print OUT; } # just pass it along
} # while
close(IN); close(OUT);

###################
sub getSPDrop {
   my $sp = shift or die "***Err: getSPDrop() expects a proc name.";
   
   my $sql = "if exists (select * from dbo.sysobjects where id = ";
   $sql .= "object_id(N'" . $sp . "') and OBJECTPROPERTY(id, ";
   $sql .= "N'IsProcedure') = 1)\n    drop procedure $sp\nGO\n\n";
   return $sql;
} # getSPDrop


__END__

=head1 NAME

addDrops - Adding a DROP PROC before each CREATE PROC

=head1 SYNOPSIS

   cmd>perl addDrops.pl <in SQL file> <out SQL file>

=head1 DESCRIPTION

This script scans a T-SQL script for CREATE PROC or CREATE PROCEDURE statements, and for each found, it 
inserts a DROP PROC immediately before the CREATE PROC(EDURE) statement. This is all very straightforward.

However, there is a minor complication, which is that the procedure name can come in a variety 
of patterns. But pattern matching is what Perl is good at doing. 

There are three possibilities for a procedure name or an owner name: 

=over

=item A regular identifier: 

This will be matched with the pattern [\w\$@#]+. Note that 
this pattern actually matches more than what�s allowed for a T-SQL regular identifier. 
But given the context, it's safe to be less precise.

=item An identifier delimited with double quotation marks: 

The pattern to match is \" (?: [^"] | \"\" )+ \" .

=item An identifier delimited with square brackets: 

The pattern to match is \[ (?: [^]] | \]\] )+ \].

=back

In the script I<addDrops.pl>, the regular expression for parsing the name of a stored procedure 
is defined and compiled:

 # define and compile a regular expression to parse the proc name
 # the name can be a simple identifier and a delimited identifier
 my $name = q/(?:  
                   [\w\$@#]+                 #  regular identifer
                |  \" (?: [^"] | \"\" )+ \"  #  double-quoted id
                |  \[ (?: [^]] | \]\] )+ \]  #  bracket-quoted id
             )/;
 # the proc name may be prefixed with owner
 my $re = qr{  (?:   $name          # one-part name w no owner
                   | $name\.$name   # two-part name w owner
               )
            }ix;
 
The script searches the SQL script for each CREATE PROCEDURE statement and uses the 
compiled regular expression I<$re> to capture the name of the procedure in the 
variable I<$spName>. When it finds a CREATE PROCEDURE statement, it passes the procedure 
name to the function I<getSPDrop()>, which returns a DROP PROCEDURE batch with the 
correct procedure name. The Perl script then writes this batch to the output before 
it writes the corresponding CREATE PROCEDURE statement. Any other line in the SQL script is 
passed to the output as is.

It's important to note that the script produces correct T-SQL scripts in most cases and is 
sufficiently useful. But it isn't 100-percent robust. The script has two obvious flaws. 

The first flaw lies in the assumption that there are only whitespaces between CREATE and 
PROCEDURE, or between PROCEDURE and the name of the procedure. The syntax of T-SQL allows 
delimited T-SQL comments wherever whitespace is permitted. For instance, the following T-SQL 
statement would confuse the script:

 CREATE PROC/* valid comments */dbo.spGetNextID

The second flaw is that not every CREATE PROC string is a real CREATE PROCEDURE statement; 
it could be inside a comment, a quoted string, or even a delimited identifier. 


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut



create procedure "select"."strang_procedure"
as
set nocount on

EXEC [master db]..sp_who 'my login'		-- EXEC [not really proc execution]

select * from [abo]."more weird table" where [123name] = 'ndafd  dnafldsj "kls daf [klsadfj]fdsa'

EXECUTE junkSP /*** embedded comments ***/ 'param one', 'param 2'

EXEC @rc = "another Junk SP" 'abc xyz'     -- "djaf ads "  klsdaf fads 'abcdefg'

EXEC (N'master..sp_lock')

declare @sql varchar(255), @db sysname, @rc int
set @sql = 'master.dbo.sp_helpdb'
set @db = 'pubs'
EXEC @rc = @sql @db
go





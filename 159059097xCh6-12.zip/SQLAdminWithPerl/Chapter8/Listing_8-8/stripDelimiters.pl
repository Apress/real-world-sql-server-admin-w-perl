# See the embedded POD or the HTML documentation

use strict;
use SQLDBA::ParseSQL qw( dbaNormalizeSQL dbaRestoreSQL 
                         $TSQLReservedWords );
my $sqlFile = shift or die "***Err: $0 expects the name of a SQL script.";

Main: {
   # read the T-SQL script into a variable first   
   my $sql;
   open(FL, $sqlFile) or die "***Err: could not open $sqlFile for read.";
   read(FL, $sql, -s FL);
   close(FL);
   
   # replace comments, strings, and delimited identifiers
   # with unique string tokens
   my $sqlRef = dbaNormalizeSQL($sql, 1);
   $sqlRef = removeDelimiters($sqlRef);
   $sqlRef = dbaRestoreSQL($sqlRef);
   print $sqlRef->{code};
}  # Main

##########################
sub removeDelimiters {
   my $sqlRef = shift or
      die "***Err: removeDelimiters() expects a reference.";

   # remove double quotes    
   foreach my $id (keys %{$sqlRef->{double_ids}}) {
      if ($sqlRef->{double_ids}->{$id} =~ /^[a-zA-Z\@\#\_]
                                            [\w\@\#\$\.]*$/ix) {
         if ($sqlRef->{double_ids}->{$id} !~ /$TSQLReservedWords/i) {
            $sqlRef->{code} =~ s/$id/$sqlRef->{double_ids}->{$id}/;
         }
      }
   }
   # remove square brackets
   foreach my $id (keys %{$sqlRef->{bracket_ids}}) {
      if ($sqlRef->{bracket_ids}->{$id} =~ /^[a-zA-Z\@\#\_]
                                            [\w\@\#\$\.]*$/ix) {
         if ($sqlRef->{bracket_ids}->{$id} !~ /$TSQLReservedWords/i) {
            $sqlRef->{code} =~ s/$id/$sqlRef->{bracket_ids}->{$id}/;
         }
      }
   }
   return $sqlRef; 
} # removeDelimiters


__END__

=head1 NAME

stripDelimiters - Stripping off T-SQL identifier delimiters

=head1 SYNOPSIS

   cmd>perl stripDelimiters.pl <SQL script file>

=head1 DESCRIPTION

The script I<stripDelimiters.pl> applies the "replace-match-restore" strategy introduced in 
the section "Implementing the Replace-Match-Restore Strategy" in Chapter 3. The script proceeds as follows:

=over

=item 1.

It calls the function I<dbaNormalizeSQL()> to identify the comments, the quoted strings, and the delimited 
identifiers and then replace them with their respective unique token strings.

=item 2.

It evaluates each delimited identifier to see whether it conforms to the T-SQL regular identifier 
naming rules, convert it to a regular identifier if it does, and replace its token string in 
the script with the regular identifier.

=item 3.

It restores the other unique tokens to their originals.

=back

More specifically, after I<stripDelimiter.pl> reads the T-SQL script into the variable I<$sql>, 
it makes three function calls. The script first calls the function I<dbaNormalizeSQL()>, 
imported from SQLDBA::ParseSQL, to replace comments, quoted strings, and delimited identifiers 
with unique token strings. 

Then, the function I<removeDelimiters()>, defined in the script, 
examines each delimited identifier to find those whose delimiters can be removed without 
altering the semantics of the SQL script and removes these delimiters from I<$sqlRef->{code}>. 
Note that the function removes both double quotes and square brackets. 

Finally, the function I<dbaRestoreSQL()> is called to put the original comments, quoted strings, 
and identifiers back in I<$sqlRef->{code}>.

To be able to safely strip off a pair of T-SQL identifier delimiters, the script must ensure 
that the identifier minus the delimiters conforms to the rules of T-SQL regular identifiers 
(in other words, identifiers that are not delimited with either double quotation marks or square 
brackets). The script follows the rules for the format of the regular identifier on SQL Server 2000. 
These rules are documented in the SQL Server 2000 Books Online in the "Rules for Regular Identifiers" 
section:

=over

=item *

The first character must be a letter, an underscore (_), the at (@) sign, or the number sign (#).

=item *

Subsequent characters can be letters, decimal numbers, the at (@) sign, the underscore (_), 
the number sign (#), or the dollar sign ($).

=item *

The identifier must not be a T-SQL reserved word.

=item *

Embedded spaces or special characters aren�t allowed.

=back

The function I<removeDelimiters()> checks each identifier, either delimited by square brackets or by 
double quotation marks, against these rules and strips the delimiters off those conforming to the rules. 
Of particular interest is the variable I<$TSQLReservedWords> in the script. This variable is imported 
by request from the module SQLDBA::ParseSQL and is a reference to a compiled regular expression that 
matches any of the SQL Server reserved words. (The SQL Server 2000 Books Online documents the r
eserved words.)

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


create procedure [dbo]."strang_procedure"
as
/* created by: Linchi Shea */
EXEC @rc = "another Junk SP" 'abc xyz'  
-- EXEC another_proce

EXEC "Create"    -- Create is a reserved word
EXEC "Create1"   -- Create1 is not a reserved word
go
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE byroyalty @percentage int
AS
select au_id from titleauthor
where titleauthor.royaltyper = @percentage


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create procedure generateAuditTable
    @tbName varchar(128)
as
  declare @cname varchar(128)
  declare col_cr cursor for
   select name from syscolumns
    where id = object_id(@tbName)
   order by colid
  open col_cr
  fetch col_cr into @cname
  while (@@fetch_status = 0)
  begin
      print @cname
      fetch col_cr into @cname
  end
  close col_cr
  deallocate col_cr

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create proc getAuid
as
   set nocount on
   select au_id from authors

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE reptq1 AS
select pub_id, title_id, price, pubdate
from titles
where price is NOT NULL
order by pub_id
COMPUTE avg(price) BY pub_id
COMPUTE avg(price)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE reptq2 AS
select type, pub_id, titles.title_id, au_ord,
   Name = substring (au_lname, 1,15), ytd_sales
from titles, authors, titleauthor
where titles.title_id = titleauthor.title_id AND authors.au_id = titleauthor.au_id
   AND pub_id is NOT NULL
order by pub_id, type
COMPUTE avg(ytd_sales) BY pub_id, type
COMPUTE avg(ytd_sales) BY pub_id


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE reptq3 @lolimit money, @hilimit money,
@type char(12)
AS
select pub_id, type, title_id, price
from titles
where price >@lolimit AND price <@hilimit AND type = @type OR type LIKE '%cook%'
order by pub_id, type
COMPUTE count(title_id) BY pub_id, type


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create proc sp_dba_sysmon
    @server     varchar(120),
    @begin_time datetime = NULL,
    @end_time   datetime = NULL,
    @detail     varchar(10) = 'FALSE'
as

/*
    This procedure displays the NY/Win2K performance counter values stored in the database 
    tables. It assumes that the performance counter values have been collected from a server 
    and stored in a table named tb_<server name>_sysperf. Given the server name, the procedure
    queries this table to either display the performance counter values for a single given 
    instance of time if only one time parameter is specified or there is only one sample for 
    the given time period. 

    If there are multiple samples with the time period, the procedure displays the statistics
    (i.e. average, minimum value, maximum value, count, and standard deviation) for all the 
    performance counter values collected during that period of time. If parameter @detail
    is set to 'true', the specific performance counter values from each sample are displayed
    under the column heading labelled with the corresponding date time strings. If the @detail
    is not specified, only the statistics are displayed.

    The procedure restricts the number of samples within the specified time period to at most
    100. It also limits the time period to be less than 10 hours. These are practical 
    restrictions and make sense for all the intents and purposes of this procedure.

    The results of this procedure are primarily intended for human visual consumption, not 
    intended to be fed into a graph program.

    Although this procedure will not give real-time performance data for a given server, its 
    results can be near real time if the performance counter values are fed directly to the
    database table on a regular ongoing basis.

    When           Who                What
    2001/12/27     Linchi Shea        Initial version
    2001/12/30     Linchi Shea        Now allow display counter values across time                 
*/
   set nocount on

   -- validate input parameters

   if (@begin_time is NULL and @end_time is NOT NULL) 
   begin
        raiserror('Err: @begin_time cannot be NULL if @end_time is not NULL.', 16, -1)
        return (1)
   end

   if (@begin_time is not NULL and @end_time is NOT NULL and @begin_time > @end_time) 
   begin
        raiserror('Err: @begin_time must be smaller than @end_time.', 16, -1)
        return (1)
   end

   if upper(@detail) not in ('TRUE', 'FALSE')
   begin
        raiserror('Err: @detail can be either TRUE or FALSE.', 16, -1)
        return (1)
   end

   -- Restrict the interval to less than 10 hours. It doesn't make much sense to calculate average 
   -- over a very large interval, and this wouldn't be a good tool if one really wants to look at 
   -- the number over a large interval.

   if (@begin_time is not NULL and @end_time is NOT NULL and datediff(hour, @begin_time, @end_time) >= 10) 
   begin
        raiserror('Err: The interval between @begin_time and @end_time is greateer than 10 hours.', 16, -1)
        return (1)
   end

   declare @begin   varchar(24),
           @end     varchar(24),
           @tb      varchar(256)

--   set @t_diff = datediff(hour, getdate(), getutcdate())
--   set @date_time = dateadd(hour, @t_diff, @date_time)   -- convert to UTC

   -- @begin and @end will be used to construct query string
   set @begin = convert(varchar(24), case when @begin_time is NULL then getdate()
                                          else @begin_time
                                     end,
                        121)

   if (@end_time is not NULL) 
      set @end = convert(varchar(24), @end_time, 121)

   select @tb = 'tb_' + @server + '_sysperf'
   if not exists (select * from sysobjects where type = 'U' and name = @tb)
   begin
       raiserror('Error: table %s does not exists', 16, -1, @tb)
       return (1)
   end

   create table #sysperf (
   log_time       datetime NULL ,
   server         varchar (120)  NULL ,
   object         varchar (120)  NULL ,
        SQL_instance   varchar (120)  NULL ,
        SQL_object     varchar (120)  NULL ,
   instance       varchar (120)  NULL ,
   counter        varchar (120)  NULL ,
   value          numeric(17, 3) NULL 
   )

   -- declare variables
   declare @sql       varchar(2000),
           @rowcnt    int,
           @instance  varchar(120),
           @object    varchar(120),
           @min_time  datetime,
           @max_time  datetime

   select @sql = 'select log_time, server, object, instance, counter, value
                    from tb_' + @server + '_sysperf '

   if @end_time is NULL
        select @sql = @sql + ' where log_time = (select max(log_time) from tb_' + @server + '_sysperf 
                                                  where log_time < ''' + @begin + ''')'
   else
        select @sql = @sql + ' where log_time between ''' + @begin + ''' and ''' + @end + ''''

   insert #sysperf (log_time, server, object, instance, counter, value)
   EXEC (@sql)
   select @rowcnt = @@rowcount

   if @rowcnt = 0
   begin 
       raiserror('Msg: there is no performance data collected for the given time or time period.', 16, -1)
       return (1)
   end

   -- Check if there are too many samples in the time period
   if (select count(distinct log_time) from #sysperf) > 100
   begin 
       raiserror('Msg: there are more than 100 samples for the given time period.', 16, -1)
       return (1)
   end

  -- separate SQL instance and object
  update #sysperf
     set SQL_instance = substring(object, 1, charindex(':', object) -1),
         SQL_object = substring(object, charindex(':', object) + 1, 120)
   where object like 'SQLServer%' 
      or object like 'MSSQL%'


   select @min_time = min(log_time), @max_time = max(log_time) 
     from #sysperf
--   select @time = dateadd(hour, -1 * @t_diff, @time)

   if @min_time = @max_time
      begin
           --prepare to print out the results from #sysperf when there is only a single sample
           create table #results (  rid                int identity primary key clustered,
                                    [object/counter]   char(40) NULL,
                                    instance           char(30) NULL,
                                    value              numeric(17,3) NULL
                                 )
           print '*** Server: ' + @server
           print '*** Time:   ' + convert(varchar(24), @min_time, 121)
           print ' '
        
           insert #results([object/counter]) values('-- Processor:')
           insert #results([object/counter], instance, value) 
                           select '    ' + counter, instance, value
                             from #sysperf
                            where object = 'Processor'
                            order by counter, instance
        
           insert #results([object/counter]) values(' ')
           insert #results([object/counter]) values('-- Memory:')
           insert #results([object/counter], instance, value) 
                           select '    ' + counter, instance, value
                             from #sysperf
                            where object = 'Memory'
                            order by counter, instance
        
           insert #results([object/counter]) values(' ')
           insert #results([object/counter]) values('-- Paging File:')
           insert #results([object/counter], instance, value) 
                           select '    ' + counter, instance, value
                             from #sysperf
                            where object = 'Paging File'
                            order by counter, instance
        
           insert #results([object/counter]) values(' ')
           insert #results([object/counter]) values('-- PhysicalDisk:')
           insert #results([object/counter], instance, value) 
                           select '    ' + counter, instance, value
                             from #sysperf
                            where object = 'PhysicalDisk'
                            order by counter, instance
        
           insert #results([object/counter]) values(' ')
           insert #results([object/counter]) values('-- Network Interface:')
           insert #results([object/counter], instance, value) 
                           select '    ' + counter, instance, value
                             from #sysperf
                            where object = 'Network Interface'
                            order by counter, instance
        
           insert #results([object/counter]) values(' ')
           insert #results([object/counter]) values('-- System:')
           insert #results([object/counter], instance, value) 
                           select '    ' + counter, instance, value
                             from #sysperf
                            where object = 'System'
                            order by counter, instance
        
            -- Now deal with SQL Server counters
        
            declare cr_instance cursor FOR
            select distinct SQL_instance
              from #sysperf 
             where object like '%SQL%'
            FOR READ ONLY
        
            open cr_instance
            fetch cr_instance into @instance
            while (@@fetch_status = 0)
                begin
                   insert #results([object/counter]) values(' ')
                   insert #results([object/counter]) values('*** SQL Instance (' + substring(@instance, charindex('$', @instance) +1, 120) + ')')
        
                   declare cr_object cursor FOR
                   select distinct SQL_object
                     from #sysperf 
                    where SQL_instance = @instance
                   FOR READ ONLY
                   open cr_object
                   fetch cr_object into @object
                   while (@@fetch_status = 0)
                     begin
                           insert #results([object/counter]) values(' ')
                           insert #results([object/counter]) values('-- ' + @object + ':')
                           insert #results([object/counter], instance, value) 
                                           select '    ' + counter, instance, value
                                             from #sysperf
                                            where SQL_instance = @instance 
                                              and SQL_object = @object
                                           order by counter, instance
        
                           fetch cr_object into @object
                     end
                     close cr_object
                     deallocate cr_object
        
                    fetch cr_instance into @instance
                end
            close cr_instance
            deallocate cr_instance
        
           select [object/counter], 
                  ISNULL(instance, ' ') as 'instance', 
                  ISNULL(cast(value as char(15)), ' ') as 'value'
             from #results
           order by rid
      end
   else
      begin
           --prepare to print out the results from #sysperf when there are multiple samples
           create table #results_m (rid                int identity primary key clustered,
                                    object             varchar(120) NULL,
                                    [object/counter]   char(40) NULL,
                                    instance           char(30) NULL,
                                    cnt            int           NULL,
                                    [min]          numeric(17,3) NULL,
                                    [max]          numeric(17,3) NULL,
                                    [avg]          numeric(17,3) NULL,
                                    [stdev]        numeric(17,3) NULL,
                                    T1   numeric(17,3) NULL,
                                    T2   numeric(17,3) NULL,
                                    T3   numeric(17,3) NULL,
                                    T4   numeric(17,3) NULL,
                                    T5   numeric(17,3) NULL,
                                    T6   numeric(17,3) NULL,
                                    T7   numeric(17,3) NULL,
                                    T8   numeric(17,3) NULL,
                                    T9   numeric(17,3) NULL,
                                    T10   numeric(17,3) NULL,
                                    T11   numeric(17,3) NULL,
                                    T12   numeric(17,3) NULL,
                                    T13   numeric(17,3) NULL,
                                    T14   numeric(17,3) NULL,
                                    T15   numeric(17,3) NULL,
                                    T16   numeric(17,3) NULL,
                                    T17   numeric(17,3) NULL,
                                    T18   numeric(17,3) NULL,
                                    T19   numeric(17,3) NULL,
                                    T20   numeric(17,3) NULL,
                                    T21   numeric(17,3) NULL,
                                    T22   numeric(17,3) NULL,
                                    T23   numeric(17,3) NULL,
                                    T24   numeric(17,3) NULL,
                                    T25   numeric(17,3) NULL,
                                    T26   numeric(17,3) NULL,
                                    T27   numeric(17,3) NULL,
                                    T28   numeric(17,3) NULL,
                                    T29   numeric(17,3) NULL,
                                    T30   numeric(17,3) NULL,
                                    T31   numeric(17,3) NULL,
                                    T32   numeric(17,3) NULL,
                                    T33   numeric(17,3) NULL,
                                    T34   numeric(17,3) NULL,
                                    T35   numeric(17,3) NULL,
                                    T36   numeric(17,3) NULL,
                                    T37   numeric(17,3) NULL,
                                    T38   numeric(17,3) NULL,
                                    T39   numeric(17,3) NULL,
                                    T40   numeric(17,3) NULL,
                                    T41   numeric(17,3) NULL,
                                    T42   numeric(17,3) NULL,
                                    T43   numeric(17,3) NULL,
                                    T44   numeric(17,3) NULL,
                                    T45   numeric(17,3) NULL,
                                    T46   numeric(17,3) NULL,
                                    T47   numeric(17,3) NULL,
                                    T48   numeric(17,3) NULL,
                                    T49   numeric(17,3) NULL,
                                    T50   numeric(17,3) NULL,
                                    T51   numeric(17,3) NULL,
                                    T52   numeric(17,3) NULL,
                                    T53   numeric(17,3) NULL,
                                    T54   numeric(17,3) NULL,
                                    T55   numeric(17,3) NULL,
                                    T56   numeric(17,3) NULL,
                                    T57   numeric(17,3) NULL,
                                    T58   numeric(17,3) NULL,
                                    T59   numeric(17,3) NULL,
                                    T60   numeric(17,3) NULL,
                                    T61   numeric(17,3) NULL,
                                    T62   numeric(17,3) NULL,
                                    T63   numeric(17,3) NULL,
                                    T64   numeric(17,3) NULL,
                                    T65   numeric(17,3) NULL,
                                    T66   numeric(17,3) NULL,
                                    T67   numeric(17,3) NULL,
                                    T68   numeric(17,3) NULL,
                                    T69   numeric(17,3) NULL,
                                    T70   numeric(17,3) NULL,
                                    T71   numeric(17,3) NULL,
                                    T72   numeric(17,3) NULL,
                                    T73   numeric(17,3) NULL,
                                    T74   numeric(17,3) NULL,
                                    T75   numeric(17,3) NULL,
                                    T76   numeric(17,3) NULL,
                                    T77   numeric(17,3) NULL,
                                    T78   numeric(17,3) NULL,
                                    T79   numeric(17,3) NULL,
                                    T80   numeric(17,3) NULL,
                                    T81   numeric(17,3) NULL,
                                    T82   numeric(17,3) NULL,
                                    T83   numeric(17,3) NULL,
                                    T84   numeric(17,3) NULL,
                                    T85   numeric(17,3) NULL,
                                    T86   numeric(17,3) NULL,
                                    T87   numeric(17,3) NULL,
                                    T88   numeric(17,3) NULL,
                                    T89   numeric(17,3) NULL,
                                    T90   numeric(17,3) NULL,
                                    T91   numeric(17,3) NULL,
                                    T92   numeric(17,3) NULL,
                                    T93   numeric(17,3) NULL,
                                    T94   numeric(17,3) NULL,
                                    T95   numeric(17,3) NULL,
                                    T96   numeric(17,3) NULL,
                                    T97   numeric(17,3) NULL,
                                    T98   numeric(17,3) NULL,
                                    T99   numeric(17,3) NULL,
                                    T100   numeric(17,3) NULL
                                 )
           print '*** Server: ' + @server
           print '*** Time:   ' + convert(varchar(24), @min_time, 121) + ' <---> ' + convert(varchar(24), @max_time, 121)
           print ' '
        
           insert #results_m([object/counter]) values(' ')
           insert #results_m([object/counter]) values('-- Processor:')
           insert #results_m(object, [object/counter], instance, cnt, [min], [max], [avg], [stdev]) 
                           select object, '    ' + counter as 'counter', instance, count(value), min(value), max(value), avg(value), stdev(value)
                             from #sysperf
                            where object = 'Processor'
                            group by object, counter, instance
                            order by object, counter, instance

           insert #results_m([object/counter]) values(' ')
           insert #results_m([object/counter]) values('-- Memory:')
           insert #results_m(object, [object/counter], instance, cnt, [min], [max], [avg], [stdev]) 
                           select object, '    ' + counter as 'counter', instance, count(value), min(value), max(value), avg(value), stdev(value)
                             from #sysperf
                            where object = 'Memory'
                            group by object, counter, instance
                            order by object, counter, instance

           insert #results_m([object/counter]) values(' ')
           insert #results_m([object/counter]) values('-- Paging File:')
           insert #results_m(object, [object/counter], instance, cnt, [min], [max], [avg], [stdev]) 
                           select object, '    ' + counter as 'counter', instance, count(value), min(value), max(value), avg(value), stdev(value)
                             from #sysperf
                            where object = 'Paging File'
                            group by object, counter, instance
                            order by object, counter, instance

           insert #results_m([object/counter]) values(' ')
           insert #results_m([object/counter]) values('-- PhysicalDisk:')
           insert #results_m(object, [object/counter], instance, cnt, [min], [max], [avg], [stdev]) 
                           select object, '    ' + counter as 'counter', instance, count(value), min(value), max(value), avg(value), stdev(value)
                             from #sysperf
                            where object = 'PhysicalDisk'
                            group by object, counter, instance
                            order by object, counter, instance

           insert #results_m([object/counter]) values(' ')
           insert #results_m([object/counter]) values('-- Network Interface:')
           insert #results_m(object, [object/counter], instance, cnt, [min], [max], [avg], [stdev]) 
                           select object, '    ' + counter as 'counter', instance, count(value), min(value), max(value), avg(value), stdev(value)
                             from #sysperf
                            where object = 'Network Interface'
                            group by object, counter, instance
                            order by object, counter, instance

           insert #results_m([object/counter]) values(' ')
           insert #results_m([object/counter]) values('-- System:')
           insert #results_m(object, [object/counter], instance, cnt, [min], [max], [avg], [stdev]) 
                           select object, '    ' + counter as 'counter', instance, count(value), min(value), max(value), avg(value), stdev(value)
                             from #sysperf
                            where object = 'System'
                            group by object, counter, instance
                            order by object, counter, instance

            -- Now deal with SQL Server counters
       
            declare cr_instance cursor FOR
            select distinct SQL_instance
              from #sysperf 
             where object like '%SQL%'
            FOR READ ONLY
        
            open cr_instance
            fetch cr_instance into @instance
            while (@@fetch_status = 0)
                begin
                   insert #results_m([object/counter]) values(' ')
                   insert #results_m([object/counter]) values('*** SQL Instance (' + substring(@instance, charindex('$', @instance) +1, 120) + ')')
        
                   declare cr_object cursor FOR
                   select distinct SQL_object
                     from #sysperf 
                    where SQL_instance = @instance
                   FOR READ ONLY
                   open cr_object
                   fetch cr_object into @object
                   while (@@fetch_status = 0)
                     begin
                           insert #results_m([object/counter]) values(' ')
                           insert #results_m([object/counter]) values('-- ' + @object + ':')
                           insert #results_m(object, [object/counter], instance, cnt, [min], [max], [avg], [stdev]) 
                                           select object, '    ' + counter as 'counter', instance, count(value), min(value), max(value), avg(value), stdev(value)
                                             from #sysperf
                                            where SQL_instance = @instance
                                              and  SQL_object = @object
                                            group by object, counter, instance
                                            order by object, counter, instance
        
                           fetch cr_object into @object
                     end
                     close cr_object
                     deallocate cr_object
        
                    fetch cr_instance into @instance
                end
            close cr_instance
            deallocate cr_instance

          -- Now prepare the output       
          if upper(@detail) = 'FALSE'
              begin
                  select  [object/counter],  
                          ISNULL(instance, ' ') as 'instance', 
                          ISNULL(cast(cnt as char(7)), ' ') as 'cnt',
                          ISNULL(cast([min] as char(15)), ' ') as 'min',
                          ISNULL(cast([max] as char(15)), ' ') as 'max',
                          ISNULL(cast([avg] as char(15)), ' ') as 'avg',
                          ISNULL(cast([stdev] as char(15)), ' ') as 'stdev'
                    from #results_m
                  order by rid
                  return
             end
          else
             begin
                  create table #log_time (rid       int identity,
                                          log_time  datetime NULL,
                                          c_name    varchar(4) NULL
                  )             
                  insert #log_time (log_time)
                  select distinct log_time from #sysperf

                  update #log_time
                     set c_name = 'T' + cast(rid as varchar(3))

                  declare @i int, @j int
                  select @j = max(rid) from #log_time
                  select @i = 1
                  while @i <= @j
                     begin
                          select @sql = ''
                          select @sql = 'update #results_m
                                            set T' + cast(@i as varchar(3)) + ' = s.value
                                           from #sysperf s
                                          where LTRIM(#results_m.[object/counter]) = s.counter
                                            and #results_m.object = s.object
                                            and (   (s.instance is not NULL and s.instance = #results_m.instance)
                                                 or (s.instance is NULL and #results_m.instance is NULL)
                                                )
                                            and s.log_time = ''' + convert(varchar(24), log_time, 121) + ''''
                            from #log_time
                           where rid = @i

                          EXEC (@sql)
                          select @i = @i + 1
                     end

                  select @i = 1
                  select @sql = 'select  [object/counter],  
                                         ISNULL(instance, '' '') as ''instance'', 
                                         ISNULL(cast(cnt as char(7)), '' '') as ''cnt'',
                                         ISNULL(cast([min] as char(15)), '' '') as ''min'',
                                         ISNULL(cast([max] as char(15)), '' '') as ''max'',
                                         ISNULL(cast([avg] as char(15)), '' '') as ''avg'',
                                         ISNULL(cast([stdev] as char(15)), '' '') as ''stdev'' '
                  while @i <= @j
                     begin
                          select @sql = @sql + 
                                  ', ISNULL(cast(T' + cast(@i as varchar(3)) + ' as char(15)), '' '') as ''' + 
                                   convert(varchar(24), log_time, 121) + ''' '
                            from #log_time
                           where rid = @i

                          select @i = @i + 1
                     end
                          
                  select @sql = @sql + ' from #results_m  order by rid'
                  EXEC (@sql)
             end
      end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create proc up_abc 
as 
set nocount on 
select * from authors

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create proc usp_test
as
begin tran
truncate table snaptest
if @@error <> 0 begin rollback tran return end
insert snaptest(text) values(convert(varchar(24), getdate(), 113))
if @@error = 0
   commit tran
else 
   rollback tran

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


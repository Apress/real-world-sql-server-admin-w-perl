# See the embedded POD or the HTML documentation

use strict;
use Data::Dumper;
use SQLDBA::ParseSQL qw( dbaNormalizeSQL dbaRestoreSQL 
                         dbaSplitBatch );

my $infile = shift or
   die "***Err: $0 expects a file on the command line.\n"; 

# the object name can be a simple identifier and a delimited one
my $name = q/(?:
                [\w@\#]+             | 
                \"(?:[^"] | \\\")+\" | 
                \[(?:[^]]|\]\])+\])
            /; 

# the proc name may be prefixed with the owner
my $SPNameRE = qr{ (?:  
                        $name        # one-part name
                      | $name\.$name # two-part name w owner
                   ) 
                 }ix;
my $SQLws = qr{ (?: \s        |  # Perl whitespace
                    /\*\w+\*/ |  # Delimited comment
                    \-\-\w+\n    # ANSI comment
                )+ 
              }ix;

Main : {
   # read the T-SQL script into a variable first   
   my $sql;
   open(FL, $infile) or die "***Err: could not open $infile for read.";
   read(FL, $sql, -s FL);
   close(FL);
   
   # replace comments, strings, and delimited identifiers
   # with unique string tokens
   my $sqlRef = dbaNormalizeSQL($sql, 1);

   # split the SQL code into batches by batch separator GO
   my $batchRef = dbaSplitBatch($sqlRef->{code});

   # combine batches of an SP into a script
   my $spRef= combineBatches($batchRef);

   # restore the original comments, strings, delimited id's
   foreach my $spName (keys %{$spRef}) {
      $sqlRef->{code} = $spRef->{$spName};
      # restore the original strings, delimited id's, and comments
      $sqlRef = dbaRestoreSQL($sqlRef);
      # write the SP script to a file
      writeSQLFile($sqlRef->{code}, $spName);
   }
} # Main

#######################
sub combineBatches {
   my $batchRef = shift or
      die "***Err: combineBatches() expects a reference.\n";
   
   # Find the array elements that are CREATE PROCEDURE statements
   # Use hash %index2Names to record the mapping from the array index
   # to the SP name
   my @sps;
   my %index2Names;
   for(my $i = 0; $i <= $#{$batchRef}; $i++) {
      if ( $batchRef->[$i] =~ 
               m{^ (?: $SQLws)? create $SQLws proc(edure)? 
                   $SQLws ($SPNameRE) }ix 
         ) {
         push @sps, $i;
         $index2Names{$i} = $2;
      }
   }
   
   # now verify that each CREATE PROCEDURE is preceded with 
   # settings ANSI_NULLS and QUOTED_IDENTIFIER
   foreach my $i (@sps) {
      # verify that the two batches preceding the CREATE PROCEUDRE are 
      # for ANSI_NULLS and QUOTED_IDENTIFIER settings
      if (    ($batchRef->[$i-1] . ' ' . $batchRef->[$i-2])
                 !~ /set $SQLws quoted_identifier $SQLws \w+/ix
           or ($batchRef->[$i-1] . ' ' . $batchRef->[$i-2])
                 !~ /set $SQLws ansi_nulls $SQLws \w+/ix
         ) {
         die "***Err: ANSI_NULLS or QUOTED_IDENTIFIER setting is missing.\n";
      }
   }
   
   my ($spRef, $line, $finish);
   
   # find the first and the last batch for each SP, and combine the batches
   # for the SP into a single script. Use the array index of the first batch
   # and the array index of the last batch to find the SP name from hash
   # %index2Names
   my $start = 0;
   shift @sps;     # toss off the first index
   foreach my $i (@sps) {
      $finish = $i-3;
      ($line) = grep {$_ >= $start and $_ < $finish} keys %index2Names;
      $spRef->{$index2Names{$line}} = 
                  join("\nGO\n", @{$batchRef}[$start..$finish]) . "\nGO\n";
      $start = $i-2;
   }
   # For the very last SP, $finish must be handled differently
   $finish = $#{$batchRef};
   ($line) = grep {$_ >= $start and $_ < $finish} keys %index2Names;
   $spRef->{$index2Names{$line}} = 
                  join("\nGO\n", @{$batchRef}[$start..$finish]) . "\nGO\n";
   return $spRef;                                  
} # combineBatches

#######################
sub writeSQLFile {
   my ($sql, $spName) = @_;

   # convert all non-alphanumeric to underline for file name
   $spName =~ s/\W/\_/g;   
   my $fileName = $spName . ".SQL";
   open(SQL, ">$fileName") or 
      die "***Err: couln't open $fileName.\n";
   print SQL $sql;
   close(SQL);
} # writeSQLFile

__END__

=head1 NAME

splitSPScript - Splitting a T-SQL stored procedure script file into multiple files

=head1 SYNOPSIS

   cmd>perl splitSPScript.pl  <SP T-SQL script file>

=head1 DESCRIPTION

Given a T-SQL script file that includes definitions of stored procedures (i.e. CREATE PROCEDURE
statements), the script I<splitSPScript.pl> splits it into multiple T-SQL script files, each containing a single
stored procedure.

To correct split a SQL stored procedure script, you need to solve three problems:

=over

=item *

The Perl whitespace (in other words, \s) is not sufficient to separate the T-SQL syntax elements.

=item *

T-SQL comments, quoted strings, or delimited identifiers all can confuse this regular 
expression, resulting in an incorrect split.

=item *

Splitting a script by this pattern won�t keep the settings of QUOTED_IDENTIFIER and ANSI_NULLS 
together with the definition of the stored procedure, thus altering the meaning of 
the stored procedure.

=back

These three problems are solved in the script I<splitSPScript.pl> as follows:

=over

=item *

The first problem is fixed by replacing the Perl whitespace with the regular expression for 
the SQL whitespace. 

=item *

The second problem is handled with the replace-match-restore strategy demonstrated in 
the previous sections in this chapter. The section "Implementing the Replace-Match-Restore Strategy"
in Chapter 3 introduced this strategy.

=item *

To handle the third problem with the settings of QUOTED_IDENTIFIER and ANSI_NULLS, 
the script first breaks the script into an array of batches by the batch separator GO. 
Then, for each array element -- in other words, a batch -- that contains a CREATE PROCEDURE 
statement, the script then searches the array backwards to find the two settings immediately 
preceding the statement. Similarly, the script searches the array forwards to find the next 
two settings immediately following the statement but before the next CREATE PROCEDURE 
statement. Joining these array elements together produces the script for the stored procedure. 

=back



=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

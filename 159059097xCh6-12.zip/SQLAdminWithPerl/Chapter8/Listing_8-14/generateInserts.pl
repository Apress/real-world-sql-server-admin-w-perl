# See the embedded POD or the HTML documentation

use strict;
use Data::Dumper;
use Win32::ODBC;
use Getopt::Std;

my %opts;
getopts('S:d:t:', \%opts);
my ($server, $dbName, $tbName) = ($opts{S}, $opts{d}, $opts{t});
(defined $server && defined $dbName && defined $tbName) or printUsage();

Main: {
   my $connStr = "Driver={SQL Server};Server=$server;" .
              "Database=$dbName;Trusted_Connection=yes";
   my $conn = new Win32::ODBC($connStr) or 
      die "***Err: " . Win32::ODBC::Error();

   my ($columnRef, $attribRef) = getColumnProperties($tbName, $conn);
   my $sql = constructINSERT($columnRef, $attribRef, $conn);
   print $sql;
   
   $conn->Close();
} # Main   

############################
sub getColumnProperties {
   my($tbName, $conn) = @_;
   
   my @columns;
   my %attrib;
   if (! $conn->Sql("select * from $tbName where 1=2") ) {
      1 while $conn->FetchRow();

      # first get the data type for each column
      my @fields = $conn->FieldNames();
      %attrib = $conn->ColAttributes($conn->SQL_COLUMN_TYPE_NAME, @fields);

      # in case the data type is user defined, we need 
      # the real data type to help us decide how to handle 
      # the retrieved data in an INSERT statement
      foreach my $field (@fields) {
         if (! $conn->Sql("sp_help \'$attrib{$field}\'") ) {
            while($conn->FetchRow()) {
               my ($type) = $conn->Data("Storage_type");
               $attrib{$field} = $type;
            }
         }
         if ($attrib{$field} =~ /^(image|sql_variant)$/i) {
            die "***Err: data type $attrib{$field} not supported.\n";
         }
         push @columns, $field if lc($attrib{$field}) ne 'timestamp';
      }
   }
   else {
      die "***Err: failed to run select * from $tbName where 1=2.\n";
   }
   return (\@columns, \%attrib);
} # getColumnProperties

########################
sub constructINSERT {
   my($columnRef, $attribRef, $conn) = @_;

   (scalar @$columnRef && scalar %$attribRef) or
      die "Err: \$columnRef or \$attribRef is empty.\n";
   
   my $sql;   
   if (! $conn->Sql("select * from $tbName") ) {
      # now get the data values for each row
      while ($conn->FetchRow()) {
         $sql .= "INSERT $tbName (" . join(',', @$columnRef) . ")\n";
         my @values = ();
         my %data = $conn->DataHash();
         # decide how to handle the VALUE clause of the INSERT
         foreach my $column (@$columnRef) {
            # the values of these data types can be used as is
            if ($attribRef->{$column} =~ /int|smallint|bigint|tinyint|
                                          bit|decimal|numeric|money|
                                          smallmoney|float|real
                                         /ix) {
               if (defined $data{$column}) {
                  push @values, $data{$column};
               }
               else {
                  push @values, 'NULL';
               }
            }
            # the values of these types must be quoted with a pair of 
            # single quotation marks
            elsif ($attribRef->{$column} =~ /datetime|smalldatetime|
                                             char|varchar|nchar|nvarchar|
                                             text|ntext|uniqueidentifier
                                            /ix) {
               if (defined $data{$column}) {
                  $data{$column} =~ s/\'/\'\'/g;
                  push @values, "\'$data{$column}\'";
               }
               else {
                  push @values, 'NULL';
               }
            }
            # the binary data must be converted to a HEX string format
            elsif ($attribRef->{$column} =~ /binary|varbinary
                                            /ix) {
               if (defined $data{$column}) {
                  push @values, '0x' . unpack("H*", $data{$column});
               }
               else {
                  push @values, 'NULL';
               }
            }
            else {
               print "***Assert: invalid code path. Skip this row.\n";
               next;
            }
         }
         $sql .= "VALUES (" . join(',', @values) . ")\n";
      }
   }
   return $sql;
} # construtcINSERT

###################
sub printUsage {
    print << '--Usage--';
Usage:    
   cmd>perl GenerateDataInserts.pl  -S <SQL server or instance> 
                                    -d <database name>
                                  [ -t <table name> ]
--Usage--
exit;
} # printUsage

__END__

=head1 NAME

generateDataInserts - Generating INSERT statements

=head1 SYNOPSIS

   cmd>perl GenerateDataInserts.pl  -S <SQL server or instance> 
                                    -d <database name>
                                  [ -t <table name> ]

=head1 USAGE EXAMPLE

To generate the INSERT statements for populating the pubs..authors table on the SQL instance
.\APOLLO, you can run the script as follows:

 perl generateInserts.pl -S.\apollo -d pubs -t authors

 INSERT authors (au_id,au_lname,au_fname,phone,address,city,state,zip,contract)
 VALUES ('172-32-1176','White','Johnson','408 496-7223','10932 Bigge Rd.','Menlo Park','CA','94025',1)
 
 INSERT authors (au_id,au_lname,au_fname,phone,address,city,state,zip,contract)
 VALUES ('213-46-8915','Green','Marjorie','415 986-7020','309 63rd St. #411','Oakland','CA','94618',1)
 
 ...
 
 INSERT authors (au_id,au_lname,au_fname,phone,address,city,state,zip,contract)
 VALUES ('998-72-3567','Ringer','Albert','801 826-0752','67 Seventh Av.','Salt Lake City','UT','84152',1)

=head1 DESCRIPTION

Given a table, the script I<GenerateDataInserts.pl> generates an INSERT statement for 
each row in the table. 

The script first reads the table definition, then reads every row from the table, 
applies necessary transformation to each column per its definition, and constructs 
the INSERT statement. A column may require transformation so that it can be correctly 
represented in a character string in the INSERT statement. 

Constructing an INSERT statement itself is straightforward. But you need to format data 
differently in the VALUES clause depending on its data type. When it comes to formatting, 
the SQL Server data types fall into three categories:

=over

=item * Data that can be used as is: 

The data types in this category include the integer types, the number types, the money types, 
and the bit type.

=item *  Data that must be quoted: 

A data value of type datetime, char, text, uniqueidentifier, and the like needs to be in 
single quotation marks.

=item *  Data that requires conversion: 

A data value of the binary data type must be converted to a hexadecimal string.

=back

In case a data value has embedded single quotation marks, you need to escape them when 
dealing with the data types in the second category. The following code fragment takes care 
of adding the quotation marks:

 if (defined $data{$column}) {
       $data{$column} =~ s/\'/\'\'/g;
       push @values, "\'$data{$column}\'";
 }
 else {
       push @values, 'NULL';
 }

The array @values will eventually include all the required data values in their proper 
formats ready to be concatenated into the string inside the VALUES clause of the INSERT 
statement.

A data value that's of the binary or varbinary type requires additional effort before you 
can add it to the VALUES clause. Note that the syntax for inserting a binary value into a 
table is similar to this example:

 INSERT binTable(binCol) VALUES(0x782374)

In Query Analyzer, you may have noted that when you select from a table that has a column 
of the binary data type, the result is displayed as a hexadecimal string because Query 
Analyzer performs the conversion for you automatically. The script I<generateDataInserts.pl> 
gets the binary data through ODBC, which does no such conversion automatically. 
Fortunately, Perl has the rather versatile built-in function I<unpack()> for this sort of 
conversion. The I<unpack()> function takes a string (a binary string in this case) 
and expands it out into a list of values (hexadecimal values in this case). The following 
code segemnt shows how you do the conversion for a binary value in the function 
I<constructINSERT()>:

 if (defined $data{$column}) {
        push @values, '0x' . unpack("H*", $data{$column});
 }
 else {
        push @values, 'NULL';
 }

The script relies heavily on the metadata information exposed by ODBC. In the function 
I<getColumnProperties()>, the script uses the I<FieldNames()> method and the I<ColAttributes()>
method -- both from the module Win32::ODBC -- to obtain the columns of the table and the 
data types of these columns, respectively.

However, a data type retrieved with the I<ColAttributes()> method may be a user-defined data 
type, which doesn't directly tell how to handle the data in the VALUES clause of the INSERT 
statement. What you need is the corresponding SQL Server built-in data type. To accomplish 
that, the function I<getColumnProperties()> loops through each column returned by the 
I<FieldName()> method and executes a T-SQL I<sp_help> on its data type. 
The storage_type column in the resultset of sp_help shows the SQL Server data type.

There is actually a simpler approach to retrieving the system-supplied data types (i.e. the
SQL Server built-in data types) of all the columns in a user table. That is to query the 
INFORMATION_SCHEMA.COLUMNS views. The DATA_TYPE column of the view shows the system-supplied 
data type for each column in each user table.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

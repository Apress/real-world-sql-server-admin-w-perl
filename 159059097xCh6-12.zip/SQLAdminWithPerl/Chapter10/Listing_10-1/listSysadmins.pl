# See the embedded POD or the HTML documentation

use strict;
use Win32::ODBC;

# Import the function from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaRemoveDuplicates );

# Import functions from the module Win32::NetAdmin
use Win32::NetAdmin qw( GetDomainController 
                        GroupGetMembers 
                        LocalGroupGetMembersWithDomain
                        UsersExist );

Main: {
   my $serverConn = shift 
      or die "***Err: a server is expected on the command line.";

   # get all the accounts/logins with sysadmin role from SQL Server
   my $loginRef = getSQLSysadmins($serverConn);
   # in case the server name is followed by an instance name
   my ($server) = $serverConn =~ /([^\\]+)(\\.+)?/;
   
   # replace BUILTIN with the server name
   foreach (@{$loginRef->{groupSet}}) { 
      s/BUILTIN\\/uc($server) . "\\"/e; # evaluate the right side before replace
   }

   # remove all local groups and get their members
   $loginRef = removeLocalGroups($loginRef);

   # get global group members
   $loginRef = getGlobalGroupMembers($loginRef);

   # now print out all the NT/SQL logins that are SQL sysadmin
   print "Listing all NT/SQL logins with the sysadmin rights ...\n";
   foreach (sort @{$loginRef->{resultSet}}) { print "\t$_\n"; }
} # Main

#########################
sub getSQLSysadmins {
    my $serverConn = shift or
       die "***Err: getSQLSysadmins() expects a server.";

   my $connStr = "Driver={SQL Server};Server=$serverConn;"  . 
                  "Trusted_Connection=Yes;Database=master";
   my $conn = new Win32::ODBC ($connStr) or 
      die "***Err: Can't connect to $serverConn. " . Win32::ODBC::Error();
  
   # get sysadmin logins (NT and SQL)
   my @logins = ();
   my $sql = q/SELECT loginname FROM master.dbo.syslogins 
                WHERE sysadmin = 1
                  AND isntgroup = 0/;

   unless ($conn->Sql( $sql )) {
       @logins = (@logins, $conn->Data) while ($conn->FetchRow());
   } else {
       print "***Err: executing $sql. ", Win32::ODBC::Error(), "\n"; 
   }

   # get sysadmin nt groups
   my @groups = ();
   my $sql =  q/select loginname from master.dbo.syslogins 
                 where sysadmin = 1
                   and isntgroup = 1/;


   unless ($conn->Sql( $sql )) {
       @groups = (@groups, $conn->Data) while ($conn->FetchRow());
   } else {
       print "***Err: executing $sql. ", Win32::ODBC::Error(), "\n"; 
   }
   $conn->Close();
   
   return { resultSet  => \@logins, 
            groupSet   => \@groups,
            userSet    => undef };
} # getSQLSysadmins

###########################
sub removeLocalGroups {
    my $loginRef = shift or
         die "***Err: removeLocalGroups() expects a reference.";
    
    foreach my $group (@{$loginRef->{groupSet}}) {
        if (my $rc = getLocalGroupMembers($group)) {
            push @{$loginRef->{userSet}}, @{$rc};
        }
        else {
            push @{$loginRef->{userSet}}, $group;
        }
    }
    delete $loginRef->{groupSet};
    return $loginRef;  
} # removeLocalGroups

##############################
sub getGlobalGroupMembers {
    my $loginRef = shift or
          die "***Err: getGlobalGroupMembers() expects a reference.\n";
    my @logins = ();
    
    foreach my $user (@{$loginRef->{userSet}}) {
        if ($user =~ /^NT\s+AUTHORITY\\/) {
            push @logins, $user;
            next;
        }

        my ($domain, $name) = $user =~ /^(.+?)\\(.+)$/;
        if ( UsersExist($domain, $name ) ) { # a user account
            push @logins, $user;
        }
        else {
            my $pdc;
            my @users;
            if (GetDomainController(undef, $domain, $pdc)) {
                $pdc =~ s/\\//g;

                if ( UsersExist($pdc, $name ) ) {
                    push @logins, $user;
                }
                else {  # $name is a global group account
                    # get users in the global group
                    if (GroupGetMembers($pdc, $name, \@users)) {
                        # prefix the users with the domain name                    
                        push @logins, map { "$domain\\$_"; } @users;
                    }
                    else {  # you shouldn't reach here
                        print "***Err: can't retrieve users for $domain\\$name.\n";
                        next;
                    }
                }
            }
            else {
                print "***Err: can't find domain controller for $domain.\n";
                next;
            }
        }
    }
    
    push @logins, @{$loginRef->{resultSet}};
    $loginRef->{resultSet} = dbaRemoveDuplicates(\@logins);
    return $loginRef;
} # getGlobalGroupMembers

################################
sub getLocalGroupMembers {
    my $group = shift or
        die "***Err: getLocalGroupMember() expects a group name.";

    my ($domain, $group_name) = $group =~ /^(.+?)\\(.+)$/  or
        die "***Err: $group must be qualified with a domain/machine name.";
    
    my @users = ();
    if (LocalGroupGetMembersWithDomain($domain, $group_name, \@users)) {
        return \@users;
    }
    else {
        return undef;
    }
}  # getLocalGroupMembers

__END__

=head1 NAME

listSysadmins - Listing sysadmin accounts or logins

=head1 SYNOPSIS

   cmd>perl listSysadmins.pl <SQL Instance name>

=head1 USAGE EXAMPLE

To print all the Windows user accounts and SQL Server logins that have the sysadmin 
privileges on the SQL Server instance LINCHI\APOLLO, log on to the domain 
with a Windows account that has been granted access to the instance, and run 
the script as follows on the command line:

 cmd>perl ListSysadmin.pl SQL1\APOLLO

 Listing all NT/SQL logins with the sysadmin rights ...
   NYDomain\NTAdmin
   NYDomain\vshea
   LINCHI\Administrator
   LINCHI\linchi_shea
   LINCHI\lshea
   distributor_admin
   sa

=head1 DESCRIPTION

The script I<listSysadmins.pl> goes through the following steps to find all the Windows user 
accounts and SQL Server logins that have the SQL Server sysadmin privileges:

=over

=item 1.

Start with three empty sets: the resultset, the group set, and the user set.

=item 2.

Add all the Windows user accounts and the SQL Server logins in the sysadmin role to 
the resultset.

=item 3.

Add all the Windows group accounts in the sysadmin role to the group set.

=item 4.

Now, the group set may include both local and global groups. For each group in the group set, 
do the following: First, if it is a local group, add all its members to the user set, and second, 
if it is not a local group, then it must be a global group. Add it to the user set.

=item 5.

Now, the user set may include both user accounts and global group accounts. For each member in 
the user set, do the following: First, if it is a global group, add its members to the resultset, 
and second, if it is not a global group, then it must be a user account. Add it to the resultset.

=item 6.

The resultset now has all the Windows user accounts and SQL Server logins that have the 
sysadmin privileges.

=back

The following paragraphes elaborate on these steps.

The script begins with a call to the function I<getSQLSysadmin()>, which queries the SQL Server 
system view syslogins in the master database to get the logins -- both the Windows user accounts 
and the SQL Server logins -- as well as the Windows groups that are sysadmin members. The 
function I<getSQLSysadmin()> first runs the following SQL query via the module Win32::ODBC to 
get the sysadmin members that are not Windows groups:

 SELECT login 
   FROM master.dbo.syslogins
  WHERE issysadmin = 1 AND isntgroup = 0

The I<getSQLSysadmin()> function then runs the following SQL query to get the sysadmin members 
that are Windows groups:

 SELECT login 
   FROM master.dbo.syslogins
  WHERE issysadmin = 1 AND isntgroup = 1

The script captures the results of these two queries separately because it needs to further 
work on the Windows groups. The function I<getSQLSysadmin()> returns the query results in a 
hash data structure referenced by I<$loginRef>. The following is a sample of this 
hash data structure:

 $loginRef = {
    groupSet   => [ 'BUILTIN\\Administrators', 'NYDomain\\SQLDBAs' ],
    resultSet  => [ 'distributor_admin', 'SQL1\\lshea', 'sa' ],
    userSet    => undef
 }

Subsequent steps in the script all work on this data structure to get the user accounts from 
each group in the array referenced by the hash key groupSet and to add the user accounts to 
the array referenced by the hash key resultSet. 

The next key step is to replace the BUILTIN with the server name. Note that the local administrators group
is represented as BUILTIN\Administrators.

The next step is to call the function I<removeLocalGroup()>, which goes through the groups in 
the groupSet array and adds all the global groups and all the members of each local group to 
the array referenced by the hash key userSet -- referred to as the userSet array in the ensuing 
discussions. The members of a local group are obtained using the function I<getLocalGroupMembers()> 
from the module Win32::NetAdmin. At this point, the data structure should look like the following:

 $loginRef = {
    resultSet => [ 'distributor_admin', 'NYSQL01\\lshea', 'sa'  ],
    userSet   => [ 'NYDomain\\SQLDBAs', 'NYDomain\\DomainAdmins', 
                   'NYDomain\\vshea' ]
 }

Finally, the script calls the function I<getGlobalGroupMembers()> to add the user accounts or 
the members of the global groups in the userSet array to the resultSet array. This function 
again relies on the functions available from the Win32::NetAdmin module to determine whether 
an element in the userSet array is a user account or a global group. If it�s a global group, 
I<getGlobalGroupMembers()> calls the I<GroupGetMembers()> function imported from Win32::NetAdmin 
to retrieve the members of the group as follows:

 if ( UsersExist($pdc, $name ) ) { # a user account
     push @logins, $user;
 }
 else {  # $name is a global group account
     # get users in the global group
     if (GroupGetMembers($pdc, $name, \@users)) {
         # prefix the users with the domain name
         push @logins, map { "$domain\\$_"; } @users;
     }
     else {  # you shouldn't reach here
         print "***Err: can't get users for $domain\\$name.\n";
         next;
     }
 }

Now, when the function I<getGlobalGroupMembers()> returns, the resultSet array has all the SQL 
Server logins and the Windows user accounts that have been granted membership in the sysadmin 
role, and it�s ready to be printed.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


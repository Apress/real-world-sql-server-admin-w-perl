use strict;
use Win32::NetAdmin;
use Win32::OLE;
use Win32::Service;
use Getopt::Std;

my %opts;
getopts('lhmd:s:', \%opts);
$opts{h} && die printUsage();
my ($user, $password) = ('sa', undef);

select((select(STDOUT), $| = 1)[0]); 

Main: {
   my @domains = enumerateDomains(\%opts);
   foreach my $domain (sort @domains) {
      print scalar localtime(), " *** Domain: $domain";

      my @servers = enumerateServers($domain);
      print "\t Found ", scalar @servers, " NT machines in the domain\n";
      
      foreach my $server (sort @servers) {
         $opts{m} && print "\t\t Scanning machine $server\n";
         if (my $msg = isSQL($server, $user, $password)) 
            { print "\t\t   $msg\n"; }
      }
   }
} # Main

#########################
sub enumerateDomains {
#########################
   my $optsRef = shift or 
         die "***enumerateDomains expects a reference.\n";
   
   my @domains;
   Win32::NetAdmin::GetServers( '', '', SV_TYPE_DOMAIN_ENUM, \@domains);

   if( $optsRef->{d} ) {
      return grep { uc($optsRef->{d}) eq uc($domain) } @domains;
   }
   
   if( $optsRef->{s} ) {
      return grep { uc($optsRef->{s}) le uc($domain) } @domains;
   }
} # enumerateDomains

#########################
sub enumerateServers {
#########################
   my $domain = shift or 
         die "***enumerateServers expects a domain name.\n";
        
   my @servers;
   Win32::NetAdmin::GetServers( '', $domain, SV_TYPE_NT, \@servers);
   return @servers;
} # enumerateServers

#########################
sub isSQL {
#########################
   my ($server, $user, $password) = @_;
   my $msg;
   
   my $db = Win32::OLE->new('ADODB.Connection');
   $db->{CoonectionTimeout} = 2;
   $db->Open("Driver={SQL Server};Server=$server;UID=$user;PWD=$password");
   my $err = Win32::OLE->LastError();
   if (!$err) {
      $msg = "Null $user password> $server";
      $db->Close;
   } 
   else {
      if ($err =~ /Login\s+failed/i) {
        $msg = "Failed $user login> $server";
      }
      else {
         my %services;
         Win32::Service::GetServices($server, \%services);
         if (grep(/MSSQLServer|MSSQL\$|SQLServerAgent/i, keys %services)) {
             $msg = "Win32::Service> $server";
         }
      }
   }
   return $msg;
}  # isSQL

#########################
sub printUsage {
#########################
    print << '--Usage--';
Usage:
 perl ScanForSQLServer.pl [-h] [-d] [-l] [-m <domain name> | -s <domain name>]
                        when no arguments are specified, scan all 
                        domains and all NT machines.

    -h                  print this usage
    -l                  list the machines only. Do not scan for SQL Server
    -d<domain name>     scan machines in this domain only
    -s<domain name>     skip to this domain and start scanning in this domain
                        and all the subsequent domains
    -m                  list all the machines as they are being 
                        scanned. For debug purposes.
--Usage--
} # printUsage
# See the embedded POD or the HTML documentation
#
# Linchi Shea  07/02/2001   This script scans the entire network to locate all
#                             domains first. For each domain, it scans for all
#                             NT machines, and for each NT, it tries to connect
#                             to it using ODBC as if it were a SQL Server. It checks
#                             the connection status to decide whether it is an active
#                             SQL Server. 
#                           This method is not totally foolproof. For instance, client
#                             network configuration issues can prevent the script from
#                             seeing a running SQL Server.
#                           
# Linchi Shea 11/29/2001    Changed to use ADO instead of ODBC. Win32::ODBC LoginTimeout doesn't
#                            seem to work. Also added command line arguments -h, -l, -d, -s, and -m.
#                            See print_suage() for info.
# Linchi Shea 06/28/2002    Put the code to test SQL Server in function isSQLServer.

use strict;
use Win32::NetAdmin;
use Win32::OLE;
use Win32::Service;
use Getopt::Std;

my %opts;
getopts('lhmd:s:', \%opts);
printUsage() if $opts{h};
select((select(STDOUT), $| = 1)[0]); # flush STDOUT after each output

Main: {
   my @domains;
   my @servers;
   my ($user, $password) = ('sa', undef);

   # enumerate domains
   Win32::NetAdmin::GetServers('', '', SV_TYPE_DOMAIN_ENUM, \@domains);

   foreach my $domain (sort @domains) {
      print scalar localtime(), "   *** Domain: $domain";

      # if there are any arguments
      if( $opts{d} ) {   # work on a particular domain introduced by -d
         if( $opts{d} ne $domain) {
            # skip to next domain
            print " skipped\n";
            next;
         }
      }
      else {
        if( $opts{s} ) { # work on the domains starting from the one by -s 
            # if the specified domain hasn't been reached yet
            if( $opts{s} gt $domain) {
               # skip to next domain
               print " skipped\n";
               next;
            }
        }
      }
      print "\n";

      # now enumerate machines in the domain
      Win32::NetAdmin::GetServers( '', $domain, SV_TYPE_NT, \@servers);
      print "\t\t Found ", scalar @servers, " NT machines in this domain\n";
      
      foreach my $server (sort @servers) {
         if ($opts{m}) {
            print "\t\t Scanning machine $server\n";
         }
         next if $opts{l};
         my $whatisit = isSQLServer($server, $user, $password);
         print "\t\t$whatisit\n";
      }
   }
} # Main

######################
sub printUsage {
    print << '--Usage--';
Usage:
 cmd>perl scanForSQLServer.pl [-h] [-m] [-l] [-d <domain name> | -s <domain name>]
                   When no arguments are specified, scan all 
                   domains and all NT machines.

    -h                  print this usage info
    -m                  list all the machines as they are being scanned.
    -l                  list the machines only. Do not scan for SQL Server
    -d<domain name>     scan machines in this domain only
    -s<domain name>     skip to this domain and start scanning in this domain
                        and all the subsequent domains
--Usage--
   exit;
} # printUsage

######################
sub isSQLServer {
######################
   my ($server, $user, $password) = @_;
   my $whatisit;
   
   my $conn = Win32::OLE->new('ADODB.Connection');
   $conn->{CoonectionTimeout} = 2;  # set a shorter timeout
   $conn->Open("Driver={SQL Server};Server=$server;UID=$user;PWD=$password");
   my $err = Win32::OLE->LastError();
   if (!$err) {
        $whatisit = "Null sa password> $server";
        $conn->Close;
   } 
   else {
       if ($err =~ /Login\s+failed/i) {
           $whatisit = "Failed Login> $server";
       }
       else {
              my %Services;
              Win32::Service::GetServices($server, \%Services);
              if (grep(/^\s*(MSSQLServer|MSSQL\$\w+)\s*$/i, keys %Services)) {
                   $whatisit = "Win32::Service> $server";
              }
       }
   }
   return $whatisit;
} # isSQLServer

__END__

=head1 NAME

scanForSQLServer - Scanning the network for SQL Server machines

=head1 SYNOPSIS

 cmd>perl scanForSQLServer.pl [-h] [-m] [-l] [-d <domain name> | -s <domain name>]

    When no arguments are specified, scan all domains and all NT machines.

    -h                  print this usage info
    -m                  list all the machines as they are being scanned.
    -l                  list the machines only. Do not scan for SQL Server
    -d<domain name>     scan machines in this domain only
    -s<domain name>     skip to this domain and start scanning in this domain
                        and all the subsequent domains

=head1 DESCRIPTION

The script I<scanForSQLServer.pl> uses the module Win32::NetAdmin to enumerate the domains 
and the servers in a domain. The following line at the beginning of the Main code block 
enumerates domains:

 Win32::NetAdmin::GetServers('', '', SV_TYPE_DOMAIN_ENUM, \@domains);

The domains that are found will be returned in the array @domains. Then, for each domain in 
@domains, the script again uses the function I<GetServers()> to retrieve a list of machine 
accounts that are running Windows 2000/NT:

 # now enumerate machines in the domain
 Win32::NetAdmin::GetServers('', $domain, SV_TYPE_NT, \@servers);

The machine names are in the array @servers. Finally, for each machine in the array, the 
script calls the function I<isSQLServer()> to test whether SQL Server is running or installed 
on the machine.

Several tests are implemented in the function I<isSQLServer()>. First, it tries to log in 
to the SQL Server using ActiveX Data Objects (ADO) as if a SQL Server default instance was 
running. The function then checks for the following two conditions: 

=over

=item *

If the login attempt succeeds, it's indicative of a running SQL Server default instance.

=item *

If the login attempt receives a login failure error, it's again indicative of a running SQL 
Server default instance.

=back

Any other return status from the login attempt doesn't provide sufficient information for a 
positive identification. The function therefore performs one more test with the help of 
the module Win32::Service. It calls the function I<Win32::Service::GetServices()> to 
enumerate the Win32 services -- both active and inactive -- on the machine, and it looks 
for these string patterns in the service names: 

 MSSQLServer, and 
 MSSQL\$\w+ 

The presence of any of these string patterns is enough to conclude that a SQL Server 
instance is installed on that machine.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaReadINI dbaReadSavedRef dbaSaveRef 
                        dbaSetDiff dbaSetCommon );

# Import the functions from the module SQLDBA::Security
use SQLDBA::Security qw( dbaGetServiceAccount dbaGetLoginConfig 
                         dbaGetSysadminMembers dbaGetShares
                         dbaGetSQLRegistryPerms );
use Getopt::Std;
use Data::Dumper;

Main: {
   my $diffRef;

   my %opts;
   getopts('shdc:', \%opts);
   printUsage() if $opts{h} or !$opts{c};
   
   my $file = $opts{c};

   # read configurations from the config file
   my $configRef = dbaReadINI($file);

   # remove the entries that are disabled in the config file
   foreach my $server (keys %$configRef) {
     delete $configRef->{$server} 
               if $configRef->{$server}->{DISABLED} =~ /^y/i;
   }
   
   # read the current security configurations
   my $currentRef = readCurrentSecurityConfig($configRef)
       or die "***Err: Unable to read the current security configurations.\n";
 
   # compare security config differences
   if ($opts{d}) {
      my $savedRef
            = dbaReadSavedRef($configRef->{CONTROL}->{SECURITYCONFIGLOG}); 

      if ($savedRef) {
         # find the difference betwene current and saved security config
         $diffRef = compareSecurityConfig($currentRef, $savedRef);
      }

      if ($diffRef) {
         # print the security config differences
         printSecurityConfigDiff($diffRef);
      }
      else {
         print "***Msg: No change to SQL Server security configurations.\n";
      }
   }
   else { # if -d not specified
      # print the current security configurations
      printCurrentSecurityConfig($currentRef);
   }

   if ($opts{s}) {
      # save the current security configurations      
      dbaSaveRef($configRef->{CONTROL}->{SECURITYCONFIGLOG}, 
                 $currentRef, 'ref'); 
   }      
} # Main

######################
sub printUsage {
    print << '--Usage--';
Usage:
 perl TrackSecurityConfig.pl [-h] [-d] -c <configuration file>

    -h     print this usage info
    -s     save the current service accounts as the canonical config    
    -d     report changes to the SQL Server security configurations
    -c     specify a configuration file
--Usage--
   exit;
} # printUsage

#################################
sub readCurrentSecurityConfig {
   my $configRef = shift;
   ref($configRef) or 
         die "***Err: readCurrentSecurityConfig() expects a reference.";

   my $ref;
   foreach my $server (sort keys %$configRef) {
      next if uc($server) eq 'CONTROL';
      foreach my $instance (sort split /\s*,\s*/, 
                                     $configRef->{$server}->{INSTANCES}) {
         my @services;
         my $instanceStr;
         if (uc($instance) eq uc('MSSQLServer')) {
            push @services, uc('MSSQLServer');
            push @services, uc('SQLServerAgent');
            $instanceStr = $server;
         }
         else {
            push @services, 'MSSQL$' . uc($instance);
            push @services, uc('SQLAgent$') . uc($instance);
            $instanceStr = "$server\\" . $instance;
         }

         #get current service accounts
         foreach my $service (sort @services) {
            $ref->{$server}->{uc($instance)}->{ServiceAccounts}->{$service} 
                     = dbaGetServiceAccount($server, $service);
         }
         
         # get current authentication mode
         $ref->{$server}->{uc($instance)}->{AuthenticationMode}
                  = dbaGetLoginConfig($instanceStr, 'login mode');
                  
         # get current audit level
         $ref->{$server}->{uc($instance)}->{AuditLevel}
                  = dbaGetLoginConfig($instanceStr, 'audit level');
                     
         # get current sysadmin members
         $ref->{$server}->{uc($instance)}->{SysadminMembers}
                  = dbaGetSysadminMembers($instanceStr);
         
         # get shares
         $ref->{$server}->{uc($instance)}->{Shares}
                  = dbaGetShares($server);
         
         # get current registry key permissions
         $ref->{$server}->{uc($instance)}->{RegistryPermissions}
                  = dbaGetSQLRegistryPerms($server, $instance);
      }
   }
   return $ref;
} # readCurrentSecurityConfig

##############################
sub compareSecurityConfig {
   my($currentRef, $savedRef) = @_;

   my $diffRef;
   foreach my $server (keys %$currentRef) {
      next unless exists $savedRef->{$server};
      foreach my $instance (keys %{$currentRef->{$server}}) {
         next unless exists $savedRef->{$server}->{$instance};
         
         my $currentInstanceRef = $currentRef->{$server}->{$instance};
         my $savedInstanceRef = $savedRef->{$server}->{$instance};
         
         my $typeDiffRef;
         foreach my $configType (keys %$currentInstanceRef) {
            next unless exists $savedInstanceRef->{$configType};
            
            # these two variables are used to contain the cod ewidth
            # Note they may references or simple scalar values
            my $currentConfigType = $currentInstanceRef->{$configType};
            my $savedConfigType = $savedInstanceRef->{$configType};

            # record any service account difference
            if (uc($configType) eq uc('ServiceAccounts')) {
                foreach my $service (keys %$currentConfigType) {
                   next unless exists $savedConfigType->{$service};
                   if ( uc($savedConfigType->{$service}) ne 
                        uc($currentConfigType->{$service}) ) {
                         $typeDiffRef->{$configType}->{$service} =
                               $savedConfigType->{$service} . " => " .
                               $currentConfigType->{$service};
                   }
                }
            }
            
            # record any difference between sysadmin memberships
            if (uc($configType) eq uc('SysadminMembers')) {
               if (my @diff = dbaSetDiff($savedConfigType,
                                         $currentConfigType)) {
                   $typeDiffRef->{$configType}->{Removed} = [ @diff ];
               }
               if (my @diff = dbaSetDiff($currentConfigType,
                                         $savedConfigType)) {
                   $typeDiffRef->{$configType}->{Added} = [ @diff ];
               }
            }
            
            # record any difference between shares
            if (uc($configType) eq uc('Shares')) {
               if (my @diff = dbaSetDiff($savedConfigType,
                                         $currentConfigType)) {
                   $typeDiffRef->{$configType}->{Removed} = [ @diff ];
               }
               if (my @diff = dbaSetDiff($currentConfigType,
                                         $savedConfigType)) {
                   $typeDiffRef->{$configType}->{Added} = [ @diff ];
               }
            }

            # record audit level or authentication mode change
            if ( (uc($configType) eq uc('AuditLevel')) or 
                 (uc($configType) eq uc('AuthenticationMode')) ) {
                if ( uc($savedConfigType) ne 
                     uc($currentConfigType) ) {
                       $typeDiffRef->{$configType} =
                            $savedConfigType . " => " . $currentConfigType;
                }
            }
            
            # record changes to SQL registry permissions
            if (uc($configType) eq uc('RegistryPermissions')) {
               # if a user account is removed
               if (my @diff = dbaSetDiff([ keys %$savedConfigType ],
                                         [ keys %$currentConfigType ])) {
                   $typeDiffRef->{$configType}->{AccountRemoved} =
                                 [ @diff ];
               }
               # if a new user account is granted access
               if (my @diff = dbaSetDiff([ keys %$currentConfigType ],
                                         [ keys %$savedConfigType ])) {
                   $typeDiffRef->{$configType}->{AccountAdded} =
                                 [ @diff ];
               }
               # if access rights are changed for an account
               if (my @common = dbaSetCommon([ keys %$currentConfigType ],
                                             [ keys %$savedConfigType ])) {
                  foreach my $acct (@common) {
                    # record added rights
                    if (my @added = dbaSetDiff($currentConfigType->{$acct},
                                               $savedConfigType->{$acct})) {
                        $typeDiffRef->{$configType}->{$acct}->{PermsAdded} 
                              = [ @added ];
                    }
                    # record removed rights
                    if (my @removed = 
                                 dbaSetDiff($savedConfigType->{$acct},
                                            $currentConfigType->{$acct})) {
                       $typeDiffRef->{$configType}->{$acct}->{PermsRemoved}
                              = [ @removed ];
                     }
                  }
               }
            }
         }
         $diffRef->{$server}->{$instance} = $typeDiffRef if $typeDiffRef;
      }
   }
   return $diffRef;
} # compareSecurityConfig

###############################
sub printSecurityConfigDiff {
   my ($diffRef) = shift;
   ref($diffRef) or die "***Err: printSecurityConfigDiff() expects a reference.";
   
   foreach my $server (sort keys %$diffRef) {
      print "Server $server:\n";
      foreach my $instance (sort keys %{$diffRef->{$server}}) {
         print "\n\tInstance $instance:\n";
         my $instanceRef = $diffRef->{$server}->{$instance};
         foreach my $configType (sort keys %$instanceRef) {
            print "\t\t$configType: \n"; 
                 my $configRef = $instanceRef->{$configType};
                 
                 # print service account diff
                 if (uc($configType) eq uc('ServiceAccounts')) {
                     foreach my $service (sort keys %$configRef) {
                        print "\t\t\t$service : $configRef->{$service} \n";
                     }
                 }
                 
                 # print sysadmin membership diff
                 if (uc($configType) eq uc('SysadminMembers')) {
                     foreach my $delta (sort keys %$configRef) {
                        foreach my $login (@{$configRef->{$delta}}) {
                           print "\t\t\t$delta: $login \n";
                        }
                     }
                 }
                 
                 # print share diff
                 if (uc($configType) eq uc('Shares')) {
                     foreach my $delta (sort keys %$configRef) {
                        foreach my $share (@{$configRef->{$delta}}) {
                           print "\t\t\t$delta: $share \n";
                        }
                     }
                 }

                 if ((uc($configType) eq uc('AuditLevel')) or 
                     (uc($configType) eq uc('AuthenticationMode')) )   {
                     print "\t\t\t$instanceRef->{$configType} \n";
                 }

                 if (uc($configType) eq uc('RegistryPermissions')) {
                     foreach my $delta (sort keys %$configRef) {
                        if (uc($delta) eq uc('AccountAdded') or
                            uc($delta) eq uc('AccountRemoved')) {
                           print "\t\t\t$delta :  [ ";
                           foreach my $acct (sort @{$configRef->{$delta}}) {
                              print " $acct, ";
                           }
                           print " ]\n";
                        }
                        else {
                           print "\t\t\t$delta: \n";
                           foreach my $permDelta (sort 
                                             keys %{$configRef->{$delta}}) {
                              print "\t\t\t\t$permDelta : ";
                              foreach my $right (sort 
                                    @{$configRef->{$delta}->{$permDelta}}) {
                                 print " $right ";
                              }
                              print "\n";
                           }
                        }
                     }
                 }
         }
      }
   }
} # printSecurityConfigDiff

####################################
sub printCurrentSecurityConfig {
   my ($currentRef) = shift;
   ref($currentRef) or 
         die "***Err: printCurrentSecurityConfig() expects a reference.";
   
   foreach my $server (sort keys %$currentRef) {
      print "Server $server:\n";
      foreach my $instance (sort keys %{$currentRef->{$server}}) {
         print "\n\tInstance $instance:\n";
         my $instanceRef = $currentRef->{$server}->{$instance};
         foreach my $configType (sort keys %$instanceRef) {
            print "\t\t$configType: \n"; 
                 my $configRef = $instanceRef->{$configType};
                 
                 # print service accounts
                 if (uc($configType) eq uc('ServiceAccounts')) {
                     foreach my $service (sort keys %$configRef) {
                       print "\t\t\t$service => $configRef->{$service} \n";
                     }
                 }
                 
                 # print sysadmin members
                 if (uc($configType) eq uc('SysadminMembers')) {
                     foreach my $login (sort @$configRef) {
                       print "\t\t\t$login \n";
                     }
                 }
                 
                 # print shares
                 if (uc($configType) eq uc('Shares')) {
                     foreach my $share (sort @$configRef) {
                       print "\t\t\t$share \n";
                     }
                 }

                 # print audit level or authentication mode
                 if ((uc($configType) eq uc('AuditLevel')) or 
                     (uc($configType) eq uc('AuthenticationMode')) ) {
                     print "\t\t\t$instanceRef->{$configType} \n";
                 }
                 
                 # print registry permissions
                 if (uc($configType) eq uc('RegistryPermissions')) {
                     foreach my $login (sort keys %$configRef) {
                        print "\t\t\t$login :  [ ";
                        foreach my $perm (@{$configRef->{$login}}) {
                           print " $perm,";
                        }
                        print " ]\n";
                     }
                 }
         }
      }
   }
} # printCurrentSecurityConfig


__END__

=head1 NAME

TrackSecurityConfig - Tracking and alerting security configuration changes

=head1 SYNOPSIS

 cmd>perl TrackSecurityConfig.pl [-h] [-d] -c <configuration file>

    -h     print this usage info
    -s     save the current service accounts as the canonical config    
    -d     report changes to the SQL Server security configurations
    -c     specify a configuration file

=head1 DESCRIPTION

The script I<TrackSecurityConfig.pl> finds changes in any of the following SQL Server security
configuration areas:

=over

=item * 

Changes to the SQL Server service accounts

=item * 

Changes to the SQL Server authentication mode (also known as security mode)

=item *

Changes to the security audit level

=item *

Changes to the sysadmin membership

=item *

Changes to the network shares on a SQL Server machine

=item *

Changes to SQL Server registry permissions

=back

=head2 Configuration File

The script accepts a configuration file name on the command line. The following is an example:

 [Control]
 SecurityConfigLog=D:\DBA\SavedSecurityConfig.txt
 
 [SQL1]
 Instances=MSSQLServer, Apollo, Pantheon
 Disabled=no
 
 [SQL2]
 Instances=MSSQLServer, Jupiter
 Disabled=no

The option SecurityConfigLog under the Control section identifies the file that has 
the security configurations saved when the script was last run with the -c parameter.

=head2 Data Structure for Storing the Security Configurations

To understand how the script works, you need to first become familiar with its key 
data structure -- the one representing the security configurations -- because the entire script 
is built around this data structure. As an example, for the SQL Server default instance on the server SQL1, 
its security configurations, as referenced by I<$ref> in the function I<readCurrentSecurityConfig()>, 
may look like the following:

 $ref->{NYSQL01}->{MSSQLServer} = {
       ServiceAccounts => { MSSQLServer => 'SQL1\Lshea',
                            SQLServerAgent => 'LocalSystem'
                          },
            AuthenticationMode => 'Windows and SQL Server',
            AuditLevel => 'Failure',
            SysadminMembers => ['BUILTIN\Administrators', 
                                'SQL1\Lshea', 'NYDOMAIN\DBAs'],
            Shares => ['C$', 'D$', 'E$', 'ADMIN$', 'IPC$', 'Public'],
            RegistryPermissions => {
                         HKEY_LOCAL_MACHINE\Microsoft\MSSQLServer => {
                               Users => [ 'KEY_READ' ],
                               Administrators => [ 'KEY_READ', 'KEY_WRITE' ],
                               SYSTEM => [ 'KEY_READ', 'KEY_WRITE' ],
                               lshea  => [ 'KEY_READ' ],
                               'Power Users' => [ 'KEY_READ', 'KEY_WRITE' ]
                         }
                }
 };

Each top level key of this data structure -- such as ServiceAccounts or AuditLevel -- corresponds 
to an area of the SQL Server security configurations you want to track. 

This is how the data structure is populated:

=over

=item Service accounts

They are retrieved with the function I<dbaGetServiceAccount()> imported from the SQLDBA::Security 
module. The section "Retrieving the Service Accounts" in Chapter 3 covered this function.

=item Authentication mode

Running the T-SQL query EXEC master..xp_loginconfig 'login mode' returns the SQL Server 
authentication mode. The function I<dbaGetLoginConfig()>, also imported from the module 
SQLDBA::Security, runs xp_loginconfig to retrieve the login mode.

=item Audit level

The function I<dbaGetLoginConfig()> also returns the audit level of the SQL Server instance.

=item Sysadmin members

The first section of this chapter, "Listing Sysadmin Accounts and Logins," presented a script 
to obtain all the individual user accounts that have sysadmin privileges. To keep it manageable, 
the script I<trackSecurityConfig.pl> tracks only changes to the direct membership of the sysadmin role. 

=item Directory shares

Although you can use the Windows 2000/NT built-in command net share to enumerate shares locally 
and use net view to enumerate the shares remotely, they don't give you the complete list of 
shares on a remote machine. The function I<dbaGetShares()> calls I<NetShareEnum()> from Win32::Lanman 
to enumerate all the shares on a remote machine. 

=item Registry permissions

The script tracks only the permissions on the root registry key for a SQL Server instance. 
For the default SQL Server instance, the root registry key is HKEY_LOCAL_MACHINE\Microsoft\MSSQLServer, 
and for a named instance (for example, APOLLO), the root registry key is 
HKEY_LOCAL_MACHINE\Microsoft\Microsoft SQL Server\APOLLO. The function I<dbaGetSQLRegistryPerms()> 
uses the module Win32::Perms. This is a versatile module that can, among other things, report 
the Access Control List (ACL) of many common Windows objects. You can download Win32::Perms 
from http://www.roth.com.

=back


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


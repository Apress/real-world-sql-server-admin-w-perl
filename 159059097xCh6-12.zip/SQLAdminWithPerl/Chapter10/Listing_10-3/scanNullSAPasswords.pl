# See the embedded POD or teh HTML documentation

use strict;
use Win32::NetAdmin;
use Win32::OLE;
use Win32::Service;
use Getopt::Std;

my %opts;
getopts('lhmd:s:', \%opts);

if ($opts{h}) {
    printUsage();
    exit;
}
select((select(STDOUT), $| = 1)[0]); 

my @domains;
my @servers;

# now enumerate domains
Win32::NetAdmin::GetServers( '', '', SV_TYPE_DOMAIN_ENUM, \@domains);

foreach my $domain (sort @domains) {
   print scalar localtime(), "   *** Domain: $domain";

   # if there are any arguments
   if( $opts{d} ) {
      if( $opts{d} ne $domain) {
         # skip to next domain
         print " skipped\n";
         next;
      }
   }
   else {
      if ( $opts{s} ) {
         # if the specified domain hasn't been reached yet
         if( $opts{s} gt $domain) {
            # skip to next domain
            print " skipped\n";
            next;
         }
      }
   }
   print "\n";
   
   # now enumerate machines in the domain
   Win32::NetAdmin::GetServers( '', $domain, SV_TYPE_NT, \@servers);
   print "\t\t Found ", scalar @servers, " NT machines in this domain\n";
   
   foreach my $server (sort @servers) {
      if ($opts{m}) {
         print "\t\t Scanning machine $server\n";
      }
      next if $opts{l};
      my @nullSAInstances = findNullSAInstances($server);
      
      # print the instance names, if any
      foreach my $instance (@nullSAInstances) {
         print "\t\t\t$instance\n";
      }
   }
}

######################
sub printUsage {
######################
    print << '--Usage--';
Usage:
 perl ScanNullSAPasswords.pl [-h] [-d] [-l] [-m <domain name> | -s <domain name>]
                        when no arguments are specified, scan all 
                        domains and all NT/Win2K machines.

    -h                  print this usage info
    -l                  list the machines only. Do not scan for SQL Server
    -d<domain name>     scan machines in this domain only
    -s<domain name>     skip to this domain and start scanning in this domain
                        and all the subsequent domains
    -m                  list all the machines as they are being scanned.
--Usage--
} # printUsage

############################
sub findNullSAInstances {
############################
   my ($server) = shift;
   my @sqlServices;
   my @nullSAInstances;
   
   # first get all the SQL Server services
   my %Services;
   Win32::Service::GetServices($server, \%Services);
   @sqlServices = grep(/^\s*(MSSQLServer|MSSQL\$\w+)\s*$/i, keys %Services));

   # now test each instance with null sa password
   foreach my $service (@sqlServices) {
      # work with only the active service
      my %status;
      Win32::Service::GetStatus($server, $service, \%status);
      next if $status{'CurrentState'} != 4; # if not running
      
      
      # construct the server name on the connection string
      my $instance;
      if ($service =~ /^MSSQLServer$/i) {
         $instance = $server;
      }
      else {
         $service =~ /^MSSQL\$(.+)$/i;
         $instance = "$server\\$1";
      }
      
      # connect to the instance 
      my $db = Win32::OLE->new('ADODB.Connection');
      $db->{CoonectionTimeout} = 2;
      $db->Open("Driver={SQL Server};Server=$server;UID=$user;PWD=$password");
      my $err = Win32::OLE->LastError();
      if (!$err) {
           push @nullSAInstances, $instance;
           $db->Close;
      } 
      
   }
   return @nullSAInstances;
} # findNullSAInstances

__END__

=head1 NAME

scanNullSAPasswords - Scanning the network for SQL Server instances with null sa passwords

=head1 SYNOPSIS

 cmd>perl ScanNullSAPasswords.pl [-h] [-d] [-l] [-m <domain name> | -s <domain name>]
 
    when no arguments are specified, scan all domains and all NT/Win2K machines.

    -h                  print this usage info
    -l                  list the machines only. Do not scan for SQL Server
    -d<domain name>     scan machines in this domain only
    -s<domain name>     skip to this domain and start scanning in this domain
                        and all the subsequent domains
    -m                  list all the machines as they are being scanned.

=head1 DESCRIPTION

The script I<scanNullSAPasswords.pl> is almost identical to the script I<scanForSQLServer.pl>. 
Unfortunately, I<scanForSQLServer.pl> tries to log into only the default instance. It doesn't 
report the null sa passwords for any named instances. 

This script build on I<scanForSQLServer.pl> by first finding all the instances and then testing
each instance for null sa password by trying to logging into each instance as the sa login 
with no password. All tests are performed in the function I<findNullSAInstances()> which replaces
the function I<isSQLServer()>. The rest of the script is copy of I<scanForSQLServer.pl>. 

To find all the instances on a machine, the function I<findNullSAPasswords()> calls the I<GetServices()>
function of the module Win32::Service to get a list of all the services installed on the server, 
and then it filters for the service names that match the string MSSQLServer for the default 
SQL Server instance or the pattern MSSQL\$\w+ for the named SQL Server instances:

 # first get all the SQL Server services for the server
 my %Services;
 Win32::Service::GetServices($server, \%Services);
 @sqlServices = grep(/^\s*(MSSQLServer|MSSQL\$\w+)\s*$/i, keys %Services));

This code fragment finds all the SQL Server instances on that server. For each SQL Server instance, 
the script then calls the function I<Win32::Service::GetStatus()> to retrieve the current status 
of the instance: 

 Win32::Service::GetStatus($server, $service, \%status);
 next if $status{'CurrentState'} != 4; # if not running

Because you need to actually log in a SQL Server instance to check whether its sa password is null, 
it's  no use working with an inactive SQL Server instance. Thus, the script skips any SQL Server 
instance whose service status isn't running. Note that the current state of a service is identified 
with a numeric value. The number 4 in the if condition means that the service is currently running.

For each service the function I<findNullSAPasswords()> constructs the correct instance name to be 
used on the ADO connection string. The service MSSQLServer is the default instance, and you use the 
server name in the connection string. For the service MSSQL$<InstanceName>, you use 
<ServerName>\<InstanceName> in the connection string. The function makes an ADO connection 
via the module Win32::OLE to the SQL Server instance using the sa login with a null password. 
If this succeeds, the instance is recorded as having the null sa password.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


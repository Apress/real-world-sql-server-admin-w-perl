# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaReadINI dbaTime2str dbaStr2time );
use Data::Dumper;

Main: {
   my $configFile = shift;
   unless (-e $configFile) {
      print "***Err: Config file $configFile doesn't exist.\n";
      printUsage();
   }

   # Read config file into $configRef and validate it
   my $configRef = dbaReadINI($configFile);

   # Now scan errorlog and summarize login audit info
   foreach my $instance (sort keys %$configRef) {
     # scan errorlog and summarize login audit info
     my $auditRef = auditSummary($instance, $configRef);

     # Now print out the errorlog summary
     printAuditSummary($auditRef, $instance, $configRef);
   }
} # Main

######################
sub printUsage {
######################
    print << '--Usage--';
Usage:
 cmd>perl LoginAuditSummary.pl <configuration file>

--Usage--
   exit;
} # printUsage

########################
sub auditSummary {
########################
   my($instance, $configRef) = @_;
   die "***Err: auditSummary() expects an instance and a reference."
         unless ($instance && $configRef);

   my $ref;
   my $instConfigRef = $configRef->{$instance};

   # Check whether the file exists
   unless (-e $instConfigRef->{SQLERRORLOG}) { 
      print "***Err: Errorlog $instConfigRef->{SQLERRORLOG} doesn't exist."; 
      return; 
   }

   # now open the errorlog file for scan
   unless (open(LOG, $instConfigRef->{SQLERRORLOG})) {
      print "***Err: Could not open $instConfigRef->{SQLERRORLOG} for read."; 
      return;
   }

   # skip old errorlog entries
   while (<LOG>) {
      if (/^\s*([\d\/\-]+\s+[\d\.\:]+)\s+/) {
         next if ( (time() - dbaStr2time($1)) > 
                        $instConfigRef->{SCANERRORLOGLASTDAYS} * 24*3600 );
         $ref->{startCheckDatetime} = $1;
         last;
      }
   }

   # now start scan and summarize login audit entries
   while (<LOG>) {

     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+logon\s+
                       Login\s+(succeeded|failed)\s+for\s+user\s+
                       \'([^']+?)\'\.(.*)}ix) {
         my ($time, $status, $user, $trusted) = ($1, $2, $3, $4);
         my $conn = ($trusted =~ /trusted/i) ? 'trusted'
                                             : 'non-trusted';
         
         if ($instConfigRef->{INCLUDEUSER} =~ /^y/i) {
            # count audit entries for each user
            if ($status =~ /^succeeded/i) {
               $ref->{auditAccounts}->{$user}->{$status}->{$conn}->{time} = $time;
               $ref->{auditAccounts}->{$user}->{$status}->{$conn}->{count}++;
            }
            else {
               $ref->{auditAccounts}->{$user}->{$status}->{time} = $time;
               $ref->{auditAccounts}->{$user}->{$status}->{count}++;
            }
         }
         else {
            # do not count them for each user
            if ($status =~ /^succeeded/i) {
               $ref->{auditAccounts}->{$status}->{$conn}->{time} = $time;
               $ref->{auditAccounts}->{$status}->{$conn}->{count}++;
            }
            else {
               $ref->{auditAccounts}->{$status}->{time} = $time;
               $ref->{auditAccounts}->{$status}->{count}++;
            }
         }
         next;
     }
   }  
   close(LOG);
   return $ref;
}  # auditSummary
    
##############################
sub printAuditSummary {
##############################
   my($ref, $instance, $configRef) = @_;

   print "\nInstance $instance since $ref->{startCheckDatetime}\n";
   my $auditRef = $ref->{auditAccounts};
   
   if ($configRef->{$instance}->{INCLUDEUSER} =~ /y/i) {
      foreach my $acct (sort keys %$auditRef) {
         print "    $acct\n";
         foreach my $status (sort keys %{$auditRef->{$acct}}) {
            my $statusRef = $auditRef->{$acct}->{$status};
            if ($status =~ /succeeded/i) {
               # succeeded logins may be trusted or non-trusted
               foreach my $conn (sort keys %{$statusRef}) {
                  print "\t$conn connection $status \n";
                  print "\t\tCount: $statusRef->{$conn}->{count}\n";
                  print "\t\tLast attempt time: $statusRef->{$conn}->{time}\n";
               }
            }
            else {
               # The security mode of a failed login is not identified
               print "\tconnection $status \n";
               print "\t\tCount: $statusRef->{count}\n";
               print "\t\tLast attempt time: $statusRef->{time}\n";
            }
         }
      }
   }
   else {
      foreach my $status (sort keys %$auditRef) {
         if ($status =~ /succeeded/i) {
            # succeeded logins may be trusted or non-trusted
            foreach my $conn (sort keys %{$auditRef->{$status}}) {
               print "\t$conn connection $status \n";
               print "\t\tCount: $auditRef->{$status}->{$conn}->{count}\n";
               print "\t\tLast attempt time: ", 
                     "     $auditRef->{$status}->{$conn}->{time}\n";
            }
         }
         else {
            # The security mode of a failed login is not identified
            print "\tconnection $status \n";
            print "\t\tCount: $auditRef->{$status}->{count}\n";
            print "\t\tLast attempt time: $auditRef->{$status}->{time}\n";
         }
      }
   }
}  # printAuditSummary

__END__

=head1 NAME

loginAuditSummary - Summarizing SQL Server login audits

=head1 SYNOPSIS

 cmd>perl LoginAuditSummary.pl <config file>

=head1 DESCRIPTION

The script I<loginAuditSummary.pl> scans the SQL Server errorlogs to produce a simple summary by 
tallying the number of successful 
logins and the number of failed logins for a given time period. For the successful logins, the 
number is further divided into the number of Windows authenticated logins and the number of 
SQL Server authenticated logins. You can configure the script to further break down these numbers 
by each user account or SQL Server login.

This script accepts a configuration file that specifies a list of SQL Server instances whose 
login audits you want to summarize. For each SQL Server instance, the configuration file 
identifies the complete path to the SQL Server errorlog, the number of days going back from 
today in which login audits should be included in the summary, and whether the summary 
should include counts for each user account or SQL Server login. 

The following is a sample configuration file for two SQL Server instances, SQL1 and SQL2\APOLLO:

 [SQL1]
 SQLErrorlog=D:\MSSQL\LOG\Errorlog
 ScanErrorlogLastDays = 10
 IncludeUser=no
 
 [SQL2\APOLLO]
 SQLErrorlog=E:\MSSQL\MSSQL$APOLLO\log\Errorlog
 ScanErrorlogLastDays = 10
 IncludeUser=yes

With this configuration file, the script I<loginAuditSummary.pl> scans the SQL Server login audit 
entries recorded in the last 10 days (specified with I<ScanErrorlogLastDays = 10>) in the 
errorlogs of the two SQL Server instances, SQL1 and SQL2\APOLLO, both of which are listed in 
the section headings of the configuration file. In addition, for the SQL1 default instance, 
because the option I<IncludeUser> is set to I<no>, the configuration file instructs the script not 
to tally the login attempts for either the Windows user account or SQL Server login. 

Run the script I<loginAuditSummary.pl> on the command line as follows with the above configuration 
options to its output: 

 cmd>perl loginAuditSummary.pl config.txt

You'll receive a summary report that may look like the following:

 Instance SQL1 since 2002-07-04 22:44:46.90
       connection failed 
            Count: 2
            Last attempt time: 2002-07-04 22:51:00.01
       trusted connection succeeded 
            Count: 12
            Last attempt time: 2002-07-04 23:02:40.34
 
 Instance SQL2\APOLLO since 2002-07-04 21:41:47.14
     SQL2\mshea
         connection failed 
               Count: 1
               Last attempt time: 2002-07-04 22:46:53.62
     NJRES\vshea
         trusted connection succeeded 
               Count: 10
               Last attempt time: 2002-07-04 22:26:55.61
     sa
         connection failed 
               Count: 102
               Last attempt time: 2002-07-04 22:47:17.20

The heart of the script is the function I<auditSummary()>, which scans the errorlog of a given SQL 
Server instance for login audit entries and records the login counts in a nested hash structure. 
An example of the hash structure for the instance SQL1 may look like the following:

 $ref = {
    startCheckDatetime => '2002-07-04 22:44:46.90',
    auditAccounts => {
               failed => {
                         count => 2,
                         time => '2002-07-04 22:51:00.01'
               },
               succeeded => {
                         trusted => {
                                  count => 12,
                                  time => '2002-07-04 23:02:40.34'
                         }
               }
    }
 };


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


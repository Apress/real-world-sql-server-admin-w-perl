# See the embedded POD or the HTML documentation

use strict;

# Import the function from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaReadINI );

# Read the list of server names from the config file
my @servers = getServers();

my $shareRef;
foreach my $server (sort @servers) {
   my @srvcheck = `srvcheck.exe \\\\$server 2>&1`;  # run the NT Reskit utility srvcheck.exe
   my $share;
   foreach (@srvcheck) {
      if ($_ =~ /^\s*(\\\\.+)/) {
         $share = $1;
         $share =~ s/\s*$//;
      }
      if ($_ =~ /^\s*(Everyone).+(Full\s+control|Change)/i) {
         push @{$shareRef->{$server}->{$share}}, "$1 : $2";
      }
   }
}

# print the open shares
foreach my $server (sort keys %$shareRef) {
   print "Server: $server\n";
   foreach my $share (sort keys %{$shareRef->{$server}}) {
      print "\tShare: $share\n";
      foreach my $perm (sort @{$shareRef->{$server}->{$share}}) {
            print "\t\t$perm\n";
      }
   }
}

#################
sub getServers {
   my $configFile = $ARGV[0] or die "***Err: getServers() expects a file.";
   my $configRef = dbaReadINI($configFile);
   my @servers;

   foreach my $instance (keys %$configRef) {
      next if $instance =~ /^CONTROL$/i;
      $instance =~ s/\\.+//;
      push @servers, $instance if !grep(/^$instance$/, @servers);
   }
   return @servers;
} # getServers

__END__

=head1 NAME

findOpenShares - Finding wide open shares

=head1 SYNOPSIS

 cmd>perl findOpenShare.pl <config file>

=head1 USAGE EXAMPLE

The following is an example of running the script I<findOpenShares.pl> with a 
configuration file in which the server names are in the section headings. 
The other options in the configuration file are not relevant.

 cmd>perl findOpenShares.pl config.txt
 
 Server: SQL1
       Share: \\SQL1\sqlbackup
               Everyone : Full Control
 Server: SQL2
       Share: \\SQL2\temp$
               Everyone : Change
       Share: \\SQL2\datatemp$
               Everyone : Full Control
 Server: SQL2
       Share: \\SQL2\FtpTemp
               Everyone : Full Control

In this example, the script I<findOpenShares.pl> found three servers -- among all the servers listed 
in the file config.txt -- that have shares giving everyone full control or allowing everyone 
to make changes. You should investigate whether these shares should be there and whether the 
permissions are warranted.


=head1 DESCRIPTION

The script I<findOpenShare.pl> accepts a configuration file name on the command line. It loops 
through the servers specified in the configuration file. For each server, the script runs the NT/2000
resource kit utility I<srvcheck.exe> to enumerate the shares and retrieve the permissions on the
shares.

The following is an example of running I<srvcheck.exe> to find the shares and their access 
permissions on the server SQL1:

 cmd>srvcheck \\SQL1
 \\SQL1\Backup
                 NYDomain\SQLDBAS       Read
                 NYDomain\lshea         Read
                 Everyone               Read
 
 \\SQL1\Remote
                 BUILTIN\Administrators    Full Control
 
 \\SQL1\sqlbackup
                 Everyone                  Full Control

For some groups such as the local administrators, having full control over a share is 
expected. What should be of concern are the shares that have been granted Change or 
Full Control to Everyone. On a sensitive server, you may want to question whether Everyone 
should indeed be granted Read access.

The script uses Perl's backtick operator to run I<srvcheck.exe> with the server that's currently 
being worked on in the foreach loop, and then it assigns the results to the array I<@srvcheck>. 
Because this forces the backtick operator to be evaluated in list context, the results are 
split by newline, and each line becomes an element of the array I<@srvcheck>. 

The script then goes through each element in I<@srvcheck>, looking for share names, user accounts, 
and access permissions. In particular, for each share, the script searches for user Everyone 
and permissions Change or Full Control. It records the share name, the user account, and the 
access permissions that match the search pattern in a data structure referenced by I<$shareRef>.

Finally the script prints the information recorded in the data structure I<$shareRef>.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


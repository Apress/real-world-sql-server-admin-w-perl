# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaReadINI dbaReadSavedRef dbaSaveRef );

# Import the function from the module SQLDBA::Security
use SQLDBA::Security qw( dbaGetServiceAccount );
use Getopt::Std;

Main: {
   my $diffRef;

   my %opts;
   getopts('sdc:', \%opts);

   my $file = $opts{c} or die "***Err: $0 expects a config file name.";
   my $configRef = dbaReadINI($file);

   foreach my $server (keys %$configRef) { # skip the disabled server
      delete $configRef->{$server} if $configRef->{$server}->{DISABLED} =~ /y/i;
   }
   my $currentRef = readCurrentAccounts($configRef);
 
   if ($opts{d}) {  # check for any difference from the canonical
      my $savedRef = dbaReadSavedRef($configRef->{CONTROL}->{SERVICEACCOUNTLOG});

      if ($savedRef) {
         $diffRef = compareAccounts($currentRef, $savedRef);
      }
      if ($diffRef) {
         printAccountDiff($diffRef);
      }
      else {
         print "***Msg: No change to SQL Server service accounts.\n";
      }
   }
   else {
      printCurrentAccounts($currentRef);
   }
   
   if ($opts{s}) { # save the current configuration as canonical
      dbaSaveRef($configRef->{CONTROL}->{SERVICEACCOUNTLOG}, $currentRef, 'ref');                 
   }
} # Main


############################
sub readCurrentAccounts {
   my $configRef = shift;
   ref($configRef) or die "***Err: readCurrentAccounts() expects a reference.";
   my $ref;
         
   foreach my $server (sort keys %$configRef) {
      next if uc($server) eq 'CONTROL';
      foreach my $instance (sort split /\s*,\s*/, 
                                       $configRef->{$server}->{INSTANCES}) {

         my @services;
         if (uc($instance) eq uc('MSSQLServer')) { # they're case insensitive
            push @services, uc('MSSQLServer');
            push @services, uc('SQLServerAgent');
         }
         else {
            push @services, 'MSSQL$' . uc($instance);
            push @services, uc('SQLAgent$') . uc($instance);
         }

         foreach my $service (sort @services) {
            #get the current service accounts
            $ref->{$server}->{uc($instance)}->{$service} 
                     = dbaGetServiceAccount($server, $service);
         }
      }
   }
   return $ref;
} #readCurrentAccounts

#########################
sub compareAccounts {
   my($currentRef, $savedRef) = @_;
   my $diffRef;

   foreach my $server (keys %$currentRef) {
      next if !exists $savedRef->{$server};
      foreach my $instance (keys %{$currentRef->{$server}}) {
         next if !exists $savedRef->{$server}->{$instance};
         foreach my $service (keys %{$currentRef->{$server}->{$instance}}) {
            next if !exists $savedRef->{$server}->{$instance}->{$service};
            if ( uc($currentRef->{$server}->{$instance}->{$service}) ne 
                 uc($savedRef->{$server}->{$instance}->{$service})) {
               $diffRef->{$server}->{$instance}->{$service} = 
                   $savedRef->{$server}->{$instance}->{$service} . ' => ' .
                   $currentRef->{$server}->{$instance}->{$service};
            }
         }
      }
   }
   return $diffRef;
} # compareAccounts

#########################
sub printAccountDiff {
   my ($diffRef) = shift;
   ref($diffRef) or die "***printAccountDiff expects a reference.";
   
   foreach my $server (sort keys %$diffRef) {
      print "Server $server:\n";
      foreach my $instance (sort keys %{$diffRef->{$server}}) {
         print "  Instance $instance:\n";
         foreach my $service (sort keys %{$diffRef->{$server}->{$instance}}) {
            print "    Service account change ($service): ", 
                      $diffRef->{$server}->{$instance}->{$service}, "\n";
         }
      }
   }
} # printAccountDiff

############################
sub printCurrentAccounts {
   my ($currentRef) = shift;
   ref($currentRef) or die "***printCurrentAccounts expects a reference.\n";
   
   foreach my $server (sort keys %$currentRef) {
      print "Server $server:\n";
      foreach my $instance (sort keys %{$currentRef->{$server}}) {
         print "  Instance $instance:\n";
         foreach my $service (sort keys %{$currentRef->{$server}->{$instance}}) {
            print "    ($service): ", 
                      $currentRef->{$server}->{$instance}->{$service}, "\n";
         }
      }
   }
} # printServiceAccounts

#########################
sub readSrvAccount_sc {
   my ($server, $service) = @_;
   
   my $srvConfig = `sc \\\\$server qc $service`;
   my ($account) = $srvConfig =~ /SERVICE_START_NAME\s*:\s*(.+)$/i;
   $account =~ s/\s+$//;
   $account =~ s/\.\\/$server\\/;
   return $account;
} # readSrvAccount_sc

__END__

=head1 NAME

trackSQLAccounts - Tracking SQL Server service accounts

=head1 SYNOPSIS

 cmd>perl trackSQLAccounts <config file>

=head1 DESCRIPTION

The script I<trackSQLAccounts.pl> allows a DBA to perform the following tasks on a group of 
SQL Server instances specified in a configuration file:

=over

=item *

Produce a list of the service accounts

=item *

Report whether a SQL Server service has been changed to run under a different user account

=back

The script retrieves the service account for a service using the function I<dbaGetServiceAccount()>
imported from the module SQLDBA::Security, which in turn relies on the I<QueryServiceConfig()>
function of the Win32::Lanman module. For change tracking, the script saves a snapshot of 
the service account configurations consisting of the service accounts and their corresponding 
services, instances, and servers. It then compares the current snapshot of the SQL Server 
service account configurations with the saved configurations to identify whether any 
change has been introduced.

=head2 Configuration File

The following is a sample configuration file that I<trackSQLAccounts.pl> accepts.

 [Control]
 ServiceAccountLog=D:\DBA\SavedAccounts.txt
 
 [SQL1]
 Instances=MSSQLServer, APOLLO, PANTHEON
 Disabled=no
 
 [SQL2]
 Instances=MSSQLServer, JUPITER
 Disabled=no

The Control section of the configuration file instructs I<trackSQLAccounts.pl> to read 
the previously saved snapshot of the service accounts from the file I<D:\DBA\SavedAccounts.txt>. 
The current snapshot, created by retrieving the configuration information directly from the 
servers, is saved to this same file if you specify the -s command-line parameter. 

With the exception of the Control section, server names are listed in the section headings. 
As specified in the above example, the script tracks changes to the service accounts of 
the default SQL Server instance, the named instance APOLLO, and the named instance PANTHEON 
on the server SQL1. Similarly, the script also tracks the service accounts of the named 
instance JUPITER and the default instance on the server SQL2.

=head2 The Hashes $currentRef and $savedRef for the Service Accounts

The key to the script is two data structures, I<$currentRef> and I<$savedRef>. The former 
records the current 
service accounts retrieved from the servers, and the latter records the information 
read from the saved service accounts in the file identified by the ServiceAccountLog 
option in the configuration file. Note that $savedRef represents the snapshot of the 
service accounts saved the last time when you ran the script I<trackSQLAccounts.pl> with 
the -s command-line switch.

These two data structures are the same in terms of their structures. For the configuration file shown above, 
I<$currentRef> looks like the following:

 $currentRef = {
      'SQL1' => {                                         # server
           'PANTHEON' => {                                # instance
                  'SQLAGENT$PANTHEON' => 'LocalSystem',   # SQLAgent service
                  'MSSQL$PANTHEON'    => 'SQL1\\lshea'    # SQL Server service
           },
           'APOLLO' => {
                  'SQLAGENT$APOLLO' => 'SQL1\\lshea',
                  'MSSQL$APOLLO'    => 'SQL1\\lshea'
           },
           'Mssqlserver' => {
                  'SQLSERVERAGENT' => 'SQL1\\lshea',
                  'MSSQLSERVER'    => 'LocalSystem'
           }
      }
      'SQL2' => {
           'JUPITER' => {
                  'SQLAGENT$PANTHEON' => 'LocalSystem',
                  'MSSQL$JUPITER'     => 'NJDOMAIN\\lshea'
           },
           'MSSQLSERVER' => {
                  'SQLSERVERAGENT' => 'NJDOMAIN\\lshea',
                  'MSSQLSERVER'    => 'NJDOMAIN\\lshea'
           }
      }
 };

The data structure I<$currentRef> is populated with the function I<readCurrentAccounts()>. The 
bulk of the work in this function is to get all the services for each server into the array 
@services. Then, for each service, the function I<dbaGetServiceAccount()> from the module 
SQLDBA::Security retrieves the user account that runs the service. Chapter 3�s "Retrieving the 
Service Accounts" section discussed the code of this function.

The data structure I<$savedRef> is populated with the function I<dbaReadSavedRef()> 
imported from the module SQLDBA::Utility, which opens the file specified with the 
configuration option ServiceAccountLog and evaluates the content to a reference. The reference 
is then assigned to I<$savedRef> in the main body of the script. If the -s command-line 
switch is specified, the file is overwritten with the current snapshot in I<$currentRef> using 
the function I<dbaSavedRef()> from the module SQLDBA::Utility, thus persisting the current 
snapshot as the canonical configurations for later comparison.

Once the script has these two hash structures populated, finding any change to the service 
accounts is a matter of traversing through each server, instance, and service, and comparing the 
service account of the corresponding service.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


use pubs
go

dbcc traceon(3604)
dbcc page(5, 1, 160, 3)

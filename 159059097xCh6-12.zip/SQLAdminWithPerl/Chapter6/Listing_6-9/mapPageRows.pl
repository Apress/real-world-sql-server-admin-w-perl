# See the embedded POD or the HTML documentation

use strict;
use Win32::OLE 'in';
use Getopt::Std;
use Data::Dumper;

my %opts;
getopts('s:d:t:', \%opts);  # specify the expected command line arguments
(defined $opts{s} and defined $opts{d} and defined $opts{t}) or printUsage();

MAIN: {
   my ($server, $db, $tab) = ($opts{s}, $opts{d}, $opts{t});
   print scalar localtime(), "\n";
   
   # open a connection to the server and database
   my $conn = getConn($server, $db);

   # get the PK column(s)
   my $pkRef = getPKRef($conn, $tab);
   unless (scalar @$pkRef) {
      die "***Err: table $tab doesn't have a primary key.";
   }
   # get all the page IDs of the table
   my $allPageIDsRef = getAllPageIDs($conn, $db, $tab);

   # for each page ID, get all the rows on the page
   my ($msgRef, $rowRef, $page2Rows);
   foreach my $pageID (@$allPageIDsRef) {
      my ($fileno, $pageno) = $pageID =~ /(\d+)\:(\d+)/;

      #get the result of DBCC PAGE to an array
      $msgRef = dbccPage($conn, $db, $fileno, $pageno);

      # get the PK values of the rows on a page
      $rowRef = getRows($pkRef, $msgRef);

      # get mapping from page ID to the PK values on the page
      $page2Rows->{$pageID} = [sort keys %$rowRef];
   }
   $conn->Close();
   print Data::Dumper->Dump([$page2Rows], ['mapPage2Rows']);      
}

#####################
sub printUsage {
   print <<___Usage;
Usage:
   cmd>perl mapPageRows.pl  -s <SQL Server instance> 
                            -d <database> 
                            -t <table> 
___Usage
   exit;
} # printUsage

#####################
#  get an ADO connection to be used throughout the script
sub getConn {
   my ($server, $db) = @_;
   
   my $conn = Win32::OLE->new('ADODB.Connection') or 
         die "***Err: Win32::OLE->new() failed.";
   $conn->{ConnectionTimeout} = 4;
   my $connStr = "Provider=sqloledb;Server=$server;" .
                 "database=$db;Trusted_Connection=yes";
   $conn->Open($connStr);
   ! Win32::OLE->LastError() or die Win32::OLE->LastError();

   $conn->Execute('dbcc traceon(3604)') or
      die Win32::OLE->LastError();
   return $conn;  # this connection will be reused until the script exits
}  # getConn

#######################
#  get the DBCC PAGE output to an array
sub dbccPage {
   my ($conn, $db, $fileNo, $pageNo) = @_;
   my @msgs;
   
   my $sql = "declare \@dbid int
              set \@dbid = db_id(\'$db\')
              dbcc page(\@dbid,$fileNo,$pageNo,3)";
   $conn->Execute($sql) or
      die Win32::OLE->LastError();
      
   # note that ADO returns DBCC output in Errors collection
   # unless you specify with tableresults
   foreach my $err (in($conn->Errors())) {
      my $msg = $err->{Description}; # it's in the Description property
      $msg =~ s/\s*$//;
      push @msgs, $msg;
   }
   return \@msgs; # contains the DBCC PAGE output
}  # dbccPage

########################
# get the rows, identified by the PKs, for the page from
# the page info dumped by DBCC PAGE
sub getRows {
   my ($pkRef, $msgRef) = @_;  # take PK columns and DBCC PAGE output
   
   my $rowCnt;          # for validation purpose
   my $pageHeader = 0;  # to signal whether the loop is in the header part
   my ($page, $slot, $offset);
   my $rowRef;
   foreach my $msg (@$msgRef) {
      $msg =~ /\s*PAGE:\s+\((.+)\)/i and $page = $1;  # e.g. PAGE: (1:160)
      
      # if matched, entering the page header
      if ($msg =~ /^\s*PAGE\s+HEADER:/i) {
         $pageHeader = 1; 
         next;
      }
      # if matched, left the page header
      if ($msg =~ /^\s*Allocation\s+Status/i) {
         $pageHeader = 0;
         next;
      }
      
      # get the slot count (i.e. row count) from the header
      # the actual row count should match this number if our search works.
      # Otherwise, sth went wrong and the result shouldn't be used
      if ($pageHeader and $msg =~ /m\_slotCnt\s*=\s*(\d+)/i) {
         $rowCnt = $1;
         next;
      }
      
      if ($msg =~ /^\s*Slot\s+(\d+)\s+Offset\s+0x\w+/i) {
         $slot = $1;
         next;
      }
      foreach my $key (@$pkRef) {
         if ($msg =~ /^\s*$key\s*=\s*(.+?)\s*$/i) {
            push @{$rowRef->{$slot}}, $1;
         }
      }
   }
   # actual row count should match the slot count in the header
   my $actualRowCnt = scalar (keys %$rowRef);
   print "Page: $page, Header slot cnt \= $rowCnt, ", 
            "actual row cnt \= $actualRowCnt\n";
   ($rowCnt == $actualRowCnt) or 
      die "***Err: parsing DBCC PAGE output encountered problem.";
   my $r_rowRef;
   foreach my $slotNo (keys %$rowRef) {
      # concatenate the PK key values if it's composite
      my $pk_concat = join('/', @{$rowRef->{$slotNo}});
      # reverse key/value
      $r_rowRef->{$pk_concat} = $slotNo;
   }
   return $r_rowRef;  # concatenated PK values is key, slot # is value
}  # getRows

#############################
#  get all the page IDs of a table
sub getAllPageIDs {
   my ($conn, $db, $tb) = @_;
   
   my $sql ="DECLARE \@db int, \@obj int
             SELECT \@db = db_id(\'$db\'), \@obj = object_id(\'$tb\')
             DBCC IND(\@db, \@obj, 1)";

   my $rs = $conn->Execute($sql) or
      die Win32::OLE->LastError();

   my @resultset = ();
   while ( !$rs->{EOF} ) {
      if ($rs->Fields('PageType')->{Value} != 1) {
         $rs->MoveNext;
         next;
      }
      my $pageID = $rs->Fields('PageFID')->{Value} .':' .
                   $rs->Fields('PagePID')->{Value};
      push @resultset, $pageID;
      $rs->MoveNext;
   }
   return \@resultset;
}  # getAllPageIDs

#######################
#   get the PK columns
sub getPKRef {
   my ($conn, $tab) = @_;
   
   my $sql = "SELECT kc.column_name
                FROM information_schema.key_column_usage kc,
                     information_schema.table_constraints tc
               WHERE kc.table_name = \'$tab\'
                 AND kc.table_schema = \'dbo\'
                 AND kc.table_name = tc.table_name
                 AND kc.table_schema = tc.table_schema
                 AND kc.constraint_name = tc.constraint_name
                 AND kc.constraint_schema = tc.constraint_schema
                 AND tc.constraint_type = 'PRIMARY KEY'
               ORDER BY kc.ordinal_position";

   my $rs = $conn->Execute($sql) or
      die Win32::OLE->LastError();

   my @resultset = ();
   while ( !$rs->{EOF} ) {
      push @resultset, $rs->Fields('column_name')->{Value};
      $rs->MoveNext;
   }
   return \@resultset;
}  # getPKRef


__END__

=head1 NAME

mapPageRows - Finding the page/row mapping

=head1 SYNOPSIS

   cmd>perl mapPageRows.pl  -s <SQL Server instance> 
                            -d <database> 
                            -t <table> 

=head1 USAGE EXAMPLE

 cmd>perl mapPageRows.pl -s .\apollo -d northwind -t Customers
 
 Sun Apr 27 01:55:12 2003
 Page: 1:131, Header slot cnt = 32, actual row cnt = 32
 Page: 1:392, Header slot cnt = 29, actual row cnt = 29
 Page: 1:393, Header slot cnt = 30, actual row cnt = 30
 $mapPage2Rows = {
                  '1:131' => [
                               'ALFKI',
                               'ANATR',
                               ...
                               'GREAL'
                             ],
                  '1:392' => [
                               'GROSR',
                               'HANAR',
                               ...
                               'QUEDE'
                             ],
                  '1:393' => [
                               'QUEEN',
                               'QUICK',
                               ...
                               'WOLZA'
                             ]
                 };


=head1 DESCRIPTION

This script shows how to find the mapping between the pages and the rows. A page is identified with
a page ID, which has the format of I<FileNumber:PageNumber>. Both FileNumber and PageNumber are 
integers. A row is identified with its primary key value. 

For instance, in the previous usage example,
1:131 represents a page, and 'ALFKI' is the primary key value of a row in the table 
I<northwind.dbo.Customer>. This row is physically located on the page 1:131.

=head2 MAPPING FROM PAGE TO ROWS

To find the mapping from a page to its rows, the script runs the DBCC PAGE command and parses
the output for the row information. For instance, to get the row information of the page 1:160 
in the I<pubs..authors> table, you can issue the following T-SQL command:

 DBCC TRACEON(3604)
 DBCC PAGE(5, 1, 160, 3)

In this DBCC PAGE command, the database number of pubs is 5 and the page ID of the 
authors table is 1:160.

The function I<dbccPage()> defined in the script captures the DBCC PAGE output, and the function
I<getRows()>, also defined in the script, extracts the row information in terms of their 
primary key values, from the output.

=head2 MAPPING FROM A ROW TO THE PAGE

Given a row in a table, there�s no straightforward way to find the page on which 
it�s stored. However, if you scan every page of the table for the rows on that page and 
record the mapping, you�ll be able to find the row and therefore the page on which it�s stored.

Now, the question becomes "How do you identify all the data pages used by a table?" You can use 
the undocumented DBCC TAB command or the undocumented DBCC IND command. 

The following is a partial output of the DBCC IND command when it�s applied to the 
I<Northwind..Customers> table. In the example shown, several nonessential columns have been 
removed from the output. 

 PageFID PagePID IndexID PageType NextPageFID NextPagePID PrevPageFID PrevPagePID
 ------- ------- ------- -------- ----------- ----------- ----------- -----------
 1       110     1       10       0           0           0           0 
 1       109     1       2        0           0           0           0 
 1       111     0       1        1           128         0           0
 1       128     0       1        1           129         1           111
 1       129     0       1        0           0           1           128

The important points to note about the above tabular output are the following:

=over

=item *

PageFID refers to the file number of the page, and PagePID refers to the page number. 
Thus, PageFID:PagePID forms the page ID.

=item *

PageType identifies the type of the page. For a data page, this value is set to 1. 
Note a leaf page of a clustered index is considered a data page; thus, its PageType is set to 1. 
For a data page in a heap table, its PageType is set to 0.

=back

Therefore, in this example the Northwind..Customers table has three data pages in total. 
They are 1:111, 1:128, and 1:129. Applying DBCC PAGE to each of these three pages gives you 
complete information on where a row is physically located.

The function getAllPageIDs() defined in the script executes the DBCC IND command on the 
table whose name is passed to the function as a parameter, and it retrieves the page 
IDs of all the data pages in the table into an array. 

=head1 WHY BOTHER?

If you're wondering why you should even bother with such a mapping, consider the 
following questions:

=over

=item *

If you delete all the rows between HANAR and QUEDE, will the remaining rows stay on the page 1:392?

=item *

How do the pages look if you add another 20 rows to the Customers table?

=item *

If you add a row to cause a page split, how does SQL Server redistribute the existing rows 
for the page split?

=back

You can easily answer these questions by running the script I<mapPageRows.pl>. If you want to 
study the storage impact of an operation, you can do the following: 

=over

=item 1

Run the script and record the result, which is the pre-operation snapshot.

=item 2

Perform the operation.

=item 3

Run the script again and record the new result, which is the post-operation snapshot.

=item 4

Compare the two results to determine what effect, if any, the operation has on the placement 
of the rows on the pages. 

=back

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.01.27

=cut

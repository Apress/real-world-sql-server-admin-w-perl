# See the embedded POD or the HTML documentation

use strict;
use Win32::OLE 'in';
use Data::Dumper;

my $server = $ARGV[0] or die "***Err: $0 expects a server name.";
my $t1200Log = $ARGV[1] or die "***Err: $0 expects a T1200 log file.";

# open a connection to the server
my $conn = getConn($server);

my ($ref, $locking, $mode, $type, $rsc, $objName);
open(TLOG, $t1200Log) or die "***Err: failed to open $t1200Log.";
while(<TLOG>) {
   if (/acquiring\s+(\w+\s+lock\s+on\s+\w+)\:\s*([:\d]+)/i) {
      ($locking, $rsc) = ($1, $2);

      # working on TAB, KEY, and IDX locks
      if ($locking =~ /(TAB|KEY|IDX)$/i) {
         if ($rsc =~ /(\d+)\:(\d+)/) {
            my ($dbid, $objid) = ($1, $2);
            if ($dbid !~ /\d+/ or $objid !~ /\d+/) {
               die "***Err: didn't match dbid or objid.";
            }
            $objName = getObjName($conn, $dbid, $objid);
         }
         else {  # error condition, should never reach here
            die "***Err: lock resource didn't match /(\d+)\:(\d+)/.";
         }
         $ref->{$objName}->{$locking}++;
         next;
      }
      
      # working on PAG and RID
      if ($locking =~ /(PAG|RID)$/i) {
         if ($rsc =~ /(\d+)\:(\d+)\:(\d+)/) {
            my ($dbid, $fileNo, $pageNo) = ($1, $2, $3);
            my $objid = dbccPage2objID($conn, $dbid, $fileNo, $pageNo);
            if ($objid !~ /^\d+$/) {
               die "***Err: dbccPage2objID() didn't return an object no.";
            }
            $objName = getObjName($conn, $dbid, $objid);
         }
         else {  # error condition, should never reach here
            die "***Err: lock resource didn't match /(\d+)\:(\d+)\:(\d+)/.";
         }
         $ref->{$objName}->{$locking}++;
         next;
      }
      print;   # print the rows that don't match as is
   }
}
close(TLOG);
$conn->Close();
print Data::Dumper->Dump([$ref], ['LockSummary']);

#####################
#  get an ADO connection to be used throughout the script
sub getConn {
   my $server = shift or die "***Err: getConn() expects a server name.";
   
   my $conn = Win32::OLE->new('ADODB.Connection') or 
         die "***Err: Win32::OLE->new() failed.";
   $conn->{ConnectionTimeout} = 4;
   my $connStr = "Provider=sqloledb;Server=$server;Trusted_Connection=yes";
   $conn->Open($connStr);
   ! Win32::OLE->LastError() or die Win32::OLE->LastError();

   $conn->Execute('dbcc traceon(3604)') or  # see trace output to the client
      die Win32::OLE->LastError();
   return $conn;  # this connection will be used in the rest of the script
}  # getConn

#######################
#  get the objetc name from DBCC PAGE output 
sub dbccPage2objID {
   my ($conn, $dbid, $fileNo, $pageNo) = @_;
   my @msgs;
   my $objid;
   
   my $sql = "dbcc page($dbid,$fileNo,$pageNo, 0)";
   $conn->Execute($sql) or
      die Win32::OLE->LastError();
      
   # note that ADO returns DBCC output in Errors collection
   # unless you specify with tableresults
   foreach my $err (in($conn->Errors())) {
      my $msg = $err->{Description}; # it's in the Description property
      if ($msg =~ /m\_objId\s*=\s*(\d+)\b/i) {
         return $1;
      }
   }
   return undef;
}  # dbccPage2objID

####################
sub getObjName {
   my ($conn, $dbid, $objid) = @_;
   
   my $sql = "DECLARE \@db varchar(256), \@sql varchar(500)
              SET \@db = QUOTENAME(db_name($dbid))
              SET \@sql = 'USE ' + \@db + 
                          'SELECT ''name'' = QUOTENAME(name), 
                                  ''user'' = QUOTENAME(USER_NAME(uid))
                             FROM sysobjects 
                            WHERE id = $objid'
              EXEC (\@sql)";
   my $rs = $conn->Execute($sql) or
      die Win32::OLE->LastError();

   while ($rs) {
      unless ( $rs->{State} ) {
         $rs = $rs->NextRecordSet();
         next;
      }
      while ( !$rs->{EOF} ) {
         my $name = $rs->Fields('name')->{Value};
         my $user = $rs->Fields('user')->{Value};
         $name =~ s/\s*$//;
         $user =~ s/\s*$//;

         if ($name and $user) {
            return "$user:$name";
         }
         $rs->MoveNext;
      }
      $rs = $rs->NextRecordSet();
   }
   return undef;
} # getObjName


__END__

=head1 NAME

postT120 - Summarizing the output of the trace flag 1200

=head1 SYNOPSIS

   cmd>perl postT1200.pl  <SQL Server instance> <T1200 output file>

=head1 USAGE EXAMPLE

Let us run the following T-SQL queries in the pubs database to insert a row into the authors 
table and save the output to the file I<t1200_insert.log>:

 DBCC TRACEON(3604, 1200)
 INSERT authors
 VALUES('111-32-1176', 'Shea', 'Linchi', '408 496-7223', '10932 Bigge Rd.', 'Menlo Park', 'CA', '94025', 1)

Even for this simple query, the output of the trace flag 1200 is voluminous, containing some 253 
lines. You can run the script I<postT1200.pl> to produce a summary of the acquired locks as 
shown below:

 cmd>perl postT1200.pl t1200_insert.log
 $LockSummary = {
             '[dbo]:[authors]' => {
                                'X lock on KEY'      => '3',
                                'Schema lock on TAB' => '1',
                                'IX lock on TAB'     => '1',
                                'IX lock on PAG'     => '3'
                 },
                 ...
                 '[dbo]:[sysindexes]' => {
                                           'S lock on RID'  => '3',
                                           'S lock on KEY'  => '14',
                                           'IS lock on PAG' => '3'
                                         },
                 ...
                 '[dbo]:[systypes]' => {
                                         'S lock on KEY' => '9'
                                       },
                 '[dbo]:[syscomments]' => {
                                            'S lock on KEY' => '7'
                                          },
                 '[dbo]:[sysusers]' => {
                                         'S lock on KEY' => '14'
                                       },
                 '[dbo]:[syscolumns]' => {
                                           'S lock on KEY' => '48'
                                         },
                 '[dbo]:[sysobjects]' => {
                                           'S lock on KEY' => '57'
                                         },
                  ...
 };

The summary result shows that the insert statement placed the following locks on the I<authors> table:

=over

=item *

Three exclusive row-level locks (actually they are KEY locks because of the clustered index), 

=item *

Three intent exclusive page locks, 

=item *

One intent exclusive table lock, and 

=item *

A schema lock. 

=back

In addition, 
the insert statement acquires row- level shared locks on various system tables.

The difference between the original output of the trace flag 1200 and the summary may not appear 
to be noteworth in this example. For such a simple query, you intuitively know what locks 
it may acquire. However, the difference becomes significant when you are studying the 
locks of a more complex query or a stored procedure that may include many queries accessing many tables.


=head1 DESCRIPTION

This script is motivated by the voluminous output the trace flag 1200, and the observation that the locking 
information recored in the output is quite repetitive and there is a considerable amount of noise.

Here is a sample output of the trace flag 1200 as the result of executing a simple T-SQL 
I<DELETE FROM authors WHERE au_id = '111-32-1176'>:

 Process 51 acquiring S lock on KEY: 5:4:1 (c20174aaf259) (class ...) result: OK
 Process 51 acquiring S lock on KEY: 5:1:2 (b80175ab6d20) (class ...) result: OK
 Process 51 acquiring S lock on KEY: 5:1:1 (820053521616) (class ...) result: OK
 Process 51 acquiring Schema lock on TAB: 5:1797581442 [] (class ...) result: OK
 Process 51 acquiring S lock on KEY: 5:1:2 (b80175ab6d20) (class ...) result: OK
 ...
 Process 51 acquiring S lock on KEY: 5:14:3 (21014760111f) (class ...) result: OK
 Process 51 acquiring S lock on KEY: 5:14:1 (9f00b01a669f) (class ...) result: OK
 ...
 Process 51 acquiring IS lock on TAB: 5:786101841 [] (class ...) result: OK
 Process 51 acquiring IX lock on TAB: 5:1797581442 [] (class ...) result: OK
 Process 51 acquiring IU lock on PAG: 5:1:87 (class ...) result: OK
 Process 51 releasing lock on PAG: 5:1:87
 Process 51 releasing lock on TAB: 5:53575229 []
 Process 51 releasing lock on TAB: 5:786101841 []

This script improves on the output of the trace flag 1200 in two ways:

=over

=item *  

The script translates all the internal identifiers to the names of their corresponding objects. 

=item *

The script counts the number of times each lock is acquired for each given object resource.

=back

=head1 TRANSLATING IDENTIFIERS TO NAMES

The output of the trace flag 1200 identifies the resource of the TAB, KEY, or IDX locks with their
corresponding identifiers. For the PAG nd RID locks, the resources are identified with their 
respective page IDs. These identifiers and page IDs are not readily reaable.

The I<postT1200.pl> script translates a table identifier to the table name qualified with the owner and 
the database name. In addition, it translates a page ID to its corresponding qualified table name. 
For instance, instead of 5:1:172, the script translates it 
to [dbo].[sysindexes] for the database pubs.

The script connects to SQL Server using ADO with the help of the Win32::OLE module. It finds the 
object name for an object identifier either by querying the sysobjcts table in the case of 
TAB and KEY locks, or by querying the DBCC PAGE output in the case of PAG and RID locks.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.01.27

=cut

# This little script shows how to call the function dbaGetKeyConstraints() and
# shows what the function returns.

use Data::Dumper;
use SQLDBA::SQLDMO qw( dbaGetKeyConstraints );

my $tRef = { srvName => '.\apollo',
              dbName  => 'pubs',
              tbName  => 'titleauthor' };

my $ref = dbaGetKeyConstraints($tRef);
print Dumper($ref);

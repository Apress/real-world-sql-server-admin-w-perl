# See the embedded POD or the HTML documentation

use strict;
use SQLDBA::Utility qw( dbaReadINI dbaRunQueryADO );
use SQLDBA::SQLDMO qw( dbaGetKeyConstraints );

my $configFile = shift or die "***Err: $0 expects a config file.";
my $configRef = dbaReadINI($configFile); # read the config file into a hash

# loop through all the servers
foreach my $server (sort keys %$configRef) {  
   print "Checking server $server ...\n";
   # get all the tables on the server
   my $ref = getTables($server);  
   foreach my $db (sort keys %$ref) {
      # get the data types of all the columns
      my $typeRef = getColTypes($server, $db);

      foreach my $tb (sort @{$ref->{$db}}) {
         my $tRef = { srvName => $server,
                      dbName  => $db,
                      tbName  => $tb
                    };
         # get all the constraints of the table
         my $keyRef = dbaGetKeyConstraints($tRef);

         # evaluate the constraints
         findPoorConstraints($tRef, $keyRef, $typeRef);
      }
   }
}

##############################
# Check the constraints on the table for best practice violation
sub findPoorConstraints {
   my ($tRef, $ref, $typeRef) = @_;
   my $tb = $tRef->{dbName} . '.' . $tRef->{tbName};
   
   # Flag it if the table has more than 8 FKs
   my $fkNo;
   foreach my $key (keys %$ref) {
      ++$fkNo if $ref->{$key}->{Foreign} =~ /yes/i;
   }
   if ($fkNo > 8) {
      print "\t***$tb has more than 8 FKs\n";
   }
   
   # Flag it if the table doesn't have a PK
   my $pk = 0;
   foreach my $key (keys %$ref) {
      if ($ref->{$key}->{Primary} =~ /yes/i) {
         $pk = 1;
         last;
      }
   }
   if ($pk == 0) {
      print "\t***$tb doesn't have a primary key.\n";
   }
   
   # Flag it if the primary key is on a float or real column
   foreach my $key (keys %$ref) {
      if ($ref->{$key}->{Primary} =~ /yes/i) {
         foreach my $col (split(/,/, $ref->{$key}->{KeyColumns})) {
            if ($typeRef->{$tRef->{tbName}}->{$col} =~ /^(real|float)/i) {
               print "\t***$tb primary key is on a real/float column.\n";
            }
         }
      }
   }
} # findPoorConstraints

##################
sub getTables {
   my $server = shift or die "***Err: getTables() expects a server name.";
   
   my $sql = "sp_MSforeachdb 'USE ? 
                SELECT DISTINCT ''table'' = object_name(id), 
                                ''user'' = user_name(uid),
                                ''db'' = db_name()
                  FROM sysobjects
                 WHERE type = ''U''
                   AND objectproperty(id, ''IsMSShipped'') = 0
                   AND db_name() not in (''pubs'', ''Northwind'', ''tempdb'')
                 ORDER BY object_name(id)'";
   my $rc = dbaRunQueryADO($server, $sql, 4);    
   my %results;
   foreach my $rset (@$rc) {
      next unless $rset;
      next unless @$rset;
      foreach my $rcd (@$rset) {
         push @{$results{$rcd->{db}}}, $rcd->{user} . '.' . $rcd->{table};
      }
   }
   return \%results;
} # getTables

##################
sub getColTypes {
   my ($server, $db) = @_;
   
   my $sql = "USE $db
              SELECT 'user' = TABLE_SCHEMA, 
                     'table' = TABLE_NAME, 
                     'col' = COLUMN_NAME, 
                     'type' = DATA_TYPE
                FROM information_schema.COLUMNS";

   my $rc = dbaRunQueryADO($server, $sql, 4);    
   my %results;
   foreach my $rset (@$rc) {
      next unless $rset;
      next unless @$rset;
      foreach my $rcd (@$rset) {
         my $tb = $rcd->{user} . '.' . $rcd->{table};
         $results{$tb}->{$rcd->{col}} = $rcd->{type};
      }
   }
   return \%results;
} # getColTypes


__END__

=head1 NAME

findPoorConstraints - Finding poorly implemented integrity constraints

=head1 SYNOPSIS

   cmd>perl findPoorConstraints.pl  <config file>

=head1 DESCRIPTION

This script is similar to the script that scans the SQL Server instances for poorly designed indexes. 
Instead of finding poorly designed indexes, this script scans for integrity constraints that do not
conform to best practices. The script checks the following integrity constraint 
best practices:

=over

=item *

Every table should have a primary key.

=item *

You should not create a PRIMARY KEY constraint on a column of the type float or real. 
These are imprecise data types, and creating a primary key on such a column can lead to 
unexpected results.

=item *  

You should not have an excessive number of FOREIGN KEY constraints on a table.

=item *

You should not have any redundant constraints.

=back

It is not the objective of the script to be a comprehensive constraint checking tool. Its primary 
purpose is to show how
you can write a Perl script to help find poorly implemented constraints. If you want to check additional 
best practices, you can add appropriate code segment to the script.

=head1 USAGE EXAMPLE

Assume that the config.txt file includes two SQL Server instances, SQL1\APOLLO and SQL1\PANTHEON, in
its section headings. The following is example of running the I<findPoorConstraints.pl> script against the 
config.txt:

 cmd>perl findPoorConstraints.pl config.txt
  Checking server SQL1\APOLLO ...
    ***Reviews.dbo.History doesn't have a primary key.
    ***TradeDB.dbo.FloatTest primary key is on a real/float column.
    ***TradeDB.dbo.RealTest primary key is on a real/float column.
    ***TradeDB.dbo.test doesn't have a primary key.
    ***TradeDB.dbo.TradeHistory has more than 8 FKs
    ***TradeDB.dbo.TradeHistory doesn't have a primary key.
  Checking server SQL1\PANTHEON ...
    ...

=head1 DESIGN OF THE SCRIPT

The script expects a configuration file on the command line. The only part of the configuration file that
is relevant to this script is the SQL Server instance names listed in the section headings and the key
I<Disabled> with either a I<yes> or a I<no> value. The script calls the function I<dbaReadINI()> imported from the module
SQLDBA::Utility to get a list of the SQL Server instances that are not disabled in the configuration file.

For each SQL Server instance, the script runs the following T-SQL script to read all the user tables:

 sp_MSforeachdb 'USE ? 
        SELECT DISTINCT ''table'' = object_name(id), 
                        ''user''  = user_name(uid),
                        ''db''    = db_name()
          FROM sysobjects
         WHERE type = ''U''
           AND objectproperty(id, ''IsMSShipped'') = 0
           AND db_name() not in (''pubs'', ''Northwind'', ''tempdb'', ''model'')
         ORDER BY object_name(id)'

The script then loops through the tables, and for each table, it calls the function I<dbaGetKeyConstraints()> 
imported from the module SQLDBA::SQLDMO to retrieve information on the primary key constraint, the 
foreign key constraints, and the unique constraints. The script also calls the function I<getolTypes()> 
to find the type for each column of the table.

The script evaluate each constraint with respect to the best practices outlined earlier in the function
I<findPoorConstraints()>.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.01.27

=cut

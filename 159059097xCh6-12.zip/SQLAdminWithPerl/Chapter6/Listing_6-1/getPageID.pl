# This script shows how to get the page ID from a byte-swapped hex string

my $root = '0xA00000000100';
my $pageID = getPageID($root);
print "Page ID = $pageID\n";

###################
sub getPageID {
   my $root = shift or die "***Err: getPageID() expects a string.";
   
   $root =~ s/^0x//;  # remove 0x hex prefix, if any
   $root =~ /^[a-f\d]{12}$/i or die "***Err: $root is not a hex string.";

   # decompose the string to an array of bytes, and swap the bytes
   my @roots = reverse($root =~ /([a-f\d]{2})/ig);

   # join the bytes and convert to decimal
   return hex(join '', @roots[0, 1]) . ':' . hex(join '', @roots[2..5]);
} # getPageID

# This little script tests the function dbaGetTableIndexes() to see
# what it produces.

use Data::Dumper;
use SQLDBA::SQLDMO qw( dbaGetTableIndexes );

$ref = { srvName => 'LINCHI\APOLLO',
          dbName => 'pubs',
          tbName => 'authors' };

$idxRef = dbaGetTableIndexes($ref);
print Dumper($idxRef);

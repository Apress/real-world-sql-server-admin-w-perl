# See the embedded POD or the HTML documentation

use strict;
use Data::Dumper;
use SQLDBA::Utility qw( dbaReadINI dbaRunQueryADO );
use SQLDBA::SQLDMO qw( dbaGetTableIndexes );

my $configFile = shift or die "***Err: $0 expects a config file.";
my $configRef = dbaReadINI($configFile); # read the config file into a hash

# loop through all the servers
foreach my $server (sort keys %$configRef) {  
   print "Checking server $server ...\n";
   # get all the tables on the server with more than 1000 pages
   my $ref = getTables($server);  
   foreach my $db (sort keys %$ref) {
      foreach my $tb (sort @{$ref->{$db}}) {
         my $tRef = { srvName => $server,
                      dbName  => $db,
                      tbName  => $tb
                    };
         # get all the indexes of the table
         my $idxRef = dbaGetTableIndexes($tRef);
         
         # evaluate the indexes
         findPoorIdx($db, $tb, $idxRef);
      }
   }
}

##################
# Check the indexes on the table for best practice violation
sub findPoorIdx {
   my ($db, $tb, $ref) = @_;

   # Flag it if the table has more than 8 indexes
   my $idxNo = scalar keys %$ref;
   if ($idxNo > 8) {
      print "***$db.$tb has $idxNo indexes.\n";
   }
   
   # Flag it if an index includes more than 5 columns
   foreach my $idx (sort keys %$ref) {
      my $colNo = scalar split(/,/, $ref->{$idx}->{IndexedColumns});
      if ($colNo > 5) {
         print "***$db.$tb.$idx includes more than 5 columns.\n";
      }
   }
   
   # Flag it if the table doesn't have a clustered index
   my $clustered = 0;
   foreach my $idx (sort keys %$ref) {
      if ($ref->{$idx}->{Clustered} =~ /yes/i) {
         $clustered = 1;
         last;
      }
   }
   if ($clustered == 0) {
#      print "***$db.$tb doesn't have a clustered index.\n";
   }
   
   # Flag it if the table has redundant indexes
   my @idxCols;
   foreach my $idx (sort keys %$ref) {
      push @idxCols, $ref->{$idx}->{IndexedColumns};
   }
   foreach my $cols (@idxCols) {
      if (grep(/^$cols,(.+)/, @idxCols)) {
         print "***$db.$tb includes indexes redundant on columns $cols.\n";         
      }
      if (grep(/^$cols$/, @idxCols) > 1) {
         print "***$db.$tb includes indexes redundant on columns $cols.\n";         
      }
   }
} # findPoorIdx

##################
sub getTables {
   my $server = shift or die "***Err: getTables() expects a server name.";
   
   my $sql = "sp_MSforeachdb 'USE ? 
                SELECT DISTINCT ''table'' = object_name(i.id), 
                                ''user'' = user_name(o.uid),
                                ''db'' = db_name()
                  FROM sysindexes i JOIN sysobjects o ON i.id = o.id
                 WHERE i.indid in (0, 1)
                   AND i.dpages > 1000
                   AND o.type = ''U''
                 ORDER BY object_name(i.id)'";
   my $rc = dbaRunQueryADO($server, $sql, 4);    
   my %results;
   foreach my $rset (@$rc) {
      next unless $rset;
      next unless @$rset;
      foreach my $rcd (@$rset) {
         push @{$results{$rcd->{db}}}, $rcd->{user} . '.' . $rcd->{table};
      }
   }
   return \%results;
} # getTables


__END__

=head1 NAME

findPoorIndexes - Finding poorly designed indexes

=head1 SYNOPSIS

   cmd>perl findPoorIndexes.pl  <config file>

=head1 DESCRIPTION

This script scans the SQL Server instances listed in the configuration file specified on the command line, 
and for each SQL Server instance,
it flags the indexes that do not conform to best practices. The script checks the following index design 
best practices:

=over

=item *

Every table should have a clustered index.

=item *

There should not be excessively many indexes on a table that is not read only.

=item *  

There should not be redundant indexes on a table.

=item *  

A clustered index should be as narrow as possible.

=item *  

A non-clustered index should be highly selective.

=back

This is by no means a comprehensive compilation of index design best practices. It is not the 
objective of the script to be a comprehensive index checking tool. Its primary purpose is to show how
you can write a Perl script to help find poorly designed indexes. If you want to check additional 
best practices, you can add appropriate code segment to the script.

=head1 DESIGN OF THE SCRIPT

The script expects a configuration file on the command line. The only part of the configuration file that
is relevant to this script is the SQL Server instance names listed in the section headings and the key
I<Disabled> with either a I<yes> or a I<no>. The script calls the function I<dbaReadINI()> imported from the module
SQLDBA::Utility to get a list of the SQL Server instances that are not disabled in the configuration file.

For each SQL Server instance, the script runs the following T-SQL script to read all the user tables with
more than 1000 data pages.

 sp_MSforeachdb 'USE ? 
                 SELECT DISTINCT ''table'' = object_name(i.id), 
                                ''user'' = user_name(o.uid),
                                ''db'' = db_name()
                   FROM sysindexes i JOIN sysobjects o ON i.id = o.id
                  WHERE i.indid in (0, 1)
                    AND i.dpages > 1000
                    AND o.type = ''U''
                  ORDER BY object_name(i.id)'

The rationale for ignoring a table with fewer than 1000 pages is that there is little to gain in enforcing
these best practices on the indexes on a small table.

The script then loops through the tables, and calls the function I<dbaGetTableIndexes()> imported from the module SQLDBA::SQLDMO
to find all the indexes for each table.

Given a SQL instance name, a database name, and a table name, the function I<dbaGetTableIndexes()>
returns complete information on the indexes created on the table. The following is a sample output 
of applying the function to the pubs..authors table:

 $ref = {
          'ix_idphone' => {
                            'UniqueKey' => 'no',
                            'FillFactor' => 0,
                            'Clustered' => 'no',
                            'IgnoreDupKey' => 'no',
                            'NoRecompute' => 'no',
                            'IndexedColumns' => 'au_id,phone',
                            'PadIndex' => 'no',
                            'Unique' => 'yes',
                            'PrimaryKey' => 'no',
                            'FileGroup' => 'PRIMARY'
                          },
          'aunmind' => {
                         'UniqueKey' => 'no',
                         'FillFactor' => 0,
                         'Clustered' => 'no',
                         'IgnoreDupKey' => 'no',
                         'NoRecompute' => 'no',
                         'IndexedColumns' => 'au_lname,au_fname',
                         'PadIndex' => 'no',
                         'Unique' => 'no',
                         'PrimaryKey' => 'no',
                         'FileGroup' => 'PRIMARY'
                       },
          'UPKCL_auidind' => {
                               'UniqueKey' => 'no',
                               'FillFactor' => 0,
                               'Clustered' => 'yes',
                               'IgnoreDupKey' => 'no',
                               'NoRecompute' => 'no',
                               'IndexedColumns' => 'au_id',
                               'PadIndex' => 'no',
                               'Unique' => 'yes',
                               'PrimaryKey' => 'yes',
                               'FileGroup' => 'PRIMARY'
                             }
        };

Given the database name, the table name, and the index information returned from the function 
I<dbaGetTableIndexes()>, the script has the complete information to evaluate the index design of 
the table. The function I<findPoorIdx()>, which is defined in the script, performs the best
practice evaluation.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.01.27

=cut

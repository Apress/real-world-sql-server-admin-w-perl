# See the embedded POD or the HTML documentation

use strict;
use Data::Dumper;
use SQLDBA::Utility qw( dbaReadINI dbaRunOsql dbaRunQueryADO );

my $configFile = shift or die "***Err: $0 expects a config file.";
my $configRef = dbaReadINI($configFile); # read the config file to a hash

# loop through all the servers
foreach my $server (sort keys %$configRef) {  
   print "Checking server $server ...\n";
   # get all the tables on the server with more than 1000 pages
   my $ref = getTables($server);  
   foreach my $db (sort keys %$ref) {
      print "  Checking database $db ...\n";
      foreach my $tb (sort @{$ref->{$db}}) {
         my $tRef = { srvName => $server,
                      dbName  => $db,
                      tbName  => $tb
                    };
         # run DBCC SHOWCONTIG on the table
         my $fragRef = getIndexFrag($tRef);

         # evaluate the fragmentation of the indexes
         findIndexFrag($tb, $fragRef);
      }
   }
}  # foreach my $server

##################
# Check the output of DBCC SHOWCONTIG for severe fragmentation
sub findIndexFrag {
   my ($tb, $ref) = @_;

   foreach my $indid (keys %$ref) {
      # skip an index if it has less than 100 pages
      next if $ref->{$indid}->{PagesScanned} < 30;
      
      #Check Page Density
      if ($ref->{$indid}->{PageDensity} < 60) {
         print "\t***Msg: $tb: Index $indid, PageDensity = ",
               $ref->{$indid}->{PageDensity}, 
               "%, PagesScanned: ", $ref->{$indid}->{PagesScanned}, "\n";
      }
      # Check Logical Scan Fragmentation
      if ($ref->{$indid}->{LogicalScanFragmentation} > 20) {
         print "\t***Msg: $tb: Index $indid, Logical Scan Frag = ",
               $ref->{$indid}->{LogicalScanFragmentation}, 
               "%, PagesScanned: ", $ref->{$indid}->{PagesScanned}, "\n";
      }
      # Check Extent Scan Fragmentation
      if ($ref->{$indid}->{ExtentScanFragmentation} > 20) {
         print "\t***Msg: $tb: Index $indid, Extent Scan Frag = ",
               $ref->{$indid}->{ExtentScanFragmentation},
               "%, PagesScanned: ", $ref->{$indid}->{PagesScanned}, "\n";
      }
   }
} # findIndexFrag

sub getIndexFrag {
   my $tRef = shift or die "***Err: getIndexFrag() expects a reference.";
   my ($db, $tb) = ($tRef->{dbName}, $tRef->{tbName});
   
   my $sql = "USE $db
              DBCC SHOWCONTIG(\'$tb\') WITH ALL_INDEXES";
              
   my $opRef = {'-E' => undef, '-n' => undef, '-h' => '-1', '-w' => 1024};
   my $rc = dbaRunOsql($tRef->{srvName}, $sql, $opRef);
   
   my ($indid, $fragRef);
   foreach my $msg (split(/\n/, $rc)) {
      if ($msg =~ /Table:\s+\'(.+)\'.+Index\s+ID:\s+(\d+)/i) {
         $indid = $2;
         next;
      }
      if ($msg =~ /Pages\s+Scanned.+\:\s+(\d+)/i) {
         $fragRef->{$indid}->{PagesScanned} = $1;
         next;
      }
      if ($msg =~ /Logical\s+Scan\s+Fragmentation.+\:\s+(.+)\%/i) {
         my $frag = $1;
         $frag =~ s/\s*$//;
         $fragRef->{$indid}->{LogicalScanFragmentation} = $frag;
         next;
      }
      if ($msg =~ /Extent\s+Scan\s+Fragmentation.+\:\s+(.+)\%/i) {
         my $frag = $1;
         $frag =~ s/\s*$//;
         $fragRef->{$indid}->{ExtentScanFragmentation} = $frag;
         next;
      }
      if ($msg =~ /Page\s+Density.+\:\s+(.+)\%/i) {
         my $frag = $1;
         $frag =~ s/\s*$//;
         $fragRef->{$indid}->{PageDensity} = $frag;
         next;
      }
   }
   return $fragRef;
} # getIndexFrag

##################
sub getTables {
   my $server = shift or die "***Err: getTables() expects a server name.";
   
   my $sql = "sp_MSforeachdb 'USE ? 
                SELECT DISTINCT ''table'' = object_name(i.id), 
                                ''user'' = user_name(o.uid),
                                ''db'' = db_name()
                  FROM sysindexes i JOIN sysobjects o ON i.id = o.id
                 WHERE i.indid = 1
                   AND i.dpages > 30
                   AND o.type = ''U''
                 ORDER BY object_name(i.id)'";
   my $rc = dbaRunQueryADO($server, $sql, 4);    
   my %results;
   foreach my $rset (@$rc) {
      next unless $rset;
      next unless @$rset;
      foreach my $rcd (@$rset) {
         push @{$results{$rcd->{db}}}, $rcd->{user} . '.' . $rcd->{table};
      }
   }
   return \%results;
} # getTables


__END__

=head1 NAME

findIndexFrag - Finding fragmented indexes

=head1 SYNOPSIS

   cmd>perl findIndexFrag.pl  <config file>

=head1 SAMPLE USAGE 

Assume that the config.txt file has two SQL Server instances, SQL1\APOLLO and SQL2, 
listed in its section headings.

 cmd>perl findIndexFrag.pl config.txt
 Checking server SQL1\APOLLO ...
   Checking database TradeDB ...
     ***Msg: dbo.RTCust: Index 1, PageDensity = 59.78%, PagesScanned: 14600
     ***Msg: dbo.RTCust: Index 1, Logical Scan Frag = 41.10%, PagesScanned: 14600
     ***Msg: dbo.RTCust: Index 2, PageDensity = 59.18%, PagesScanned: 6500
     ***Msg: dbo.RTCust: Index 2, Logical Scan Frag = 52.31%, PagesScanned: 6500
 Checking server SQL2 ...
   Checking database DealDB ...
     ***Msg: dbo.RTDeal: Index 1, PageDensity = 59.78%, PagesScanned: 2460
     ***Msg: dbo.RTDeal: Index 1, Logical Scan Frag = 41.10%, PagesScanned: 2460
     ***Msg: dbo.RTDeal: Index 2, PageDensity = 59.18%, PagesScanned: 1980
     ***Msg: dbo.RTDeal: Index 2, Logical Scan Frag = 52.31%, PagesScanned: 1980
   Checking database pubDB ...

This output only highlights the index fragmentation. It is up to you to decide whether you want 
to take any action to further investigate these indexes, or to defrag them.

=head1 DESCRIPTION

The I<findIndexFrag.pl> script highlights the indexes whose defragmentation may yield the most significant 
performance improvement. Through scanning the output of DBCC SHOWCONTIG, it implements the following rules:

=over

=item *

In deciding which table to scan, the script selects only large tables. The threshold 
is set to 1,000 data pages in the script.

=item *

The script checks a table only if it has a clustered index.

=item *

The script considers an index only if it has more than 1,000 pages.

=item *

The script highlights an index if its Logical Scan Fragmentation is greater than 20 percent%.

=item *

The script highlights an index if its Extent Scan Fragmentation is greater than 40 percent %.

=item *

The script highlights an index if its Average Page Density is lower than 60 percent%.

=back

More specifically, the script scans the DBCC SHOWCONTIG ooutput for the values of Logical Scan 
Fragmentation, Extent Scan Fragmentation, and Average Page Density.

Beware that none of the threshold numbers in the preceding list is selected through a 
scientific process. They are rough numbers that you should adjust to fit your own environment.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.01.27

=cut

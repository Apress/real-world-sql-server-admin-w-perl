# See the embedded POD or the HTML documentation

use strict;
use Win32::OLE 'in';
use Getopt::Std;
use SQLDBA::Utility qw( dbaReadSavedRef dbaSaveRef dbaSetDiff dbaTime2str );
use Data::Dumper;

my %opts;
getopts('S:d:t:s:r:', \%opts);
(defined $opts{S} and defined $opts{d} and defined $opts{t}) or printUsage();
printUsage() if defined $opts{s} and defined $opts{r};

MAIN: {
   my ($server, $db, $tab) = ($opts{S}, $opts{d}, $opts{t});
   print dbaTime2str(), "\n";
   
   # open a connection to the server and database
   my $conn = getConn($server, $db);

   # get the PK column(s)
   my $pkRef = getPKRef($conn, $tab);
   unless (scalar @$pkRef) {
      die "***Err: table $tab doesn't have a primary key.";
   }
   # get all the page IDs of the table
   my $allPageIDsRef = getAllPageIDs($conn, $db, $tab);

   my $page2Rows;
   # for each page ID, get all the rows on the page
   foreach my $pageID (@$allPageIDsRef) {
      my ($fileno, $pageno) = $pageID =~ /(\d+)\:(\d+)/;

      #get the result of DBCC PAGE to an array
      my $msgRef = dbccPage($conn, $db, $fileno, $pageno);

      # get the PK values of the rows on a page
      my $rowRef = getRows($pkRef, $msgRef);

      # get mapping from page ID to the PK values
      $page2Rows->{$pageID} = $rowRef;
   }

   if (-e $opts{s}) {
      # retrive the saved old pageID to rows mapping
      my $savedPage2Rows = dbaReadSavedRef($opts{s});

      # remove the pages that have not changed and report the diff
      my ($oldDiff, $newDiff) = 
                   reportPageDiff($savedPage2Rows, $page2Rows);
      
      # print pages that are removed or changed
      print Data::Dumper->Dump([$oldDiff], ['oldPages']); 
      # print pages that are new or changed
      print Data::Dumper->Dump([$newDiff], ['newPages']); 
   }
   if ($opts{r}) {
      # record the current page 2 row mapping
      dbaSaveRef($opts{r}, $page2Rows, 'page2Rows'); 
   }
   $conn->Close();
}

#####################
sub printUsage {
   print <<___Usage;
Usage:
   cmd>perl checkPages.pl  -S <SQL Server instance> 
                           -d <database> 
                           -t <table> 
                           ( -r <snapshot file> | -s <snapshot file> )
___Usage
   exit;
} # printUsage

#####################
#  get an ADO connection to be used throughout the script
sub getConn {
   my ($server, $db) = @_;
   
   my $conn = Win32::OLE->new('ADODB.Connection') or 
         die "***Err: Win32::OLE->new() failed.";
   $conn->{ConnectionTimeout} = 4;
   my $connStr = "Provider=sqloledb;Server=$server;" .
                 "database=$db;Trusted_Connection=yes";
   $conn->Open($connStr);
   ! Win32::OLE->LastError() or die Win32::OLE->LastError();

   $conn->Execute('dbcc traceon(3604)') or
      die Win32::OLE->LastError();
   return $conn;  # this connection will be reused until the script exits
}  # getConn

#######################
#  get the DBCC PAGE output to an array
sub dbccPage {
   my ($conn, $db, $fileNo, $pageNo) = @_;
   my @msg;
   
   my $sql = "declare \@dbid int
              set \@dbid = db_id(\'$db\')
              dbcc page(\@dbid,$fileNo,$pageNo,3)";
   $conn->Execute($sql) or
      die Win32::OLE->LastError();
      
   # note that ADO returns DBCC output in Errors collection
   # unless you specify with tableresults
   foreach my $err (in($conn->Errors())) {
      my $msg = $err->{Description}; # it's in the Description property
      $msg =~ s/\s*$//;
      push @msg, $msg;
   }
   return \@msg; # contains the DBCC PAGE output
}  # dbccPage

########################
# get the rows, identified by the PKs, for the page from
# the page info dumped by DBCC PAGE
sub getRows {
   my ($pkRef, $msgRef) = @_;  # take PK columns and DBCC PAGE output
   
   my $rowCnt;          # for validation purpose
   my $pageHeader = 0;  # to signal whether the loop is in the header part
   my ($slot, $offset, $pageID);
   my $rowRef;
   foreach my $msg (@$msgRef) {
      $msg =~ /\s*PAGE:\s+\((.+)\)/i and $pageID = $1;  # PAGE: (1:160)

      # if matched, entering the page header
      if ($msg =~ /^\s*PAGE\s+HEADER:/i) {
         $pageHeader = 1; 
         next;
      }

      # get the slot count (i.e. row count) from the header
      # the actual row count should match this number if our search works.
      # Otherwise, sth went wrong and the result shouldn't be used
      if ($pageHeader and $msg =~ /m\_slotCnt\s*=\s*(\d+)/i) {
         $rowCnt = $1;
         next;
      }

      # get the number of ghost record count
      if ($pageHeader and $msg =~ /m\_ghostRecCnt\s*=\s*(\d+)/i) {
         $rowRef->{PageHeader}->{GhostRecCnt} = $1;
         next;
      }

      # get number of free bytes on the page
      if ($pageHeader and $msg =~ /m\_freeCnt\s*=\s*(\d+)/i) {
         $rowRef->{PageHeader}->{FreeCnt} = $1;
         next;
      }
      
      # if matched, left the page header
      if ($msg =~ /^\s*Allocation\s+Status/i) {
         $pageHeader = 0;
         next;
      }
     
      if ($msg =~ /\s*Slot\s+(\d+)\s+Offset\s+(0x\w+)/i) {
         ($slot, $offset) = ($1, $2);
         $rowRef->{Slots}->{$slot}->{Offset} = $offset;
         next;
      }

      # get Record Type
      if ($msg =~ /\s*Record\s*Type\s*=\s*(.+)/i) {
         my $recordType = $1;
         $recordType =~ s/\s*$//;
         $rowRef->{Slots}->{$slot}->{RecordType} = $recordType;
         next;
      }
      
      foreach my $key (@$pkRef) {
         if ($msg =~ /^\s*$key\s*=\s*(.+?)\s*$/i) {
            push @{$rowRef->{Slots}->{$slot}->{PK}}, $1;
         }
      }
   }
   # actual row count should match the slot count in the header
   my $actualRowCnt = scalar (keys %{$rowRef->{Slots}});
   print "Page: $pageID, Header slotCnt = $rowCnt, ",
         "actual rowCnt = $actualRowCnt\n";
   ($rowCnt == $actualRowCnt) or 
      die "***Err: parsing DBCC PAGE output encountered problem.";
   $rowRef->{PageHeader}->{SlotCnt} = $actualRowCnt;

   my $r_rowRef;
   foreach my $slotNo (keys %{$rowRef->{Slots}}) {
      # concatenate the PK key values if it's composite to 
      # identify a row
      my $row_id = join('/', @{$rowRef->{Slots}->{$slotNo}->{PK}});
      # reverse key/value for the slots
      $r_rowRef->{Slots}->{$row_id} = 
                     { Slot   => $slotNo,
                       Offset => $rowRef->{Slots}->{$slotNo}->{Offset},
                       RecordType => $rowRef->{Slots}->{$slotNo}->{RecordType}
                     };
   }
   $r_rowRef->{PageHeader} = $rowRef->{PageHeader};
   return $r_rowRef;  # concatenated PK values is key, slot # is value
}  # getRows

#############################
#  get all the page IDs of a table
sub getAllPageIDs {
   my ($conn, $db, $tb) = @_;
   
   my $sql ="declare \@db int, \@obj int
             select \@db = db_id(\'$db\'), \@obj = object_id(\'$tb\')
             dbcc ind(\@db, \@obj, 0)";

   my $rs = $conn->Execute($sql) or
      die Win32::OLE->LastError();

   my @resultset = ();
   while ( !$rs->{EOF} ) {
      if ($rs->Fields('PageType')->{Value} != 1) {
         $rs->MoveNext;
         next;
      }
      my $pageID = $rs->Fields('PageFID')->{Value} .':' .
                   $rs->Fields('PagePID')->{Value};
      push @resultset, $pageID;
      $rs->MoveNext;
   }
   return \@resultset;
}  # getAllPageIDs

#######################
#   get the PK columns
sub getPKRef {
   my ($conn, $tab) = @_;
   
   my $sql = "SELECT kc.column_name
                FROM information_schema.key_column_usage kc,
                     information_schema.table_constraints tc
               WHERE kc.table_name = \'$tab\'
                 AND kc.table_schema = \'dbo\'
                 AND kc.table_name = tc.table_name
                 AND kc.table_schema = tc.table_schema
                 AND kc.constraint_name = tc.constraint_name
                 AND kc.constraint_schema = tc.constraint_schema
                 AND tc.constraint_type = 'PRIMARY KEY'
               ORDER BY kc.ordinal_position";

   my $rs = $conn->Execute($sql) or
      die Win32::OLE->LastError();

   my @resultset = ();
   while ( !$rs->{EOF} ) {
      push @resultset, $rs->Fields('column_name')->{Value};
      $rs->MoveNext;
   }
   return \@resultset;
}  # getPKRef

########################
#  report any page difference between what's read from the server and
#  what's saved last time
sub reportPageDiff {
   my ($old, $new) = @_;

   foreach my $page (keys %$new) {
      # report any new page that has been added
      if (!exists $old->{$page}) {
         print "***Page $page has been added.\n";
         next;
      }
   }
   
   foreach my $page (keys %$old) {
      # report any page that has been removed
      if (!exists $new->{$page}) {
         print "***Page $page has been removed.\n";
         next;
      }

      my $pageChanged = 0;      # to identify whether a page has changed

      # report any changes in the page header
      foreach my $headerEntry (keys %{$old->{$page}->{PageHeader}}) {
         my $oldValue = $old->{$page}->{PageHeader}->{$headerEntry};
         my $newValue = $new->{$page}->{PageHeader}->{$headerEntry};
         if ($oldValue ne $newValue) {
            print "***Page: $page, Header $headerEntry: $oldValue => $newValue\n";
            $pageChanged = 1;
         }
      }
      
      my $oldRowRef = [keys %{$old->{$page}->{Slots}}];
      my $newRowRef = [keys %{$new->{$page}->{Slots}}];
      # report any row that has been removed from the page
      if (my @removedRows = dbaSetDiff($oldRowRef, $newRowRef)) {
         print "***These rows have been removed from page $page: ", 
                  join(',', @removedRows), "\n";
         $pageChanged = 1;
         next;
      }

      # report any page with newly added rows
      if (my @addedRows = dbaSetDiff($newRowRef, $oldRowRef)) {
         print "***These rows have been added to page $page: ", 
                  join(',', @addedRows), "\n";
         $pageChanged = 1;
         next;
      }

      # for the pages with the same rows, check for any change for each row
      foreach my $row (keys %{$old->{$page}->{Slots}}) {
         my $rowChanged = 0;

         # check the entries for each row
         foreach my $rowEntry (keys %{$old->{$page}->{Slots}->{$row}}) {
            # report any slot change
            my $oldValue = $old->{$page}->{Slots}->{$row}->{$rowEntry};
            my $newValue = $new->{$page}->{Slots}->{$row}->{$rowEntry};
            
            if ($oldValue ne $newValue) {
               print "***The $rowEntry of row $row: $oldValue => $newValue\n"; 
               $rowChanged = 1;
               $pageChanged = 1;
            }
         }
         if (! $rowChanged) {   # if the row is not changed
            delete $old->{$page}->{Slots}->{$row};
            delete $new->{$page}->{Slots}->{$row};
         }
      }
      if (! $pageChanged) {  # if the page is not changed
         delete $old->{$page};
         delete $new->{$page};
      }
   }
   return ($old, $new);
}  # reportPageDiff


__END__

=head1 NAME

checkStoragePages - A script for studying the SQL Server storage internals

=head1 SYNOPSIS

   cmd>perl checkPages.pl  -S <SQL Server instance> 
                           -d <database> 
                           -t <table> 
                           ( -r <snapshot file> | -s <snapshot file> )

     -r instructs the script to just read from the saved storage snapshot
     -s instructs the script to record a new snapshot of the storage

=head1 USAGE EXAMPLES

To study the behavior of the SQL Server storage, let us again use the Northwind.dbo.Customers table. 
To ensure you can insert into and delete rows from the table, you need to remove or disable all the 
foreign keys that reference the Customers table.

It is convenient to study each scenario against the same base line. Let us start with a pristine 
copy of the Customers table, in other words, the copy created during the SQL Server 2000 installation. 
Run the script as follows to save a snapshot:

 cmd>perl checkStoragePages.pl -S SQL1 -d northwind -t Customers -s snapshot.log
 
When done, the file snapshot.log contains a data structure similar to what is hsown below:

 $ref = {
    '1:351' => {
              'PageHeader' => {  # hash for the page header
                             'FreeCnt'     => '3732',
                             'GhostRecCnt' => '0',
                             'SlotCnt'     => '31'
              },
              'Slots' => {  # hash for the slots
                     'COMMI' => {
                               'RecordType' => 'PRIMARY_RECORD',
                               'Offset'     => '0xe34',
                               'Slot'       => '14'
                     },
                     'BERGS' => {
                               'RecordType' => 'PRIMARY_RECORD',
                               'Offset'     => '0x452',
                               'Slot'       => '4'
                     },
                     ...
                     'BLONP' => {
                               'RecordType' => 'PRIMARY_RECORD',
                               'Offset'     => '0x65e',
                               'Slot'       => '6'
                     }
              }
    },
    '1:392' => {
              'PageHeader' => { # hash for a page
                             'FreeCnt'     => '4142',
                             'GhostRecCnt' => '0'
              },
              'Slots' => {  # hash for the slots
                        'FRANR' => {
                                  'RecordType' => 'PRIMARY_RECORD',
                                  'Offset'     => '0x7d0',
                                  'Slot'       => '8'
                        },
                        'FOLKO' => {
                                  'RecordType' => 'PRIMARY_RECORD',
                                  'Offset'     => '0x61c',
                                  'Slot'       => '6'
                        }
              }
    }
 };


If a previous copy of the file snapshot.log already exists, the script will replace it with an updated 
snapshot if the -s argument is specified on the command line.

=head2 Deleting a Row

From Query Analyzer, run the following SQL query:

 DELETE FROM Customers
  WEHRE CustomerID = 'COMMI'

And immediately run the script I<checkStoragePages.pl> as follows to see the changes to the 
data pages of the Customers table:

 cmd>perl checkStoragePages.pl -S SQL1 -d northwind -t Customers -r snapshot.log
 
 2003/04/27 18:04:31
 Page: 1:351, Header slot cnt = 32, actual row cnt = 32
 Page: 1:384, Header slot cnt = 29, actual row cnt = 29
 Page: 1:385, Header slot cnt = 30, actual row cnt = 30
 ***Page: 1:351, Header GhostRecCnt: 0 => 1
 ***The RecordType of row COMMI: PRIMARY_RECORD => GHOST_DATA_RECORD
 $oldPages = {
           '1:351' => {
                  'Slots' => {
                            'COMMI' => {
                                      'Offset'     => '0xe34',
                                      'RecordType' => 'PRIMARY_RECORD',
                                      'Slot'       => '14'
                            }
                  },
                  'PageHeader' => {
                                 'FreeCnt'     => '40',
                                 'GhostRecCnt' => '0',
                                 'SlotCnt'     => '32'
                  }
           }              
 };
 $newPages = {
           '1:351' => {
                  'PageHeader' => {
                                    'FreeCnt'     => '40',
                                    'GhostRecCnt' => '1',
                                    'SlotCnt'     => '32'
                  },
                  'Slots' => {
                            'COMMI' => {
                                      'RecordType' => 'GHOST_DATA_RECORD',
                                      'Offset' => '0xe34',
                                      'Slot' => '14'
                            }
                  }
           }
 };

Overall, the script reports two main changes:

=over 

=item * Page: 1:351, Header GhostRecCnt: 0 => 1

=item * The RecordType of row COMMI: PRIMARY_RECORD => GHOST_DATA_RECORD

=back

The result also shows that the deleted row is now marked as a ghost record in the slot allocated 
to the row on the page 1:351. The ghost record count in the page header has increased to 1. 
Also, the script prints the variables $oldPages and $newPages. They record only the pages and 
the rows that have been changed.

Although a record has been deleted from the page, SQL Server did not update the number of free bytes 
available on the page when the script was run. It remains to be 40 bytes.


=head2 Updating a Row with a Clustered Index

When you update a row that becomes too large to fit on the existing page, how does SQL 
Server accommodate this row? The behavior depends on whether the table has a clustered index.

If the table has a clustered index, the behavior is the same as a page split. Before you make 
any change to the Customer table, the page 1:351 has 40 bytes of free space. 
If you run the following SQL statement, the updated row will not fit on the same page:

 UPDATE Customers
    SET Address = REPLICATE('A', 60)
  WHERE CustomerID = 'COMMI'

Now run the script I<checkStoragePages.pl> to see how SQL Server accommodates this overflow row in the output
shown below:

 cmd>perl checkStoragePages.pl -S SQL1 -d northwind -t Customers -r snapshot.log
 
 2003/04/27 23:36:45
 Page: 1:351, Header slotCnt = 16, actual rowCnt = 16
 Page: 1:384, Header slotCnt = 29, actual rowCnt = 29
 Page: 1:385, Header slotCnt = 30, actual rowCnt = 30
 Page: 1:386, Header slotCnt = 16, actual rowCnt = 16
 ***Page 1:386 has been added.
 ***Page: 1:351, Header FreeCnt: 40 => 4148
 ***These rows have been removed from page 1:351: 
 BERGS,COMMI,ALFKI,ANTON,BOTTM,CENTC,CACTU,AROUT,ANATR,BLAUS,BSBEV,CHOPS,BOLID,
 BONAP,BLONP,CONSH
 $oldPages = {
        '1:351' => {
                  'Slots' => {
                            'FOLIG' => {
                                      'Offset'     => '0x15fc',
                                      'RecordType' => 'PRIMARY_RECORD',
                                      'Slot'       => '22'
                            },
                            ...
                            'BLONP' => {
                                      'Offset'     => '0x65e',
                                      'RecordType' => 'PRIMARY_RECORD',
                                      'Slot'       => '6'
                            }
                  },
                  'PageHeader' => {
                                 'FreeCnt'     => '40',
                                 'GhostRecCnt' => '0',
                                 'SlotCnt'     => '32'
                  }
        }
 };
 $newPages = {
        '1:351' => {
                  'PageHeader' => {
                                    'FreeCnt'     => '4148',
                                    'GhostRecCnt' => '0',
                                    'SlotCnt'     => '16'
                  },
                  'Slots' => {
                            'FRANR' => {
                                      'RecordType' => 'PRIMARY_RECORD',
                                      'Offset' => '0x18ba',
                                      'Slot' => '9'
                            },
                            ...
                            'FOLKO' => {
                                      'RecordType' => 'PRIMARY_RECORD',
                                      'Offset' => '0x1706',
                                      'Slot' => '7'
                            }
                  }
        },
        '1:386' => {
                  'PageHeader' => {
                                 'FreeCnt' => '3908',
                                 'GhostRecCnt' => '0'
                                 'SlotCnt'     => '16'
                  },
                  'Slots' => {
                            'COMMI' => {
                                         'RecordType' => 'PRIMARY_RECORD',
                                         'Offset' => '0x104c',
                                         'Slot' => '14'
                            },
                            'BERGS' => {
                                         'RecordType' => 'PRIMARY_RECORD',
                                         'Offset' => '0x452',
                                         'Slot' => '4'
                            },
                            ...
                            'BLONP' => {
                                         'RecordType' => 'PRIMARY_RECORD',
                                         'Offset' => '0x65e',
                                         'Slot' => '6'
                            }
                  }
        }
 };

Because the updated row does not fit on the page 1:351, SQL Server allocates a new 
page (the page 1:386) and moves a half of the rows from the page 1:351 to this new page. 
This is evident if you check the value of SlotCnt for the page 1:351. Before the split, 
the value is 32. After the split, the value becomes 16, leaving the page 1:351 with 4148 
bytes of free space.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.01.27

=cut


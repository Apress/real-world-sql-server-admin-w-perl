# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaReadINI dbaTime2str dbaTime2dateStr );
use Win32::EventLog;
use Data::Dumper;

my $configFile = shift or die "***Err: $0 expects a config file.";
my $configRef = dbaReadINI($configFile);
my $eventID = 6005;

foreach my $server (sort keys %$configRef) {
   print "\nServer=$server\n";

   my $cutoff_days = $configRef->{$server}->{INCLUDEDAYS};
   my $rebootRef = dbaReadEventLog($server, "system", $cutoff_days);
   dbaPrintReboot($rebootRef);
}

sub dbaReadEventLog {
   my($server, $log, $days) = @_;
   my($logRef, $eventRef, $rebootRef);

   my $cutoff = time() - $days * 24 * 3600;

   $logRef = Win32::EventLog->new($log, $server) 
            or die "Could not open $log on $server: $!\n";

   while ( $logRef->Read(EVENTLOG_BACKWARDS_READ | 
                         EVENTLOG_SEQUENTIAL_READ, 0, $eventRef) &&
         $cutoff < $eventRef->{TimeGenerated}) {
      if ( $eventRef->{EventType} == EVENTLOG_INFORMATION_TYPE &&
               ($eventRef->{EventID} & 0xffff) == $eventID ) {
         $rebootRef->{dbaTime2dateStr($eventRef->{TimeGenerated})}->{count}++;
         $rebootRef->{dbaTime2dateStr($eventRef->{TimeGenerated})}->{lastReboot} 
                                 = dbaTime2str($eventRef->{TimeGenerated});
      }
   } 
   Win32::EventLog::CloseEventLog($logRef);
   return $rebootRef;
}  # dbaReadEventLog

sub dbaPrintReboot {
   my ($rebootRef) = shift or die "dbaPrintReboot expects reference.\n";
   
   my($date, $rebootCount, $lastReboot);
   if (scalar keys %$rebootRef) {
     print '  Date           Reboot # Last Rebooted', "\n";
     print '  ============= ========= ======================', "\n";
     foreach $date (sort keys %$rebootRef) {
        $rebootCount = $rebootRef->{$date}->{count};
        $lastReboot = $rebootRef->{$date}->{lastReboot};
        write;
     }
   }
   else {
     print "    None\n";
   }

format STDOUT =
  @<<<<<<<<<<<< @>>>>>>>> @<<<<<<<<<<<<<<<<<<<<<
  $date,        $rebootCount,  $lastReboot
.
} # dbaPrintReboot

__END__

=head1 NAME

rebootSummary - Summarizing reboot history

=head1 SYNOPSIS

   cmd>perl rebootSummary.pl <config file>

=head1 USAGE EXAMPLE

Assume you have the following sample configuration options in the config.txt file:

 [SQL1]
 IncludeDays=14
  
 [SQL2]
 IncludeDays=14


The options in this example indicate that you want to summarize the reboot history for the 
servers SQL1 and SQL2 during the past 14 days.

Run I<rebootSummary.pl> on the command line as follows to see the result:

 cmd>perl rebootSummary.pl config.txt
 
 Server=SQL1
   Date          Reboot #  Last Rebooted
   ============= =========  =====================
   2002/03/31    2         2002/03/31 13:50:24
   2002/04/12    1         2002/04/12 11:50:41
   2002/04/13    3         2002/04/13 15:24:51
   2002/04/14    1         2002/04/14 11:38:39 
 
 Server=SQL2
   Date          Reboot #  Last Rebooted
   ===========   ========  =====================


The script was run on April 14, 2002. The report shows that within the 14 days prior to 
April 14, 2002, the server SQL1 was rebooted seven times, and the reboots were particularly 
frequent in the last three days. The server SQL2, on the other hand, was not rebooted at 
all during these same 14 days.


=head1 DESCRIPTION

This script uses the module Win32::EventLog to scan the Windows system eventlog for event ID 6005 
and its description -- The Event log service was started. This event log entry is a good indicator 
of a server reboot.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


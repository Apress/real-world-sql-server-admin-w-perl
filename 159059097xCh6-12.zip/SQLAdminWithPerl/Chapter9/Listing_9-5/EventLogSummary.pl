# See the embedded POD or the HTML documentation

use strict;

# import functions from the module SQLDBA::Utility
use SQLDBA::Utility qw ( dbaTime2str dbaSetDiff dbaSetCommon dbaInSet
                         dbaReadINI dbaReadEventLog dbaFilterLogEntry );
                         
Main: {
   my $configFile = shift or 
         die "***Err: config file must be specified on the command line.";
   (-e $configFile) or die "Config file $configFile does not exist.";

   # get config options
   my $configRef = getConfig($configFile);
   # read and summarize the eventlog entries for each server
   foreach my $server (sort keys %$configRef) {
     my $summaryRef = dbaReadEventLog($server, \&dbaFilterLogEntry, $configRef);
     printEventLog($server, $summaryRef, $configRef);
   }
} # Main

##################
sub getConfig {
   my $configFile = shift or die "***Err: getConfig() expects a file name.";

   my $ref = dbaReadINI($configFile);
   foreach my $server (keys %$ref) {
      foreach my $key (keys %{$ref->{$server}}) {
         if (! defined $ref->{$server}->{$key}) {
            delete $ref->{$server}->{$key}; # remove config key with no value
            next;
         }
         if ($key !~ /(includeMessage|ExcludeMessage)/i) {
            # split the comma-separated values into an array
            $ref->{$server}->{$key} = 
               [ split /\s*,\s*/, uc($ref->{$server}->{$key}) ];
         }
         else {
            # for IncludeMessage or ExcludeMessage keys,
            # split the comma-separated values, evaluate each value 
            # as a regex, and put the regex into an array
            my @res;
            foreach my $re (split /\s*,\s*/, $ref->{$server}->{$key}) {
               $re = 'qr' . $re unless $re =~ /^\s*qr/;
               my $regex = eval $re;  # evaluate the qr// expression in eval()
               if ($@) {              # trap the error if not a valid regex
                   print "***Err: $re is not a valid regex.";
                   next;
               }
               push @res, $regex;  # add the compiled regex to the array
            }
            # now the key has a reference to an array of compiled regex'es            
            $ref->{$server}->{$key} = \@res;
         }
      }
   }
   return $ref;
} # getConfig

#########################
sub printEventLog {
   my ($server, $summaryRef, $configRef) = @_; 
   my (@keys);

   foreach my $log (@{$configRef->{$server}->{LOG}}) {
      @keys = sort {     $summaryRef->{$log}->{$b}->{Source} 
                     cmp $summaryRef->{$log}->{$a}->{Source} }
              (keys %{$summaryRef->{$log}});

      if (@keys) {
         print "\n", "*" x 50, "\n";
         print "***  Server = $server -- ", $log, " log ***\n";
         print "*" x 50, "\n";
      }

      foreach my $header (@keys) {
      printf " %-20s %-6s %-5s %s\n", 
             $summaryRef->{$log}->{$header}->{TimeGeneratedStr},
             "Total:", $summaryRef->{$log}->{$header}->{No}, $header;
      }
   }
} # printEventLog

__END__

=head1 NAME

eventLogSummary - Summarizing Windows event logs

=head1 SYNOPSIS

   cmd>perl eventLogSummary.pl <config file>

=head1 USAGE EXAMPLE

Assume you have the following options specified in the I<config.txt> file:

 [SQL1]
 Log = system,application
 LogElement = Type,Source,EventID,Message
 IncludeDays = 6
 IncludeType = Error,Warning
 ExcludeType =
 IncludeSource =
 ExcludeSource = MSSQLServer,SQLServerAgent,SQLExecutive
 IncludeEventID =
 ExcludeEventID =
 IncludeMessage =
 ExcludeMessage = /Import\s+Error/i
 
 [SQL2]
 Log = system
 LogElement = Type,Source,EventID
 IncludeDays = 7
 IncludeType = Error,Warning,Information
 ExcludeEventID = 6006,6009


In this example, the eventlog summary for SQL1 will include both errors and warnings but 
exclude all the log records from the source MSSQLServer, SQLServerAgent, and SQLExecutive. 
In case you wonder, the events from these sources are excluded from the summary because 
it's better to handle the SQL Server messages with a dedicated script. For SQL2, the 
summary will include records of all three types but without counting any log records with 
the event IDs 6006 and 6009. 

Below is an example of running of the script I<eventLogSummary.pl> with this config file:

 cmd>perl perl eventlogSummary.pl config.txt
 **********************************************************
 *** SQL Server = SQL1 -- APPLICATION log ***
 **********************************************************
 2002/04/26 14:02:01 #: 4124 INFORMATION, Source: Network, EventID: 1, Message:
                                om:boostrap succeeded 
 2002/04/25 18:16:26 #: 5 INFORMATION, Source: SysmonLog, EventID: 2023, Message:
                                Log SQL3 has been started or restarted and,
 2002/04/21 17:45:56 #: 6 ERROR, Source: SysmonLog, EventID: 2003, Message:
                                Unable to open the Performance Logs and Alerts,
 
 ****************************************************
 *** SQL Server = SQL1 -- SYSTEM log ***
 ****************************************************
 2002/04/26 01:06:01 #: 17 WARNING, Source: w32time, EventID: 11, Message:
                              The NTP server didn't respond,
 2002/04/25 18:59:31 #: 2  ERROR, Source: NETLOGON, EventID: 5719, Message:
                             No Windows NT or Windows 2000 Domain Controller is,
 2002/04/24 22:05:08 #: 5  WARNING, Source: Srv, EventID: 2013, Message:
                              The F: disk is at or near capacity. You may need,
                              

For readability, I've generously sanitized this printout by removing or truncating many entries. 
On a real-world server, you may need to filter out many more event sources to obtain a short 
summary that's pertinent to your job. 

This summary shows that the application log has 4,124 entries from a source named Network, 
which happened to be issued by a backup facility. If the log entries from this source have no 
impact on the SQL Server operations, you can include Network in the ExcludeSource list to further 
reduce the summary and let the owner of the backup facility worry about whether these 4,124 messages 
are of any concern. The numerous application log entries generated by SQL Server aren't shown in 
the summary because in the configuration file their sources (MSSQLServer and SQLServerAgent) are 
excluded. The SQL Server entries should be handled separately, which is the topic of the next section.


=head1 DESCRIPTION

This script gets the name of a configuration file from the command line. It then reads the
options specified in the configuration file. The script then loops through the servers specified 
in the section headings of the configuration file, and summarizes the event log for each server.

The script uses two key data structures, the configuration hash structure (I<$configRef>), and 
the summary hash structure (I<$summaryRef>). The former is created from reading the configuration 
file with the function I<getConfig()>, and the latter is produced by the function I<dbaReadEventLog()>, 
which is imported from the module SQLDBA::Utility. 

The function I<getConfig()> first calls I<dbaReadINI()> from SQLDBA::Utility to read the options 
from the configuration file into the variable I<$configRef>; it then traverses the data structure 
referenced by I<$configRef> to perform the following for each option:

=over

=item *

It removes the entry from I<$configRef> if no value is specified for the option. 

=item *

If the value is a comma-separated string, it splits the string by comma into an array of 
strings and assigns a reference to the array to the configuration option. 

=item *

However, for the option I<IncludeMessage> or I<ExcludeMessage>, the option value is expected to 
consist of comma-separated regular expressions. The function I<getConfig()> compiles each regular 
expression with the qr// operator in eval(). All the valid regular expressions are placed in an array, 
whose reference is assigned to the option. Invalid regular expressions are discarded.

=back

For the sample configurations shown in the USAGE EXAMPLE section, when the function I<getConfig()> 
finishes, the hash structure I<$configRef> contains the structure shown below: 

 $configRef = { 
            SQL1 => {
                  LOG => ['SYSTEM', 'APPLICATION'],
                  LOGELEMENT    => ['TYPE', 'SOURCE', 'eventid', 'MESSAGE'],
                  INCLUDEDAYS   => ['6'],
                  INCLUDETYPE   => ['ERROR', 'WARNING'],
                  EXCLUDESOURCE =>
                             ['MSSQLSERVER','SQLSERVERAGENT','SQLEXECUTIVE'],
                  EXCLUDEMESSAGE => [ qr/(?i-xsm:Import\s+Error)/ ]
            }
            SQL2 => {
                  LOG => ['SYSTEM'],
                  LOGELEMENT  =>    ['TYPE', 'SOURCE', 'EVENTID'],
                  INCLUDEDAYS =>    ['7'],
                  INCLUDETYPE =>    ['ERROR', 'WARNING', 'INFORMATION'],
                  EXCLUDEEVENTID => ['6006', '6009'] 
            }
 }


Briefly, I<$configRef> is a reference to a hash of hashes of arrays. If you aren't sure about what 
this all means, review the section "Using References and Nested Data Structures" in Chapter 1 and 
consult one of the Perl tutorial books listed in Appendix A, "Perl Resources."

In this example, the value of I<$configRef->{SQL1}->{EXCLUDEMESSAGE}> is a reference to an anonymous 
array whose only element is the following expression:

 qr/(?i-xsm:Import\s+Error)/


This expression returns a compiled regular expression. The I<Dumper()> function of Data::Dumper 
reconstructs this qr// expression. With I<$configRef>, the script loops through each server 
specified in the configuration file. For each server, it calls the function I<dbaReadEventLog()> 
to populate the hash structure I<$summaryRef> that records the log summary information and then 
prints the summary for that server with the function I<printEventLog()>. 

The function I<dbaReadEventLog()> is the heart of the script I<eventlogSummary.pl>. This
function is based on the same core engine in Listing 2-10 that iterates through the event 
log records on a given server.



=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaSetDiff dbaSetSame );
use Data::Dumper;

Main:{
   my $logFile = shift or die "Errorlog file must be specified.\n";
   my $logFile2 ="${logFile}_v1";

   dbaGetDeadlockEntries($logFile, $logFile2);
   my $deadlockRef = dbaGetDeadlockSummary($logFile2);
#print Dumper($deadlockRef);

   dbaPrintDeadlockSummary($deadlockRef);
} #Main

###############################
sub dbaGetDeadlockEntries {
   my ($logFile, $logFile2) =@_;
   
   open(LOG, "$logFile") or die "Cannot open $logFile for read.\n";
   open(LOG1, ">$logFile2") or die "Cannot open $logFile2 for write.\n";

   $_ = <LOG>;
   m{^\s*[\d\/\-]+\s+[\d\:\.]+\s+[\w\d]+\s+
                 Microsoft\s+SQL\s+Server\s+2000\s+}ix 
      or die "This is not a SQL 2000 errorlog.\n";

   my $deadlockON = 0;
   while (<LOG>) {
      if (/Deadlock\s+encountered\s+/i) {
         print LOG1 "Deadlock encountered\n";
         $deadlockON = 1;
         next;
      }
      if (m{^\s*[\d\/\-]+\s+[\d\:\.]+\s+[\w\d]+\s+
                             Node:\d+}ix && $deadlockON) {
         my $line = $_;
         while(<LOG>) {
            if (/^\s*[\d\/\-]+\s+[\d\:\.]+\s+[\w\d]+(\s+.+)/) {
               $line .= $1;
            }
            else {
               $line .= $_;
            }
            last if /^\s*[\d\/\-]+\s+[\d\:\.]+\s+[\w\d]+\s+ResType:LockOwner/;
         }
         $line =~ s/\n/ /g;
         print LOG1 "$line\n";
         next;
      }
      if (m{^\s*[\d\/\-]+\s+[\d\:\.]+\s+[\w\d]+\s+
                             Victim\s+Resource\s+Owner}ix && $deadlockON) {
         my $line = $_;
         $_ = <LOG>;
         /^\s*[\d\/\-]+\s+[\d\:\.]+\s+[\w\d]+\s+(.+)/ && ($line .= $1);
         $line .= $1;
         $line =~ s/\n/ /g;
         print LOG1 "$line\n";
         $deadlockON = 0;
         next;
      }
   }
   close(LOG);
   close(LOG1);
} # dbaGetDeadlockEntries

###############################
sub dbaGetDeadlockSummary {
   my ($logFile2) =shift;
   
   my $deadlockRef = {};
   my $i;
   $/ = "Deadlock encountered\n";
   open(LOG, "$logFile2") 
            or die "Cannot open $logFile2 for read.\n";
   while(<LOG>) {
      s/\s*Deadlock encountered\s*//;
      next if /^\s*$/;

      my $ref = {};
      for (split /\n/) { 
         /^\s*([\d\/\-]+\s+[\d\:\.]+)\s+[\w\d]+\s+/ 
                              and $ref->{time} = $1;

         if (m{ (Node:\d+)\s+(\w+:\s+[\d\:]+)\s+.+?
                 Grant\s+List::.+?(Mode:\s+[^\s]+)\s+.+
                 Input\s+Buf:\s+(.+)
                 Requested\s+by:.+?(Mode:\s+[^\s]+)\s+
              }ix) {
            $ref->{$1}->{resource} = $2;
            $ref->{$1}->{grantedLockMode} = $3;
            $ref->{$1}->{inputBuffer} = $4;
            $ref->{$1}->{requestedLockMode} = $5;
            push @{$ref->{signatures}}, "$2//$3//$4//$5";
         }
      }
print Dumper($ref);      
      # check whether a deadlock with that signature is already recorded
      my $found = 0;
      foreach my $d (keys %$deadlockRef) {
         if (dbaSetSame($deadlockRef->{$d}->{signatures}, $ref->{signatures})) {
            $deadlockRef->{$d}->{count}++;
            $deadlockRef->{$d}->{time} = $ref->{time};
            $found = 1;
            last;
         }
      }
      unless ($found) {
         ++$i;
         $deadlockRef->{$i} = $ref;
         $deadlockRef->{$i}->{count} = 1;
      }
   }
   close(LOG);
   return $deadlockRef;
} # dbaGetDeadlockSummary

############################
sub dbaPrintDeadlockSummary {
   my ($deadlockRef) = shift;
   
   foreach my $dl (sort keys %$deadlockRef) {
      print "*** Deadlock $dl\n";
      print "\tTime:  $deadlockRef->{$dl}->{time}\n";
      print "\tCount: $deadlockRef->{$dl}->{count}\n";
      foreach my $node (sort keys %{$deadlockRef->{$dl}}) {
         next if $node !~ /node:\d+/i;
         print "\t$node info:\n";
         print "\t\tResource:     ", 
                     "$deadlockRef->{$dl}->{$node}->{resource}\n";
         print "\t\tGranted Lock: ",
                     "$deadlockRef->{$dl}->{$node}->{grantedLockMode}\n";
         print "\t\tRequest Lock: ",
                     "$deadlockRef->{$dl}->{$node}->{requestedLockMode}\n";
         print "\t\tInput Buffer: ", 
               substr($deadlockRef->{$dl}->{$node}->{inputBuffer}, 0, 50), "\n";
      }
   }
} # dbaPrintdeadlockSummary

__END__

=head1 NAME

deadlockInfo - Analyzing deadlock traces

=head1 SYNOPSIS

   cmd>perl deadlockInfo.pl <config file>

=head1 USAGE EXAMPLE

If the errorlog is in d:\mssql\log folder, you can run the script as following to find and summarize 
the deadlock information recorded in the errorlog:

 cmd>perl deadlockSummary.pl d:\mssql\log\errorlog.txt

 *** Deadlock 1
    Last Occurred Time:  2002-04-12 00:55:19.32
    Count: 2
    Node:1 info:
        Resource:     KEY: 6:1977058079:1
        Granted Lock: Mode: U
        Request Lock: Mode: U
        Input Buffer: select * from employees (holdlock 
    Node:2 info:
        Resource:     KEY: 6:1977058079:1
        Granted Lock: Mode: U
        Request Lock: Mode: U
        Input Buffer: begin tran select * from employees 
 *** Deadlock 2
    Last Occurred Time:  2002-04-16 00:58:37.10
    Count: 150
    Node:1 info:
        Resource:     KEY: 6:1977058079:1
        Granted Lock: Mode: U
        Request Lock: Mode: U
        Input Buffer: begin tran select * from employees 
    Node:2 info:
        Resource:     KEY: 6:1977058079:1
        Granted Lock: Mode: U
        Request Lock: Mode: U
        Input Buffer: select * from employees (holdlock 
 *** Deadlock 3
    Last Occurred Time:  2002-04-18 09:50:46.27
    Count: 23
    Node:1 info:
        Resource:     TAB: 6:21575115
        Granted Lock: Mode: X
        Request Lock: Mode: X
        Input Buffer: select * from employees (holdlock tablockx)
    Node:2 info:
        Resource:     TAB: 6:1977058079
        Granted Lock: Mode: X
        Request Lock: Mode: X
        Input Buffer: select * from orders (holdlock 

In this output, the script I<deadlockSummary.pl> identifies three unique deadlocks. For each unique 
deadlock, it also reports the date and the time of its last occurrence and the total number 
of occurrences. In addition, the report includes the basic elements for each deadlock node. 

For instance, deadlock 3 in the output last logged at 9:50:46.27 on April 18, 2002, and was found 23 
times in the errorlog file. In each of these 23 occurrences, this deadlock had two nodes. 
On node 1, a process has been granted an exclusive lock on the table orders (object ID 21575115) 
while another process is requesting an exclusive lock on the same table and is being blocked. 
On node 2, the second process has been granted an exclusive lock on the table employees 
(object ID 1977058079) while the first process is trying to obtain another exclusive lock on 
the same table, thus causing a deadlock. Moreover, in each of the 23 occurrences, the input 
buffer of the corresponding node had the same SQL statement: select * from orders (holdlock tablockx) 
for node 1 and select * from employees (holdlock tablockx) for node 2.

=head1 DESCRIPTION

This script reads the errorlog specified on the command line, looks for unqiue deadlocks, and counts their 
occurences. Two deadlocks
are occurences of the same unique deadlock if they have the same I<node signature>, which is a concatenation 
of the resource name, the granted lock mode, the requested lock mode, and the input buffer. 

In practice, it is very common to see hundreds of deadlocks that are just occurences of a very small number
of unique deadlocks.

This script checks the node signature of each deadlock recorded in the errorlog and determines whether it
is an occurence of a deadlock already encountered, in which case the script increments the deadlock count, or 
whether it is a new unique deadlock, in which case the script records a new unique deadlock with 
a count of one.

To simplify the code that matches a deadlock node signature, the script first makes one pass through 
the errorlog file to pick out the entries related to the trace flag 1204, skipping all the 
other entries. This is the job of the function I<getDeadlockEntries()>. This pass produces an 
intermediate file consisting of the better-formatted lines for the deadlock chains. For each 
deadlock chain, the entries in this intermediate file are similar to the following:

 Deadlock encountered
 2002-04-16 00:55:19 spid4 Node:1 KEY... Grant List... Input Buf... Requested By:
 2002-04-16 00:55:19 spid4 Node:2 KEY... Grant List... Input Buf... Requested By: 
 2002-04-16 00:55:19 spid4 Victim Resource Owner: ... Mode: U ...

Recall that each element of a node may occupy multiple lines in the original trace flag output, 
and the input buffer often has embedded newlines. Also recall that when the script reads 
from the errorlog file, it reads in one line at a time. To mix inputting errorlog lines 
with searching for deadlock information in the same function would render the code unwieldy 
and not readable. Therefore, the script uses this preprocessing pass through the errorlog to 
extract the deadlock lines and format each deadlock chain as follows: 

=over

=item *

The output starts a deadlock chain with the string Deadlock encountered. 

=item *

Then, there are two or more lines, each for a single node.

=item *

The output ends the deadlock chain with a line containing the string Victim Resource Owner.

=back

With the trace flag output cleanly formatted as such, it becomes straightforward for the 
function I<getDeadlockSummary()> to apply pattern matching to capture the basic elements of each 
node and construct the node signature. Note that at the beginning of the function I<getDeadlockSummary()> 
the input record separator $/ is set to the string I<Deadlock encountered\n>, causing the angle 
operator (<>) in the while statement to slurp in one deadlock chain at a time, as opposed to one 
line at a time.

When the deadlock chain is completely read into the Perl predefined variable $_, the script 
splits the chain into separate strings, one for each node. Then, the following code segment in 
I<getDeadlockSummary()> matches each node string for the node elements -- including node resource, 
granted lock mode, input buffer, and requested lock mode -- and records the node elements in a hash 
structure:

 if (m{ (Node:\d+)\s+                             # node number
           (\w+:\s+[\w\d\:]+)\s+.+?               # node resource
           Grant\s+List::.+?(Mode:\s+[^\s]+)\s+.+ # granted mode
           Input\s+Buf:\s+(.+)                    # input buffer content
           Requested\s+by:.+?(Mode:\s+[^\s]+)\s+  # requested mode
      }ix) {
    $ref->{$1}->{resource} = $2;
    $ref->{$1}->{grantedLockMode} = $3;
    $ref->{$1}->{inputBuffer} = $4;
    $ref->{$1}->{requestedLockMode} = $5;
    push @{$ref->{signatures}}, "$2//$3//$4//$5";
 }

The following is an example of the hash structure for a two-node deadlock chain (edited for readability).

 $ref = {
         'Node:1' => {
              'requestedLockMode' => 'Mode: X',
               'resource' => 'TAB: 6:21575115',
               'inputBuffer' => 'select * from employees (holdlock tablockx)',
               'grantedLockMode' => 'Mode: X'
          },
         'Node:2' => {
               'requestedLockMode' => 'Mode: X',
               'resource' => 'TAB: 6:1977058079',
               'inputBuffer' => 'select * from orders (holdlock tablockx)',
               'grantedLockMode' => 'Mode: X'
          },
         'signatures' => [
               'TAB: 6:21575115//Mode: X//select ... //Mode: X',
               'TAB: 6:1977058079//Mode: X//select ... //Mode: X'
          ],
         'time' => '2002-04-18 09:50:46.27'
 }

Note that the above example has two separate node signatures, one for each node. The signature is the 
concatenation of the values of the node elements (node resource, granted lock mode, input buffer, and 
requested lock mode), separated by forward slashes. This hash structure records the information about 
a single occurrence of a deadlock. To keep the example short, the SQL statements in the input buffers 
aren't printed in full for the node signatures.

The data structure for the overall deadlock summary is similar but of course includes additional 
information.  The following is an example:

 $deadlockRef = {
    1 => {
       'count' => 24,
       'Node:1' => {
           'requestedLockMode' => 'Mode: U',
           'resource' => 'KEY: 6:1977058079:1',
           'inputBuffer' => 'select * from employees (holdlock rowlock updlock)',
             'grantedLockMode' => 'Mode: U'
        },
       'Node:2' => {
           'requestedLockMode' => 'Mode: U',
           'resource' => 'KEY: 6:1977058079:1',
           'inputBuffer' => 'select * from employees (holdlock rowlock updlock)',
             'grantedLockMode' => 'Mode: U'
        },
       'signatures' => [
           'KEY: 6:1977058079:1//Mode: U//select ... //Mode: U',
           'KEY: 6:1977058079:1//Mode: U//select ... //Mode: U'
        ],
       'time' => '2002-04-16 00:56:46.94'
   },
   2 => {
       'count' => 78,
       'Node:1' => {
           'requestedLockMode' => 'Mode: U',
           'resource' => 'KEY: 6:1977058079:1',
           'inputBuffer' => 'select * from employees (holdlock rowlock updlock)',
           'grantedLockMode' => 'Mode: U'
       },
       'Node:2' => {
           'requestedLockMode' => 'Mode: U',
           'resource' => 'KEY: 6:1977058079:1',
           'inputBuffer' => 'select * from employees (holdlock rowlock updlock)',
             'grantedLockMode' => 'Mode: U'
        },
       'Node:3' => {
           'requestedLockMode' => 'Mode: U',
           'resource' => 'KEY: 6:1977058079:1',
           'inputBuffer' => 'select * from employees (holdlock rowlock updlock)',
           'grantedLockMode' => 'Mode: U'
        },
       'signatures' => [
           'KEY: 6:1977058079:1//Mode: U//select * ...//Mode: U',
           'KEY: 6:1977058079:1//Mode: U//select * ...//Mode: U',
           'KEY: 6:1977058079:1//Mode: U//select * ...//Mode: U'
        ],
       'time' => '2002-04-16 01:07:00.38'
   },
 }

In the above hash structure, there are two unique deadlocks. A number identifies each deadlock, and 
this number is used as the key in the hash. At the time this structure is printed, the script 
I<deadlockSummary.pl> has found, in the trace flag 1204 output, 24 instances of deadlock 1 and 78 
instances of deadlock 2.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


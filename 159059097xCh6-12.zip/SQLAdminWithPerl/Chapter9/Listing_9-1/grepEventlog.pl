# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;

# import functions from the module SQLDBA::Utility
use SQLDBA::Utility qw ( dbaTime2str dbaSetDiff dbaStr2time
                         dbaSetCommon dbaInSet);
use Win32::EventLog;
use Data::Dumper;

# The global data structures %types, @types, @logs, @fields 
# are all used to help validate command line arguments
my %types = ( EVENTLOG_ERROR_TYPE       , 'ERROR', 
              EVENTLOG_INFORMATION_TYPE , 'INFORMATION',
              EVENTLOG_WARNING_TYPE     , 'WARNING',
            );
my @types  = values(%types);            
my @logs   = ('SYSTEM', 'APPLICATION');
my @fields = ('TYPE', 'SOURCE', 'EVENTID', 'MESSAGE');

Main: {
   my %opts;
   getopts('M:L:e:t:s:d:m:', \%opts); # get command line arguments

   # check and normalize command line arguments
   my $argsRef = checkArgs(\%opts);

   # scan the eventlog entries for matches
   grepEventLog($argsRef);
} # Main

#####################
sub checkArgs {
#####################
   my $argsRef = shift or 
      die "***Err: checkArgs() expects a reference.";

   my @temp;

   # check the -M option for computer name.
   # -M is mandatory
   defined $argsRef->{M} or
         die "***Err: option -M must be specified.";

   # check the -L option for log 'SYSTEM' and/or 'APPLICATION'
   # -L is mandatory
   defined $argsRef->{L} or
         die "***Err: option -L must be specified.";
   # get the specified eventlogs into an array
   @temp = map {s/^\s*//; s/\s*$//; uc($_)}
              (split /\s*[,;]\s*/, $argsRef->{L});
   for (dbaSetDiff(\@temp, \@logs)) {   # must be APPLICATION and/or SYSTEM
      die "***Err: $_ must be one of " . join(', ', @logs);
   }
   $argsRef->{L} = [ @temp ];  # convert it to a reference to an array

   # check the -e option for event IDs
   # -e is optional. If -e is not specified, all event IDs are scanned.
   @temp = map {s/^\s*//; s/\s*$//; uc($_)}
              (split /\s*[,;]\s*/, $argsRef->{e});
   $argsRef->{e} = [ @temp ] if @temp;

   # check -t option for event type
   # -t is mandatory. 
   defined $argsRef->{t} or
         die "***Err: option -t must be specified.";
   @temp = map {s/^\s*//; s/\s*$//; uc($_)} 
              (split /\s*[,;]\s*/, $argsRef->{t});
   for (dbaSetDiff(\@temp, \@types)) { 
        print "***Err: $_ must be one of " . join(', ', @types);
   }
   $argsRef->{t} = [ dbaSetCommon(\@temp, \@types) ]; # keep only the valids
   scalar @{$argsRef->{t}} or
      die "***Err: there must be at least one eventlog type.";

   # check -s option for event source
   # -s is optional, but must be a valid regular expression
   if (defined $argsRef->{s}) {
      my $re = 'qr' . $argsRef->{s} unless $argsRef->{s} =~ /^\s*qr/;
      my $regex = eval $re;
      if ($@) {
          die "***Err: $argsRef->{s} is not a valid regex.";
      }
      $argsRef->{s} = $regex;  # convert to compiled regex
   }

   # check -d option for date/time
   # -d is optional. If specified, it must include a date/time 
   # range with a hyphen. If the lower limit is not specified, it defaults
   # to the epoch. If the upper limit is not specified, it defaults to 
   # a year from the current time, i.e. time() + 3600*24*365.
   my ($d1, $d2);
   if ($argsRef->{d}) {
      $argsRef->{d} =~ /^[^\-]*\-[^\-]*$/ or 
         die "***Err: -d option must specify a date/time range with a hyphen.";
      ($d1, $d2) = split /\-/, $argsRef->{d};
   }
   # convert the date/time string to the epoch seconds
   $argsRef->{d1} = $d1 ? dbaStr2time($d1) : 0;
   $argsRef->{d2} = $d2 ? dbaStr2time($d2) : (time() + 3600*24*365);
   delete $argsRef->{d};      

   # check -m for message regular expression
   # -m is mandatory, and must be a valid regular expression.
   defined $argsRef->{m} or 
      die "***Err: option -m must be specified.";
   my $re = 'qr' . $argsRef->{m} unless $argsRef->{m} =~ /^\s*qr/;
   my $regex = eval $re;  # compile the regex to check its validity
   if ($@) {
       die "***Err: $argsRef->{m} is not a valid regex.";
   }
   $argsRef->{m} = $regex;  # convert to compiled regex
   return $argsRef;
} # checkArgs

#########################
sub grepEventLog {
   my $argsRef = shift or 
      die "***Err: grepEventLog() expects a reference.";
   my($handle, $eventRef);

   $Win32::EventLog::GetMessageText = 1;
   foreach my $log (@{$argsRef->{L}}) {   # APPLICATION and/or SYSTEM
      $handle = Win32::EventLog->new($log, $argsRef->{M}) 
                or die "***Err: could not open $log on $argsRef->{M}";
      # loop through the eventlog records backwards                
      while (    $handle->Read( EVENTLOG_BACKWARDS_READ | 
                                EVENTLOG_SEQUENTIAL_READ, 0, $eventRef)
              && $argsRef->{d1} < $eventRef->{TimeGenerated} 
              && $argsRef->{d2} > $eventRef->{TimeGenerated} ) {
         # for each record, check if it meets the criteria
         my $rc = matchLogEntry($argsRef, $eventRef);
         if ( $rc == 1 ) 
         {
            # for each record that meets the criteria, print a single 
            # string including date/time, type, source, ID, and message text
            my $msg = dbaTime2str($eventRef->{TimeGenerated});
            $msg .= ', ' . $types{$eventRef->{EventType}};
            $msg .= ', ' . $eventRef->{Source};
            $msg .= ', ' . ($eventRef->{EventID} & 0xffff);
            my $text = $eventRef->{Message};
            $text =~ s/[\n\r]/ /g;
            $msg .= ', ' . $text;
            print "$msg\n";
         }
      }    
      Win32::EventLog::CloseEventLog($handle);
   }
} #grepEventLog

######################
# this function is to make the if condition in grepEventLog() more readable
sub matchLogEntry {
   my ($argsRef, $eventRef) = @_;
   my $return = 0;

   # check event Type
   if (exists $argsRef->{t}) {
       return -1 if (!dbaInSet(uc($types{$eventRef->{EventType}}), 
                            $argsRef->{t}));
   }
   # now check event Source
   if (exists $argsRef->{s}) {
      return -2 unless eval { $eventRef->{Source} =~ /$argsRef->{s}/ }
   }
   # check event IDs
   if (exists $argsRef->{e}) {
       return -3 if (!dbaInSet($eventRef->{EventID} & 0xffff, 
                            $argsRef->{e}));
   }

   # now check message body
   if (exists $argsRef->{m}) {
      return -4 unless eval { $eventRef->{Message} =~ /$argsRef->{m}/ }
   }
   return 1;
} # matchLogEntry

__END__

=head1 NAME

grepEventlog - Extracting information from Windows event logs

=head1 SYNOPSIS

   cmd>perl grepEventlog.pl -M <computer name>
                            -L <event log>
                          [ -e <event IDs> ]
                            -t <event type>
                          [ -s <event source pattern> ]
                          [ -d <beginning date/time> - <end date/time> ]
                            -m <event message pattern>

=head1 COMMAND-LINE ARGUMENTS

 -M <computer name>         This mandatory argument specifies the computer name.
 -L <event log>             This mandatory argument specifies which event log to scan. 
                            It must be either SYSTEM or APPLICATION.
 -e <event IDs>             This optional argument accepts a list of comma-separated 
                            event IDs. If not specified, the script scans all the event 
                            IDs.
 -t <event type>            This mandatory argument specifies the type of the event. It 
                            can be information, warning, or error, or a comma-separated 
                            string of any of these three.
 -s <event source pattern>  This optional argument accepts a regular expression to 
                            include the event sources in the scan. The regular expression 
                            can be any valid Perl regular expression.
 -d <beginning date/time>-<end date/time>  This optional argument specifies a date/time 
                                           range. The script scans only the event log 
                                           entries in this range. If not specified, the script 
                                           scans all the event log entries. 
                                           The <beginning date/time> and <end date/time> are in 
                                           the format of YYYY/MM/DD hh:mm:ss. The time portion 
                                           is optional.
 -m <event message pattern> This mandatory argument specifies a regular expression to match 
                            the strings in the message text of the event log entries. The 
                            regular expression can be any valid Perl regular expression.

=head1 USAGE EXAMPLE

head2 Example 1

I ran the following command line on a machine named SQL1 and obtained the event log startup 
entries 
since 2003/03/02 15:23:32. The entire command line should be on the same line (I've split 
it into three lines for readability):

 cmd>perl eventlogGrep.pl -M SQL1 -L system -t information 
                          -d"2003/03/02 15:23:32-" 
                          -m"/event log service was started/i"
 2003/03/09 01:54:18, INFORMATION, EventLog, 6005, The Event log ... was started.
 2003/03/08 21:38:15, INFORMATION, EventLog, 6005, The Event log ... was started.
 2003/03/07 21:11:41, INFORMATION, EventLog, 6005, The Event log ... was started.
 2003/03/04 17:20:23, INFORMATION, EventLog, 6005, The Event log ... was started.
 2003/03/03 19:00:53, INFORMATION, EventLog, 6005, The Event log ... was started.
 2003/03/03 00:09:15, INFORMATION, EventLog, 6005, The Event log ... was started.
 2003/03/02 17:54:33, INFORMATION, EventLog, 6005, The Event log ... was started.

=head2 Example 2

The second example is to get the Windows process ID's for all the SQL Server instances 
on the computer SQL1. The following shows the command line and the results:

 cmd>perl eventlogGrep.pl -M SQL1 -L application -t information 
                          -s "/^MSSQL/i"
                          -d "2003/03/08 15:23:32-" 
                          -m "/SQL Server .+ using a process id of \d+/i" 
 2003/03/09 15:51:21, INFORMATION, MSSQL$SQL1, 17176 ... a process id of 1164
 2003/03/09 15:07:02, INFORMATION, MSSQL$SQL2, 17176 ... a process id of 564 
 2003/03/09 01:54:47, INFORMATION, MSSQL$SQL2, 17176 ... a process id of 596 
 2003/03/09 00:00:05, INFORMATION, MSSQL$SQL2, 17177 ... a process id of 596


=head1 DESCRIPTION

This script uses the Win32:EventLog module to scan the Windows event log for entries 
meeting the criteria specified on the command line. The highlight of this script is that
it accepts criteria that may be an arbitrary regular expression.

The script retrieves the command-line arguments with the module Getopt::Std. It then performs
extensive validation in the function I<checkArgs()>. You cannot simply use the criteria grabbed 
from the commend line as is. They may be invalid date/time string or invalid regular expressions.
Finally, the script calls the function I<grepEventLog()> to loop through the event log entries, going 
from the latest and checking the entries against the criteria one entry at a time.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


use strict;

my $traceLog = shift or
   die "***Err: $0 expects an ODBC trace log file.";
   
my $sql;   
open(TRACE, $traceLog) or die "***Err: failed to open $traceLog for read.";
while(<TRACE>) {
   # look for SQLExecDirect or SQLPrepare
   if (/ENTER\s+(SQLExecDirect|SQLPrepare)/i) {
      <TRACE>;                          # skip the first parameter
      $_ = <TRACE>;                     # this should be the 2nd parameter
      if (/WCHAR\s+\*[^\"]+\"(.+)\"/) { # the 2nd paramter has this pattern
         $sql = $1;
         $sql =~ s/\\ d\\ a/\n/g;       # replace \d \ a with \n
         $sql =~ s/\\ 0//g;             # remove the terminating null charatcer
         $sql .= "\n" unless $sql =~ /\n$/; # append a newline if not present
         print $sql;
      }
      else {  # if the 2nd parameter doesn't, the problem isn't handled
         print "***Err: incorrect code path. Should never be here.\n";
      }
   }
}
close(TRACE);

__END__

=head1 NAME

getODBCSQL - Extracting SQL statements from an ODBC trace file

=head1 SYNOPSIS

   cmd>perl getODBCSQL.pl <ODBC trace log file>

=head1 USAGE EXAMPLE

Assume that the file I<SQL.log> is an ODBC trace log. You can run the script as follows to 
extract the SQL statements captured by the log file:

 cmd>perl getODBCSQL.pl SQL.log
 SELECT au_id FROM "authors"
  WHERE au_id = '123-43-4523'
 SELECT au_id FROM "authors"
  WHERE au_id = '123-43-4523'
 SELECT au_id FROM "authors"
  WHERE au_id = '123-43-4523'
 SELECT au_id FROM "authors"
  WHERE au_id = '123-43-4523'
 EXEC sp_who
 EXEC sp_who
 EXEC sp_who
 EXEC sp_who

In this example, each SQL query was logged four times in the trace log I<SQL.log> because 
the I<SQLExecDirect> function was entered four times. The number of times a query is 
logged in the ODBC trace log may be different if you run the same query using a 
different application such as osql.exe. Unfortunately, it's not clear how you can 
remove the extraneous copies of the SQL queries recorded in an ODBC trace log.


=head1 DESCRIPTION

This script is based on the following observations with respect to the content of an ODBC trace
log:

=over

=item *

An ODBC trace records SQL queries when it logs the ODBC functions I<SQLExecDirect()> and 
I<SQLPrepare()>. The second parameter of these two functions includes a SQL query.

=item *

ODBC trace records each ODBC function twice, once when the function begins and once 
when the function exits.

=item *

ODBC trace records each embedded carriage return -- linefeed combination as \ d \ a, which 
is the ASCII value 13 followed by the ASCII value 10.

=item *

ODBC trace encloses a SQL query with a pair of double quotation marks. However, it doesn't 
escape any embedded double quotes.

=back

The script I<getODBCSQL.pl> implements these observations to extract the SQL statements
from an ODBC trace log.

The primary motivation of the script is to demonstrate that you can first study the text 
patterns in a file and then apply Perl's powerful text processing features to find and 
extract information from the file. You can do much more with ODBC trace logs beyond 
extracting the SQL queries. For instance, if you're troubleshooting an ODBC application, 
you may be more interested in extracting the SQL queries that are logged when the execution 
exits the SQLExecDirect function and an error code is recorded in the trace log.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


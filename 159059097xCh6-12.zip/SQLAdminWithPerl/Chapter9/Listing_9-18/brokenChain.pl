# See the embedded POD or the HTML documentation

use strict;
use Data::Dumper;

my $logFile = shift or die "The script expects an errorlog file.\n";

Main: {
   my $ref = dbaReadLogChain($logFile);
   dbaPrintBrokenLogChain($ref);
} # Main


#######################
sub dbaReadLogChain {
#######################
   my ($logFile) = shift or "dbaReadLogChain expects a file name.";
   open(LOG, "$logFile") or die "Could not open $logFile for read.";

   my ($ref, $time, $type, $dbName, $first, $last);
   while (<LOG>) {
      # match only the backup entries and ignore others
      if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+
               (Database|log)\s+backed\s+up.+Database:\s+([^,]+)\,.+
               first\s+LSN:\s+([\d:]+)\,\s+last\s+LSN:\s+([\d:]+)\,}ix) {
         ($time, $type, $dbName, $first, $last) = ($1, $2, $3, $4, $5);
      }
      else {
         next;   # skip if not a backup entry
      }

      # work on database backup entry
      if ($type =~ /database/i) {
         $ref->{$dbName}->{wasDBBackup} = 1;
         $ref->{$dbName}->{logChainBroken} = 0;  # restart a good log chain
         next;
      }

      # log backup SQL7, 2000
      if ($type =~ /log/i) {
         # skip it if log chain already broken. All subsequent log entries
         # are ignored until next full backup
         next if $ref->{$dbName}->{logChainBroken};
         $ref->{$dbName}->{logTime} = $time;
         if (!exists $ref->{$dbName}->{firstLSN} ||  # first log backup or
             $ref->{$dbName}->{wasDBBackup} ) {      # first after a full backup
               $ref->{$dbName}->{logChainBroken} = 0; # assume a good start
               $ref->{$dbName}->{firstLSN} = $first;
               $ref->{$dbName}->{lastLSN} = $last;
         }
         else { 
            # if immediate preceding backup is a log backup,  
            # compare the current first LSN with the previous last LSN
            if ($first eq $ref->{$dbName}->{lastLSN}) {
               $ref->{$dbName}->{logChainBroken} = 0; 
               $ref->{$dbName}->{firstLSN} = $first;
               $ref->{$dbName}->{lastLSN} = $last;
            }
            else {
               $ref->{$dbName}->{logChainBroken} = 1; 
               $ref->{$dbName}->{firstLSN} = $first;
               $ref->{$dbName}->{lastLSN} = $last;
            }
         }

         # remember this is not a full backup to help interpret 
         # the next backup entry
         $ref->{$dbName}->{wasDBBackup} = 0;
         next;
      }   
   }
   close(LOG);
   return $ref;
} # dbaReadLogChain

################################
sub dbaPrintBrokenLogChain {
################################
   my ($ref) = shift 
      or die "dbaPrintBrokenLogChain expects a reference.";
   
   foreach my $dbName (sort keys %$ref) {
      next if !$ref->{$dbName}->{logChainBroken};
      printf "%s %s log backup chain broken, first/last LSN: %s/%s\n", 
             $ref->{$dbName}->{logTime},
             $dbName,
             $ref->{$dbName}->{firstLSN}, 
             $ref->{$dbName}->{lastLSN};
   }
#   print Dumper($ref);
} # dbaPrintBrokenLogChain

__END__

=head1 NAME

brokenChain - Checking transaction log backup chains

=head1 SYNOPSIS

   cmd>perl brokenChain.pl <errorlog file>

=head1 USAGE EXAMPLE

Let's use the following T-SQL script to create two scenarios in which the transaction log chain is broken:

 use pubs 
 go
 create table tbTest (i int)
 go
 alter database pubs set recovery full
 backup database pubs to pubsDBback
 insert tbTest values(123)
 backup log pubs to pubsLogBack1
 insert tbTest values(123)
 /* break the log backup chain */
 backup log pubs with no_log
 backup log pubs to pubsLogBack2
 insert tbTest values(123)
 backup log pubs to pubsLogBack3
 go
 
 use myDB
 go
 create table tbTest (i int)
 go
 alter database myDB set recovery full
 backup database myDB to myDBback
 insert tbTest values(123)
 backup log myDB to myDBLogBack1
 insert tbTest values(123)
 go
 /* break the log backup chain */
 alter database myDB set recovery simple
 checkpoint
 alter database myDB set recovery full
 go
 backup log myDB to myDBLogBack2
 insert tbTest values(123)
 backup log myDB to myDBLogBack3
 go

Assume that the errorlog is in D:\mssql\log, and if you run the script brokenChain.pl as follows, 
the output from the script will look like the following:

 cmd>perl brokenChain.pl d:\mssql\log\errorlog

 2002-05-01 16:13 pubs log backup chain broken,first/last LSN: 6:375:1/6:375:1
 2002-05-01 16:13 myDB log backup chain broken,first/last LSN: 29:482:1/29:482:1

With the information reported here, you should investigate the log backups of the databases 
pubs and myDB at around 4:13 P.M., May 1, 2002. It's most likely that both log backup chains 
were broken there, and your database backup and recovery is in jeopardy.

=head1 DESCRIPTION

This script scans the errorlog, specified on the command line, for broken transaction log backup chains.
The script relies on the following observations:

=over

=item *

If the entry is a database backup, simply take note that this is a database backup.

=item *

If the entry is the first log backup in the errorlog for the database, or is the first log 
backup after a full database backup, you can assume the log chain is good at this point.

=item *

The third situation is when the entry isn't the first log backup in the errorlog, and there's 
an immediate preceding log backup with no database backup in between. In this case, if 
the first LSN of this log backup matches the last LSN of the previous log backup, the log 
backup chain remains good. Otherwise, it's broken.

=back

Note the possibility that the errorlog might have been recycled recently, leaving you only 
the tail of the chain with which to work. To keep it simple, this script checks only the current errorlog.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


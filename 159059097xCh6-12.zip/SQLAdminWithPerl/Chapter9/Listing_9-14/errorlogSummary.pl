# See the embedded POD or the HTML documentation

use strict;
use Win32;

# Import functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaReadINI dbaTime2str dbaStr2time );

Main: {
   my $configFile = shift;
   # if the config file is not found, abort
   (-e $configFile) or 
      die "***Err: config file $configFile doesn't exist.";

   # Read config file into $configRef and validate it
   my $configRef = dbaReadINI($configFile);
   $configRef = validateConfig($configRef);

   # Now scan and summarize each errorlog
   foreach my $server (sort keys %$configRef) {
     # scan and summarize SQL Server errorlog
     my $logRef = scanErrorlog($server, $configRef->{$server});

     # Now print out the errorlog summary
     printLogSummary($logRef, $server, $configRef->{$server});
   }
} # Main

##########################
sub validateConfig {
   my $configRef = shift or 
      die "***Err: validateConfig() expects a reference.";
   my $server;

   # set the default if an option is not specified
   foreach my $server (keys %$configRef) {
      # default LogWarningSize to 5000KB   
      $configRef->{$server}->{LOGWARNINGSIZE} =~ /^\d+/ or
         $configRef->{$server}->{LOGWARNINGSIZE} = 5000;

      # default LogStopSize to 10000KB
      $configRef->{$server}->{LOGSTOPSIZE} =~ /^\d+/ or
         $configRef->{$server}->{LOGSTOPSIZE} = 10000;

      # default ScanErrorlogLastDays to 5 days
      $configRef->{$server}->{SCANERRORLOGLASTDAYS} =~ /^\d+/ or
         $configRef->{$server}->{SCANERRORLOGLASTDAYS} = 5;

      # default WarnMissingBackupLastDays to 2 days
      $configRef->{$server}->{WARNMISSINGBACKUPLASTDAYS} =~ /^\d+/ or
         $configRef->{$server}->{WARNMISSINGBACKUPLASTDAYS} = 2;

      # default ExcludeBackupHistory to no
      $configRef->{$server}->{EXCLUDEBACKUPHISTORY} =~ /^(y|n)/i or
         $configRef->{$server}->{EXCLUDEBACKUPHISTORY} = 'no';

      # default ExcludeDBCCHistory to no
      $configRef->{$server}->{EXCLUDEDBCCHISTORY} =~ /^(y|n)/i or
         $configRef->{$server}->{EXCLUDEDBCCHISTORY} = 'no';
   }

   # check whether errorlog files are specified
   foreach my $server (sort keys %$configRef) {
      unless ( exists $configRef->{$server}->{SQLERRORLOG} ) {
         print "***Err: SQLErrorlog not specified for $server.\n";
         print "     Server $server errorlog will not be scanned.\n";

         # if its errorlog is not specified,
         # remove the server from the scan list
         delete $configRef->{$server};
      }
   }
   return $configRef;
}  # validateConfig


##########################
sub scanErrorlog {
   my($server, $serverRef) = @_;
   die "scanErrorlog() expects a server name and a reference."
         unless (defined $server && defined $serverRef);

   my $ref;
   my $sqlErrorlog = $serverRef->{SQLERRORLOG};

   # Check whether the errorlog file exists
   unless (-e $sqlErrorlog) { 
      $ref->{notExist} = "***Errorlog $sqlErrorlog doesn't exist.";
      return $ref; 
   }

   # Get errorlog actual size in KB
   $ref->{actualLogsize} = int((stat($sqlErrorlog))[7]/1024);

   # Check errorlog size
   if ($ref->{actualLogsize} >= $serverRef->{LOGSTOPSIZE}) {
      $ref->{logsizeError} = 
            "***Errorlog over $serverRef->{LOGSTOPSIZE} KB.";
      return $ref;        # too big to bother openning it
   }
   elsif ($ref->{actualLogsize} >= $serverRef->{LOGWARNINGSIZE}) {
      $ref->{logsizeWarning} = 
            "***Errorlog over $serverRef->{LOGWARNINGSIZE} KB.";
   }
   # now open the errorlog file for scan
   unless (open(LOG, "$sqlErrorlog")) {
      $ref->{logOpenError} = "***Could not open $sqlErrorlog for read. ";
      $ref->{logOpenError} .= Win32::FormatMessage(Win32::GetLastError);
      return $ref;
   }

   # from the very first errorlog line, get the SQL version and 
   # the date/time of the first entry
   $_ = <LOG>;
   if (/^\s*([\d\/\-]+\s+[\d\:\.]+)\s+[^\s]+\s+(Microsoft\s+SQL .+)/i) {
      ($ref->{firstRecordedDate}, $ref->{sqlVersion}) = ($1, $2);
   }

   # skip old errorlog entries
   my $prevLine;
   while ($prevLine = $_, <LOG>) {
      if (/^\s*([\d\/\-]+\s+[\d\.\:]+)\s+/) {
         next if ( (time() - dbaStr2time($1)) > 
                         $serverRef->{SCANERRORLOGLASTDAYS} * 24*3600 );
         $ref->{startCheckDatetime} = $1;
         last;
      }
   }

   # now start scan and summarize the errorlog entries
   while (<LOG>) {
     # SQL7,2000: for regular SQL errors , capture the error # and severity
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+
               Error\s*\:\s*(\d+)\s*\,\s*Severity\s*\:\s*(\d+)}ix) {
         # identify the error with error # and severity
         my $error = "$2\_$3";

         $ref->{$error}->{time} = $1;       # always record the date/time
         $ref->{$error}->{type} = 'error';
         $ref->{$error}->{error} = $2;      # error #
         $ref->{$error}->{severity} = $3;   # severity
         $ref->{$error}->{no}++;            # increase the tally
         # the message text is on the next line
         $_ = <LOG>;                
         /^\s*[^\s]+\s+[^\s]+\s+[^\s]+\s+(.+)\s*$/ and
               ($ref->{$error}->{msg} = substr($1, 0, 80));
         next;
     }

     # SQL7,2000: record and count failed db/log backups
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+
               backup+\s+(BACKUP\s+failed)\s+to\s+complete.+
               (database|log)\s+([^\s]+)}ix) {
         # identify the entry with 'BACKUP failed' + 'database' + <DB name>
         #                      or 'BACKUP failed' + 'log' + <DB name>
         my $error = "$2\_$3\_$4";
         $ref->{failedBackup}->{$error}->{time} = $1;
         $ref->{failedBackup}->{$error}->{type} = 'failedBackup';
         $ref->{failedBackup}->{$error}->{msg} = "$2 $3 $4";
         $ref->{failedBackup}->{$error}->{no}++;
         next;
     }

     # SQL7,2000: record SQL warnings
     if (/^\s*([\d\/\-]+\s+[\d\.\:]+)\s.+(Warning.+)$/i) {
         my $warning = lc($2);

         $ref->{warning}->{$warning}->{time} = $1;
         $ref->{warning}->{$warning}->{type} = 'warning';
         $ref->{warning}->{$warning}->{msg} = $warning;
         $ref->{warning}->{$warning}->{no}++;
         next;
     }

     # SQL7: count the # of deadlocks
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+
               (\*\*\*\s*Deadlock\s+Detected)}ix) {
         $ref->{deadlock}->{time} = $1;
         $ref->{deadlock}->{type} = 'deadlock';
         $ref->{deadlock}->{msg} = $2;
         $ref->{deadlock}->{no}++;
         next;
     }

     # SQL2000: count the # of deadlocks
     if (m{^\s*Deadlock\s+encountered}ix) {
         $prevLine =~ /^\s*([\d\/\-]+\s+[\d\.\:]+)\s+/;
         $ref->{deadlock}->{time} = $1;
         $ref->{deadlock}->{type} = 'deadlock';
         $ref->{deadlock}->{msg} = '*** Deadlock encountered';
         $ref->{deadlock}->{no}++;
         next;
     }

     # SQL7,2000: record and count process killed
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+
               (Process\s+id\s+\d+\s+killed\s+.+)$}ix) {
         $ref->{kill}->{time} = $1;
         $ref->{kill}->{type} = 'kill';
         $ref->{kill}->{msg} = $2;
         $ref->{kill}->{no}++;
         next;
     }

     # SQL7,2000: record and count stack dumps
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+
               (SqlDumpExceptionHandler:)}ix) {
         $ref->{stackDump}->{time} = $1;
         $ref->{stackDump}->{type} = 'stackDump';
         $ref->{stackDump}->{msg} = $2;
         $ref->{stackDump}->{no}++;
         next;
     }

     # SQL7,2000: record and count database starting up 
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+
               (Starting\s+up\s+database\s+\'([^\']+)\')}ix) {
         my $db = "startingDatabase_" . $3;
         $ref->{$db}->{time} = $1;
         $ref->{$db}->{type} = 'startingDatabase';
         $ref->{$db}->{msg} = $2;
         $ref->{$db}->{no}++;
         next;
     }

     # SQL7,2000: record and count successful DB backups
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+
               Database\s+backed\s+up.+Database:\s+([^,]+)\,}ix) {
         my $error = $2 . "_dbBackup";
         $ref->{$error}->{time} = $1;
         $ref->{$error}->{type} = 'dbBackup';
         $ref->{$error}->{database} = $2;
         $ref->{$error}->{msg} = "DB $2 last backed up at $1";
         $ref->{$error}->{no}++;
         next;
     }

     # SQL7,2000: record and count successful log backups
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+
               Log\s+backed\s+up.+Database:\s+([^,]+)\,}ix) {
         my $error = $2 . "_logBackup";
         $ref->{$error}->{time} = $1;
         $ref->{$error}->{type} = 'logBackup';
         $ref->{$error}->{database} = $2;
         $ref->{$error}->{msg} = "Log for DB $2 last backed up at $1";
         $ref->{$error}->{no}++;
         next;
     }

     # SQL7,2000: record and count DBCC CHECKDB's
     if (m{^\s*([\d\/\-]+\s+[\d\.\:]+)\s+[^\s]+\s+DBCC\s+CHECKDB\s+
             \(([^)]+)\).+found\s+(\d+)\s+.+repaired\s+(\d+)}ix) {
         my $error = $2 . "_checkdb";
         $ref->{$error}->{time} = $1;
         $ref->{$error}->{type} = 'checkdb';
         $ref->{$error}->{database} = $2;
         $ref->{$error}->{msg} = "DBCC last CHECKDB $2";
         $ref->{$error}->{no}++;
         $ref->{$error}->{FoundErrors} = $3;
         $ref->{$error}->{RepairedErrors} = $4;
         next;
     }
   }  
   close(LOG);
   return $ref;
}  # scanErrorlog
    
##############################
sub printLogSummary {
   my($ref, $server, $serverRef) = @_;

   print "\n***Server: $server\n";
   print "Checking errorlog $serverRef->{SQLERRORLOG}\n";
   if (exists $ref->{notExist}) {
      print "  $ref->{notExist}\n";
      return;
   }

   if (exists $ref->{logsizeError}) {
      print "  $ref->{logsizeError}\n";
   }
   elsif(exists $ref->{logOpenError}) {
      print "  $ref->{logOpenError}\n";
   }
   else {
      print "  SQL Server restarted or errorlog recycled at: ";
      print "$ref->{firstRecordedDate}\n";
      print "  $ref->{sqlVersion}\n";
      if ($ref->{logsizeWarning}) {
         print "  $ref->{logsizeWarning}\n";
      }
      else {
         print "  Errorlog size = $ref->{actualLogsize} KB\n";
      }
      if ($ref->{startCheckDatetime}) {
         print "  Checking entries newer than $ref->{startCheckDatetime}\n";
      }
      else {
         print "  ***Errorlog does not have any entries less ";
         print "than $serverRef->{SCANERRORLOGLASTDAYS} days old.\n";
      }

      # print backup history summary
      my @backups = grep {/_(db|log)Backup$/i} (keys %$ref);
      if ($serverRef->{EXCLUDEDATABASES}) {
         @backups = grep !/^$serverRef->{EXCLUDEDATABASES}/i, @backups;
      }

      unless ($serverRef->{EXCLUDEBACKUPHISTORY} =~ /y/i) {
         if (@backups) {
             printf "\n  %-11s %-25s %-20s %5s\n", 'Type', 'Database', 
                                          'Last Backup Time', 'Total';
             printf "  %-11s %-25s %-20s %5s\n", '-' x 11, '-' x 25, 
                                          '-' x 20, '-' x 5;
             foreach my $backup (sort @backups)  {
                 printf "  %-11s %-25s %-20s %5d\n", 
                        $ref->{$backup}->{type}, 
                        substr($ref->{$backup}->{database}, 0, 25),
                        substr($ref->{$backup}->{time}, 0, 19), 
                        $ref->{$backup}->{no};
             }
         }
      }

      # print a warning if no backup is found for a database 
      # when errorlog has more than two-day history
      if ( time() - dbaStr2time($ref->{firstRecordedDate}) 
                  > 3600*24*$serverRef->{WARNMISSINGBACKUPLASTDAYS}) { 
         my %backupTime;
         foreach my $backup (@backups) {
            if ($backupTime{$ref->{$backup}->{database}}) {
               if (  dbaStr2time($backupTime{$ref->{$backup}->{database}})
                           < dbaStr2time($ref->{$backup}->{time})  ) {
                   $backupTime{$ref->{$backup}->{database}} = $ref->{$backup}->{time}; 
               }
            }
            else {
               $backupTime{$ref->{$backup}->{database}} = $ref->{$backup}->{time};    
            }
         }
         # use grep() to find the keys whose values evaluate the code to true
         my @dbs = grep { time() - dbaStr2time($backupTime{$_}) 
                            > 3600*24*$serverRef->{WARNMISSINGBACKUPLASTDAYS} } 
                        keys %backupTime;
         print "\n" if scalar @dbs;
         foreach my $db (@dbs) {
             my $msg = "  ***Warning: $db was not backed up within last ";
             $msg .= "$serverRef->{WARNMISSINGBACKUPLASTDAYS} days\n";
             print $msg;
         }
      }

      # print DBCC history
      unless ($serverRef->{EXCLUDEDBCCHISTORY} =~ /y/i) {
         my @checkdbs = grep {/_checkdb$/i} (keys %$ref);

         if (@checkdbs) {
             printf "\n  %-28s %-8s\n", ' ' x 29, "Found";
             printf "  %-8s %-20s %-8s %-20s %5s\n", 
                    'Type', 'Database', 'Errors', 'Last DBCC Time', 'Total';
             printf "  %-8s %-20s %-8s %-20s %5s\n", 
                        '-' x 8, '-' x 20, '-' x 8, '-' x 20, '-' x 5;
             foreach my $dbcc (sort @checkdbs)  {
                 printf "  %-8s %-20s %-8d %-20s %5d\n", 
                              $ref->{$dbcc}->{type}, 
                              substr($ref->{$dbcc}->{database}, 0, 25),
                              $ref->{$dbcc}->{FoundErrors},
                              substr($ref->{$dbcc}->{time}, 0, 19), 
                              $ref->{$dbcc}->{no};
             }
         }
      }

      # print deadlock summary
      if (ref $ref->{deadlock}) {
         print "\n  $ref->{deadlock}->{msg}, Last occurred: ";
         print "$ref->{deadlock}->{time},";
         print " Total #: $ref->{deadlock}->{no}\n";
      }

      # print process killed summary
      if (ref $ref->{kill}) {
         print "\n  Process killed. Total #: $ref->{kill}->{no}, "; 
         print "Last occurred: $ref->{kill}->{time}\n";
         print   "\t\t$ref->{kill}->{msg},\n";
      }

      # print stackDump summary
      if (ref $ref->{stackDump}) {
         print "\n  $ref->{stack_dump}->{msg}, ";
         print "Last occurred: $ref->{stackDump}->{time},";
         print " Total #: $ref->{stackDump}->{no}\n";
      }

      # print warning summary
      if (ref $ref->{'warning'}) {
         foreach my $warning (keys %{$ref->{'warning'}}) {
             print "\n  $ref->{'warning'}->{$warning}->{msg},";
             print " Last occurred: $ref->{'warning'}->{$warning}->{time},";
             print " Total #: $ref->{'warning'}->{$warning}->{no}\n";
         }
      }

      # print failedBackup summary
      if (ref $ref->{failedBackup}) {
         print "\n";
         foreach my $failedBackup (keys %{$ref->{failedBackup}}) {
             print "  $ref->{failedBackup}->{$failedBackup}->{msg},";
             print " Last occurred: $ref->{failedBackup}->{$failedBackup}->{time},";
             print " Total #: $ref->{failedBackup}->{$failedBackup}->{no}\n";
         }
      }

      # print avError summary
      if (ref $ref->{avError}) {
         print "\n  $ref->{avError}->{msg}, Total #: $ref->{avError}->{no}\n";
      }

      # print database startup summary
      my @errors = grep {/startingDatabase/i} keys %$ref;
      print "\n" if @errors;
      foreach my $error (@errors) {
         next if $ref->{$error}->{NO} <= 3;
         my ($database) = $error =~ /startingDatabase_(.+)/;
         print "  $ref->{$error}->{msg}, Total #: $ref->{$error}->{no},";
         print "  Last occurred: $ref->{$error}->{time}\n";
      }

      # print Error_Severity summary
      my @errors = grep {/^\d+_\d+$/} keys %$ref;
      print "\n" if @errors;
      foreach my $error (@errors) {
         if (ref $ref->{$error}) {
             print "  Err: $ref->{$error}->{error}, ";
             print "Severity: $ref->{$error}->{severity}, ";
             print " Total #: $ref->{$error}->{no}, Last occurred: ";
             print "$ref->{$error}->{time}\n";
             print "\t\t$ref->{$error}->{msg}\n";
         }
      }
   }    
}  # printLogSummary

__END__

=head1 NAME

errorlogSummary - Summarizing SQL Server errorlogs

=head1 SYNOPSIS

   cmd>perl errorlogSummary.pl <config file>

=head1 USAGE EXAMPLE

Assume you have the following sample configuration options in the config.txt file:

 [SQL1]
  SQLErrorlog=\\SQL1\H$\MSSQL\LOG\Errorlog
  LogWarningSize=3000
  LogStopSize=10000
  ScanErrorlogLastDays = 3
  ExcludeBackupHistory = no
  ExcludeDBCCHistory = no
  ExcludeDatabases = NorthWind,pubs
  WarnMissingBackupLastDays=1
 
 [SQL2\APOLLO]
  SQLErrorlog=\\SQL2\H$\MSSQL\APOLLO\log\Errorlog
  LogWarningSize=3000
  LogStopSize=10000
  ScanErrorlogLastDays = 3
  ExcludeBackupHistory = yes
  ExcludeDBCCHistory = yes
  ExcludeDatabases = NorthWind,pubs,ComDB
  WarnMissingBackupLastDays=2

Run I<errorlogSummary.pl> on the command line as follows to see the result:

 cmd>perl errorlogSummary.pl config.txt
 
 ***Server: SQL1
 Checking SQL errorlog \\SQL1\H$\MSSQL\LOG\Errorlog 
   SQL Server restarted or errorlog recycled at: 2002-04-12 04:38:55.50
   Microsoft SQL Server 2000 - 8.00.384 (Intel X86) 
   Errorlog size = 254 KB
   Checking errorlog entries younger than 2002-04-22 07:05:01.15
 
   Type             Database         Last Backup Time      Total
   ---------------- ---------------- --------------------- --------
   db_backup        ComDB             2002-04-24 17:38:31  6
   log_backup       ComDB             2002-04-25 06:45:01  124
   db_backup        NetDB             2002-04-22 17:38:31  3
   db_backup        master            2002-04-25 16:10:41  3
   db_backup        msdb              2002-04-25 16:10:47  3
 
   ***Warning: NetDB was not backed up within last 1 days
 
                                Found   
   Type          Database       Errors     Last DBCC Time         Total
   ------------- -------------- ---------- ---------------------- -----
   checkdb       ComDB          0          2002-04-24 20:16:11    3
   checkdb       NetDB          0          2002-04-24 19:10:06    3
   checkdb       master         0          2002-04-24 19:00:03    3
   checkdb       model          0          2002-04-24 19:00:04    3
   checkdb       msdb           0          2002-04-24 19:00:05    3
 
   Err: 50000, Severity: 19, Total #: 3, Last occurred: 2002-04-24 10:00:06.90
                B drive on SQL1 is below 200MB.
   Err: 14421, Severity: 16, Total #: 4319, Last occurred: 2002-04-25 06:49:00.64
                The log shipping destination SQL1.NetDB is out of sync by 16890
 
   warning: unable to allocate 'min server memory' of 450mb., 
                Last occurred: 2002-04-23 19:24:02.75, Total #: 1
   Err: 1204, Severity: 19, Total #: 18, Last occurred: 2002-04-23 18:13:46.67
                The SQL Server cannot obtain a LOCK resource at this time.
   Process killed. Total #: 6, Last occurred: 2002-04-22 16:15:42.26
                Process ID 72 killed by hostname WSW060, host process ID 498.
 
 ***Server: SQL2\APOLLO
 Checking SQL errorlog \\SQL2\H$\MSSQL\APOLLO\LOG\Errorlog
   SQL Server restarted or errorlog recycled at: 2002-04-17 17:37:28.34
   Microsoft SQL Server 7.00 - 7.00.842 (Intel X86) 
   Errorlog size = 530 KB
   Checking errorlog entries younger than 2002-04-22 07:02:02.57
 
   Starting up database 'RecDB', Total #: 10, Last occurred: 2002-04-24 22:05:29

The first thing to notice in the above output is that it's a significantly condensed report 
compared with the two actual SQL Server errorlogs. The I<errorlogSummary.pl> script is able 
to achieve this reduction with no loss of useful information, primarily by removing the old 
errorlog entries and by  collapsing the repetitive messages. 

For instance, for the server 
SQL1, 4,319 entries of the log shipping error message are replaced with the following single entry:

 Err: 14421, Severity: 16, Total #: 4319, Last occurred: 2002-04-25 06:49:00.64
              The log shipping destination SQL1. NetDB is out of sync by 16890

This entry in the summary report represents the latest recording of the error, along with the 
total count of the error in the errorlog.

In the report, also notice that there's a backup summary table and a DBCC CHECKDB summary table. 
They make it visually convenient to spot any inconsistencies. The backup summary has helped me 
several times in my own environments to catch database backups that failed to get performed. 
Of course, in an ideal environment, your SQL Server monitoring system should have caught 
missing database backups. However, we all know that most environments are not ideal and will 
never be. Things do fall through the cracks in any monitoring infrastructure. Therefore, a 
summary report such as this one gives you an additional means to rescue you from blissful ignorance.

For the server SQL2\APOLLO, the script reports that it was started 10 times during the past 
three days. This may or may not be a problem, but it needs to be investigated. If the report brings 
a potential issue to the attention of the DBA, it has added value to your SQL Server support service.

=head1 CONFIGURATION OPTIONS

The following configuration options can be specified in the configuration file:

=over

=item SQLErrorlog 

This option specifies the full path to the errorlog. The script uses this path to open the errorlog 
file. The path should use the Uniform Naming Convention (UNC) so that you can run the script 
from any machine.

=item LogWarningSize 

If the size of the errorlog is greater than this kilobyte value, a warning message will be included 
in the summary report, but the script will proceed to scan the errorlog. If not specified, 
it defaults to 5,000 kilobytes (KB).

=item LogStopSize 

If the script detects that the size of the errorlog exceeds this threshold (in kilobytes), it will 
not open the file. Instead, only a note is made in the summary. It defaults to 10,000KB.

=item ScanErrorlogLastDays 

This option specifies how many days the script should go back during its scan of the errorlog. Any 
entry with an older time stamp will be skipped. The default is five days if the option isn�t specified.

=item ExcludeBackupHistory 

When this option is set to no or isn't specified at all, a table will be included in the summary to 
show the number of database backups and log backups performed. 

=item ExcludeDBCCHistory   

This is similar to the previous option. When it�s set to no or not specified at all, the table shows 
the history of DBCC CHECKDB instead. The table also includes the number of errors found by DBCC.

=item ExcludeDatabases  

There may be databases whose backups are of no concerns to you, and you don�t want to see these 
databases in the backup summary. This option specifies a comma-separated list of databases that 
are excluded from the backup history table that the script may otherwise print. In the above example
configuraion file, the backup summary for the server SQL2\APOLLO won't include the databases 
Northwind, pubs, and ComDB.

=item WarnMissingBackupLastDays  

If the script finds a database with no database backup for this many days and the database isn't 
excluded with the ExcludeDatabases option, the script issues a warning in the summary.

=back


=head1 DESCRIPTION

This script scans the errorlogs of the SQL Server instances specified in a configuration file, and 
summarizes the errorlog files by taking advantage of the following observations:

=over

=item *  

The errorlogs are text files.

=item *

They contain a significant amount of "noise" that's not totally useless but that needs not be 
reviewed by a DBA everyday.

=item *

There's a lot of repetitions of the same or essentially the same messages.

=item *

The bulk of the errorlog is old and obsolete.

=item *

The errorlog entries exhibit recognizable text patterns although not always consistent, 
especially between SQL Server versions.

=back

These characteristics make Perl a good tool to help out with errorlog analysis. This 
script is written to scan all the SQL Server errorlogs; find the information deemed important; 
ignore nonessential, repetitive, or old messages; and produce a succinct summary report. 
The summary gives a huge "conceptual compression ratio" without losing any critical information. 

The script includes the following items in an errorlog summary:

=over

=item Errorlog header

When not recycled, the first part of the errorlog contains important information on server startup and 
database startup. I want to include any abnormal or nonstandard startup behavior. An example is when 
SQL Server complains about not being able to obtain the allocated memory or not being able to listen 
on a port.

=item Size of the errorlog file

If the errorlog becomes very large, it's often indicative of trouble somewhere. If it becomes 
extraordinarily large, you would want to skip scanning the file altogether. It's good enough to 
just note in the summary that it's too large, and you can later take care of it manually.

=item Database startups

If a database starts up too many times within a short time span, it could be caused by the autoclose 
database option being set to true, and in an enterprise environment that generally isn�t best practice.

=item Regular SQL Server errors

These are regularly formatted SQL Server error messages with error numbers and severity levels, for 
instance, Error: 14421, Severity: 16.

=item SQL Server warnings

It turns out that some warning messages can be more important than many error messages. For instance, 
you wouldn't want to miss the warnings on memory shortage.

=item Deadlocks

Setting trace flags 1204 and 3605 directs SQL Server to write deadlock information to the errorlog. 
A few deadlocks are normal. You�d want to be informed when there are too many deadlocks.

=item Stack dumps and Access Violations (AV)

Prior to SQL Server 7.0, AV errors are not well formatted when written to the errorlog. Since SQL 
Server 7.0, scanning for regular SQL Server errors with error numbers and severity levels will 
catch most of them, if not all.

=item DBCC CHECKDB entries

Every time that a DBCC CHECKDB is performed, it's noted with an entry in the errorlog along with the 
total number of errors found for each database.

=item Backups

Whenever a database or transaction log is backed up, it's noted in the errorlog. Both the successful 
backups and the failed backup attempts are recorded.

=item Process killed

It�s probably difficult to find a DBA who hasn�t had the pleasure to terminate a user connection. 
In some environments, this has become routine. In a well-run environment, this is really an 
extraordinary event and should be noted as such.

=back

Most of the items listed previously have multiple entries in the errorlog, some of them recurring 
frequently. That's where the bulk of the repetition lies. By condensing the repetitions of an item 
to a statistical count, you significantly reduce the amount of the information you have to absorb.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

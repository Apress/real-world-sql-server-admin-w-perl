# See the embedded POD or the HTML documentation

use strict;

# Import functions from the module SQLDBA::Utility
use SQLDBA::Utility qw ( dbaTime2str dbaSetDiff dbaSetCommon dbaInSet
                         dbaReadINI dbaReadEventLog dbaFilterLogEntry );
                         
Main: {
   my $configFile = shift or 
         die "***Err: config file must be specified on the command line.";
   (-e $configFile) or die "Config file $configFile does not exist.";

   # get config options
   my $configRef = getConfig($configFile);
   
   # read and summarize the eventlog entries for each server
   foreach my $server (sort keys %$configRef) {
     my $summaryRef = dbaReadEventLog($server, \&dbaFilterLogEntry, $configRef);
     printIPPorts($server, $summaryRef, $configRef);
   }
} # Main

##################
sub getConfig {
   my $configFile = shift or die "***Err: getConfig() expects a file name.";

   my $ref = dbaReadINI($configFile);
   foreach my $server (keys %$ref) {
      foreach my $key (keys %{$ref->{$server}}) {
         if (! defined $ref->{$server}->{$key}) {
            delete $ref->{$server}->{$key};
            next;
         }
         if ($key !~ /(includeMessage|ExcludeMessage)/i) {
            $ref->{$server}->{$key} = 
               [ split /\s*,\s*/, uc($ref->{$server}->{$key}) ];
         }
         else {
            my @res;
            foreach my $re (split /\s*,\s*/, $ref->{$server}->{$key}) {
               $re = 'qr' . $re unless $re =~ /^\s*qr/;
               my $regex = eval $re;
               if ($@) {
                   print "***Err: $re is not a valid regex.";
                   next;
               }
               push @res, $regex;
            }
            $ref->{$server}->{$key} = \@res;
         }
      }
   }
   return $ref;
} # getConfig

#########################
sub printIPPorts {
   my ($server, $summaryRef, $configRef) = @_; 
   my (@keys);

   foreach my $log (@{$configRef->{$server}->{LOG}}) {
      @keys = sort {     $summaryRef->{$log}->{$a}->{Source} 
                     cmp $summaryRef->{$log}->{$b}->{Source} }
              (keys %{$summaryRef->{$log}});

      if (@keys) {
         print "\n", "*" x 50, "\n";
         print "***  Server = $server ***\n";
         print "*" x 50, "\n";
      }

      foreach my $header (@keys) {
         my ($source, $msg) = $header =~ /Source: (.+?,) EventId.+SQL server (listening.*)/i;
         printf " %-20s %2s %-3s %s\n", 
             $summaryRef->{$log}->{$header}->{TimeGeneratedStr},
             "#:", $summaryRef->{$log}->{$header}->{No}, "$source $msg";
      }
   }
} # printEventLog

__END__

=head1 NAME

scanIPPorts - Scanning for IP addresses and TCP ports used by SQL Server

=head1 SYNOPSIS

   cmd>perl scanIPPorts.pl <config file>

=head1 USAGE EXAMPLE

Assume you have the following sample configuration options in the config.txt file:

 [SQL1]
 log = application
 LogElement = Type, Source, EventID, Message
 IncludeDays = 10
 IncludeType = Information
 IncludeEventID = 17055
 IncludeMessage = /SQL server listening on/i

The options in this example are for the server SQL1 only. You can specify the options for 
multiple machines in the configuration file by including multiple sections.

Run I<scanIPPorts.pl> on the command line as follows 
to report the IP addresses and ports used by the SQL Server instances running on the machine SQL1:

 cmd>perl scanIPPorts.pl config.txt
 **************************************************
 ***  Server = SQL1 ***
 **************************************************
  2003/01/31 10:17:09  #: 5   MSSQL$APOLLO, listening on 170.242.93.97: 2433.,
  2003/02/02 10:33:05  #: 17  MSSQL$APOLLO, listening on 127.0.0.1: 2433.,
  2003/02/02 10:33:05  #: 17  MSSQL$APOLLO, listening on TCP, Named Pipes.,
  2003/02/02 14:59:34  #: 5   MSSQL$PANTHEON, listening on 127.0.0.1: 1057.,
  2003/01/28 13:47:50  #: 1   MSSQL$PANTHEON, listening on 170.242.93.97: 1057.
  2003/02/02 14:59:38  #: 5   MSSQL$PANTHEON, listening on TCP, Shared Memory.,

This report shows how many times various IP addresses and ports were used during the 10 days prior 
to the time when the script was run.


=head1 DESCRIPTION

The script I<scanIPPorts.pl> relies on the fact that each SQL Server instance records a message
similar to the one below during its startup:

 SQL server listening on 127.0.0.1: 2433.

In addition, the event log fields of this message have the following characteristics:

=over

=item *

The event type is information.

=item *

The event ID is 17055.

=item *

The event source is MSSQLServer or MSSQL$ followed by the SQL Server instance name.

=back

This script is nearly identical to I<eventLogSummary.pl> in Listing 9-5. However, it formats the
output differently with the function I<printIPPorts()>.

If you wish, you can actually use the script I<grepEventLog.pl> to retrieve all the entries that
contain the IP addresses and port numbers. For instance, you can run the script I<grepEventLog.pl>
as follows:

 cmd>perl grepEventlog.pl -M SQL1 -L application -t information 
                          -d "2003/03/04-" 
                          -m "/SQL\s+server\s+listening\s+on\s+[\d.]+/i"
 2003/03/11 17:32:38, INFORMATION, MSSQL$SQL1, 17055, ... on 170.25.60.1: 2433.
 2003/03/10 03:10:14, INFORMATION, MSSQL$SQL1, 17055, ... on 170.25.60.1: 2433.
 2003/03/09 15:51:28, INFORMATION, MSSQL$SQL2, 17055, ... on 170.25.60.1: 1057.
 2003/03/07 21:12:51, INFORMATION, MSSQL$SQL1, 17055, ... on 170.25.60.1: 2433.



=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


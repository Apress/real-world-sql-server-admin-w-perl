# See the embedded POD or the HTML documentation

use strict;
use Win32::OLE;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaSMTPSend dbaTime2str dbaSaveRef dbaInStrList
                        dbaReadSavedRef dbaIsBetweenTime dbaReadINI );
use Win32::Service;
use Data::Dumper;

Main: {
   my $configFile = shift;
   unless ($configFile) { printUsage(); exit; }

   (-T $configFile) or 
         die "***Err: Specified config file $configFile does not exist.";

   # Read config file into $configRef
   my $configRef = dbaReadINI($configFile);

   # validate config options and set defaults
   $configRef = validateConfig($configRef);

   my $statusRef = (-T $configRef->{CONTROL}->{STATUSFILE}) 
                     ? dbaReadSavedRef($configRef->{CONTROL}->{STATUSFILE})
                     : {};

   my $ref = { Config => $configRef, Status => $statusRef };

   # Check availability
   $ref = checkAvailability($ref);

   #  Decide whether to send an alert
   $ref = alertAvailability($ref);

   print Dumper($ref);
   # Save status to the status file
   dbaSaveRef($configRef->{CONTROL}->{STATUSFILE}, $ref->{Status}, 'ref');
} # Main

############################
sub printUsage {
############################
    print << '--Usage--';
Usage:  

 perl monitorAvailability.pl <Config File> 
    <Config File> file to specify config options for monitoring availability
--Usage--
}

#######################
sub validateConfig {
#######################
   my $configRef = shift or 
      die "***Err: validateConfig() expects a reference.";
   
   foreach my $server (sort keys %{$configRef}) {
      next if $server =~ /^control$/i;
      next if $configRef->{$server}->{DISABLED} =~ /^y/i;
      
      if (!defined $configRef->{$server}->{ALERTINTERVAL} or
          $configRef->{$server}->{ALERTINTERVAL} !~ /\d+/) {
          $configRef->{$server}->{ALERTINTERVAL} = 15;
      }
   }   
   return $configRef;
} # validateConfig

##########################
sub checkAvailability {
##########################
   my $ref = shift or 
         die "***Err: checkAvailability() expects a reference.";

   foreach my $server (sort keys %{$ref->{Config}}) {
      next if $server =~ /^control$/i;
      next if $ref->{Config}->{$server}->{DISABLED} =~ /^y/i;
      
      my ($instance) = $server =~ /^SERVER\s*:\s*(.+)$/i;
      my $statusRef = $ref->{Status}->{$server};
      
      print "Checking $instance...\n";
      CHECK_HEALTH: {
         # Ping the server
         if ($ref->{Config}->{$server}->{CHECKPING} =~ /^y/i and 
             !isPingOK($instance)) {
            $statusRef->{Ping}->{OK} = 0;
            $statusRef->{Ping}->{LastFailed} = dbaTime2str();
            $statusRef->{BadStatusCounter}++;
            $statusRef->{ErrMsg} = 'Failed to ping ' . $instance;
            last CHECK_HEALTH;
         }
         else {
            $statusRef->{Ping}->{OK} = 1;
         }
         # login to the instance
         if ($ref->{Config}->{$server}->{CHECKCONNECTION} =~ /^y/i and 
             !isSQLConnectOK($instance)) {
            $statusRef->{SQLConnect}->{OK} = 0;
            $statusRef->{SQLConnect}->{LastFailed} = dbaTime2str();
            $statusRef->{BadStatusCounter}++;
            $statusRef->{ErrMsg} = 'Failed to connect to ' . $instance;
            last CHECK_HEALTH;
         }
         else {
            $statusRef->{SQLConnect}->{OK} = 1;
         }
         # Check SQLAgent
         if ($ref->{Config}->{$server}->{CHECKSQLAGENT} =~ /^y/i and
             !isSQLAgentOK($instance)) {
            $statusRef->{SQLAgent}->{OK} = 0;
            $statusRef->{SQLAgent}->{LastFailed} = dbaTime2str();
            $statusRef->{BadStatusCounter}++;
            $statusRef->{ErrMsg} = "SQLAgent on $instance is not running";
            last CHECK_HEALTH;
         }
         else {
            $statusRef->{SQLAgent}->{OK} = 1;
         }
         #check DB status
         if ($ref->{Config}->{$server}->{CHECKDATABASES} =~ /^y/i) {
            my $DBStatusRef = getDBStatus($ref, $server);
            if (!$DBStatusRef->{OK}) {
               $statusRef->{DB}->{OK} = 0;
               $statusRef->{DB}->{LastFailed} = dbaTime2str();
               $statusRef->{BadStatusCounter}++;
               $statusRef->{ErrMsg} = $DBStatusRef->{DBMsg};
               $statusRef->{DB}->{DBMsg} = $DBStatusRef->{DBMsg};
               last CHECK_HEALTH;
            }
            else {
               $statusRef->{DB}->{OK} = 1;
            }
         }
         else {
            $statusRef->{DB}->{OK} = 1;
         }
         # Check SQLMail
         if ($ref->{Config}->{$server}->{CHECKSQLMAIL} =~ /^y/i and
             !isSQLMailOK($instance)) {
            $statusRef->{SQLMail}->{OK} = 0;
            $statusRef->{SQLMail}->{LastFailed} = dbaTime2str();
            $statusRef->{BadStatusCounter}++;
            $statusRef->{ErrMsg} = "SQLMail on $instance is not running";
            last CHECK_HEALTH;
         }
         else {
            $statusRef->{SQLMail}->{OK} = 1;
         }
      }   

      # Now update the overall status
      if ( $statusRef->{Ping}->{OK}       &&
           $statusRef->{SQLConnect}->{OK} &&
           $statusRef->{SQLAgent}->{OK}   &&
           $statusRef->{SQLMail}->{OK}    &&
           $statusRef->{DB}->{OK}) {
         $statusRef->{OK} = 1;
         $statusRef->{BadStatusCounter} = 0;
      }
      else {
         $statusRef->{OK} = 0;
      }
      $ref->{Status}->{$server} = $statusRef;
   }
   return $ref;
} # checkAvailability

####################
sub isPingOK {
####################
    my $server = shift or
      die "***Err: IsPingOK() expects a server name.";

    $server =~ s/\\.+$//;  # remove the instance name, if any

    use Net::Ping;
    my $p = Net::Ping->new("icmp");
    my $r = $p->ping($server, 2);
    $p->close();
    return $r;
} # IsPingOK

###########################
sub isSQLConnectOK {
###########################
   my $server = shift or 
      die "***Err: IsSQLConnectOK() expects a server name.";

   my $conn = Win32::OLE->new('ADODB.Connection') or return 0;
   $conn->{ConnectionTimeout} = 2;
   $conn->Open("Driver={SQL Server};Server=$server;Trusted_Connection=yes");
   my $state = $conn->{State};
   $conn->Close();
   return $state;
} # isSQLConnectOK

#########################
sub isSQLAgentOK {
#########################
   my $server = shift or 
      die "***Err: isSQLAgentOK() expects a server name.";

   my ($serverName, $instanceName) = $server =~ /^([^\\]+)\\([^\\]+)$/i;
   my $conn = Win32::OLE->new('ADODB.Connection') or return 0;
   $conn->{ConnectionTimeout} = 2;
   $conn->Open("Driver={SQL Server};Server=$server;Trusted_Connection=yes");

   my $rc = 0;
   my $sql = q/EXEC master..xp_cmdshell 'net start'/;
   my $rs = $conn->Execute($sql);
   if ($rs) {
      while ( !$rs->{EOF} ) {
         my $info = $rs->Fields('output')->{Value};
            if (! $instanceName) {
              $rc = 1 if $info =~ /(SQLExec|SQLServerAgent)/i;
            }
            else {
              $rc = 1 if $info =~ /SQLAgent\$$instanceName/i;
            }
         $rs->MoveNext();
      }
      $rs->Close;
   }
   $conn->Close;
   return $rc if $rc;
   
   # now if xp_cmdshell does not work, try Win32::Service
   my ($key, %services, %status);

   Win32::Service::GetServices($serverName,\%services);
   foreach $key (keys %services){
      if ($key =~ /(SQLExecutive|SQLServerAgent)/i) {
         Win32::Service::GetStatus( $serverName, $services{$key}, \%status);
         if($status{CurrentState} eq "4"){
             return 1;
         }
      }
   }
   return 0;
} # isSQLAgentOK

#############################
sub isSQLMailOK {
#############################
   my $server = shift or 
      die "***Err: isSQLMailOK() expects a server name.";

   my $conn = Win32::OLE->new('ADODB.Connection') or return 0;
   $conn->{ConnectionTimeout} = 2;
   $conn->Open("Driver={SQL Server};Server=$server;Trusted_Connection=yes");

   my $rc = 0;
   my $sql = q/ declare @rc int 
                set nocount on
                create table #tmp (a varchar(125) null)
                insert #tmp EXEC @rc = master..xp_findnextmsg
                select 'output' = @rc/;
   my $rs = $conn->Execute($sql);
   if ($rs) {
      while ( !$rs->{EOF} ) {
         $rc = $rs->Fields('output')->{Value};
         $rs->MoveNext();
      }
      $rs->Close;
   }
   $conn->Close();
   return !$rc;
} # isSQLMailOK

########################
sub restartSQLMail {
########################
   my $server = shift or 
      die "***Err: restartSQLMail() expects a server name.";

   my $conn = Win32::OLE->new('ADODB.Connection') or return 0;
   $conn->{ConnectionTimeout} = 2;
   $conn->Open("Driver={SQL Server};Server=$server;Trusted_Connection=yes");
   my $sql = q/EXEC master..xp_startmail /;
   my $rs = $conn->Execute($sql);
   $conn->Close();
} # restartSQLMail

########################
sub getDBStatus {
########################
   my ($ref, $server) = @_;  # $server is expected to have SERVER: prefix
   my $configRef = $ref->{Config}->{$server};
   my $DBStatusRef = $ref->{Status}->{$server}->{DB};
   
   my ($instance) = $server =~ /^SERVER\s*:\s*(.+)$/i;

   my $conn = Win32::OLE->new('ADODB.Connection');
   $conn->{ConnectionTimeout} = 2;
   $conn->Open("Driver={SQL Server};Server=$instance;Trusted_Connection=yes");
   if (!$conn->{State}) {
      $DBStatusRef->{OK} = 0;
      $DBStatusRef->{DBMsg} = "Failed to connect to $instance";
      return $DBStatusRef;
   }
   
   # get the database names first
   my @DB = ();
   my $sql = q/select name from master..sysdatabases 
                where name not in ('pubs', 'model', 'NorthWind')   
                  and name not like '%test%' /;

   my $rs = $conn->Execute($sql);
   if ($rs) {
      while ( !$rs->{EOF} ) {
         @DB = (@DB, $rs->Fields('name')->{Value});
         $rs->MoveNext();
      }
      $rs->Close;
   }
   else {
       $DBStatusRef->{OK} = 0;
       $DBStatusRef->{DBMsg} = "Problem executing $sql";
       return $DBStatusRef;
   }

   my $badDB = undef;
   foreach my $db (@DB) {
      $sql = qq/set quoted_identifier on 
                select count(*) from \"$db\"..sysobjects 
                 where name = 'sysobjects'/;
      # construct a list of databases that cannot be queried
      unless ($rs = $conn->Execute($sql)) {
         my $dbErr = 'Msg: ' . Win32::OLE->LastError();  
         # check whether Offline mode is excluded from alerting
         next if ($dbErr =~ /Database.+is\s+offline/is and 
                  dbaInStrList($db, $configRef->{EXCLUDEOFFLINE}));
         # check whether Loading mode is excluded from alerting
         next if ($dbErr =~ /Database.+is\s+in.+\s+restore/is and 
                  dbaInStrList($db, $configRef->{EXCLUDELOADING}));
         $badDB .= " $db";
      } 
   }
   if ($badDB) {
      $DBStatusRef->{OK} = 0;
      $DBStatusRef->{DBMsg} = "Problem querying database(s):$badDB";
      return $DBStatusRef;
   }
   else {
      $DBStatusRef->{OK} = 1;
   }
   $conn->Close();
   return $DBStatusRef;
} # getDBStatus

#############################
sub alertAvailability {
#############################
   my $ref = shift or 
      die "***Err: alertAvailability() expects a reference.";

   foreach my $server (sort keys %{$ref->{Config}}) {
      next if $server =~ /^control$/i;
      next if $ref->{Config}->{$server}->{DISABLED} =~ /^y/i;
      
      my ($instance) = $server =~ /^SERVER\s*:\s*(.+)$/i;
      my $statusRef = $ref->{Status}->{$server};

      my @receivers = split (/[;,\s]+/, $ref->{Config}->{$server}->{DBAPAGER});
      @receivers = ($ref->{Config}->{CONTROL}->{DUTYPAGER}) unless @receivers;

      # if there is a problem for more than two consecutive times, 
      # and it is not quiet time,
      # and it has been longer than the AlertInterval since an alert was last sent 
      # send an alert
      if ($ref->{Status}->{$server}->{OK} == 0 and
          $ref->{Status}->{$server}->{BadStatusCounter} > 2 and 
          !dbaIsBetweenTime($ref->{Config}->{QuietTime}) and 
          (time() - $ref->{Status}->{$server}->{LastAlertSentTime}) 
                         > ($ref->{Config}->{$server}->{ALERTINTERVAL})*60 ) {
          
            if (dbaSMTPSend($ref->{Config}->{CONTROL}->{SMTPSERVER}, 
                         \@receivers, 
                         $ref->{Config}->{CONTROL}->{SMTPSENDER},
                         undef,
                         $ref->{Status}->{$server}->{ErrMsg})) {
               $ref->{Status}->{$server}->{AlertSent} = 1;
               $ref->{Status}->{$server}->{LastAlertSentTime} = time();
               $ref->{Status}->{$server}->{LastAlertSentTimeStr} = dbaTime2str();
               $ref->{Status}->{$server}->{BadStatusCounter} = 0;

               open(LOG, ">>$ref->{Config}->{CONTROL}->{ALERTLOGFILE}");
               printf LOG "%s  %s. Sent to %s\n", dbaTime2str(), 
                                         $ref->{Status}->{$server}->{ErrMsg},
                                         $ref->{Config}->{$server}->{DBAPAGER};
               printf "\t%s  %s. Sent to %s\n", dbaTime2str(), 
                                         $ref->{Status}->{$server}->{ErrMsg},
                                         $ref->{Config}->{$server}->{DBAPAGER};
               close(LOG);
            }
      }
   }
   return $ref;
} # alertAvailability

__END__

=head1 NAME

monitorAvailability - Monitoring SQL Server availability: the robust version

=head1 SYNOPSIS

 cmd>perl monitorAvailability.pl <Config File> 

      <Config File> file to specify config options for monitoring availability


=head1 CONFIGURATION OPTIONS

The following is a sample configuration file for two SQL Server instances, SQL1 and SQL1\APOLLO.

 [Control]
 AlertLogFile=Alert.log
 StatusFile=status.log
 DutyPager=74321@myTel.com
 SMTPServer=mail.linchi.com
 SMTPSender=dba@linchi.com
 
 [Server:SQL1]
 Disabled=no
 DBAPager=71234@myTel.com 
 
 CheckPing=yes
 CheckConnection=yes
 CheckSQLAgent=yes
 CheckDatabases= yes
 CheckSQLMail=no
 QuietTime=18-8
 AlertInterval=20
 
 [Server:SQL1\APOLLO]
 Disabled=no
 DBAPager=75114@myTel.com 
 
 CheckPing=yes
 CheckConnection=yes
 CheckSQLAgent=yes
 CheckDatabases=yes
 CheckSQLMail=yes
 QuietTime=24-6
 AlertInterval=15
 ExcludeLoading=RDM,UDM
 ExcludeOffline=Survey

The list below describes all the configuration options you can specify in the [Control] section 
of the configuration file accepted by the script I<monitorAvailability.pl>.

=over

=item AlertLogFile   

Every time an alert is sent, a log entry is written to the text file specified by this option.

=item StatusFile  

The script persists the status data structure for the availability monitoring to this file.

=item DutyPager   

This specifies the email address. Alerts goes to this address if the DBAPager option for the 
server isn't specified.

=item SMTPServer  

This is the SMTP server that all the outgoing notification messages use.

=item SMTPSender  

This is the SMTP account to identify the sender of the alert messages.

=back

The following is the list of the configuration options you can specify for a given SQL Server instance (e.g.
[Server:SQL1] in the previous example):


=over

=item Disabled 

If this is set to yes, this SQL Server instance won't be checked for availability.

=item DBAPager 

All notifications will be sent to this email address.

=item CheckPing   

The script pings the server for reachability only if the option is set to yes.

=item CheckConnection   

The script performs the connectivity check on the SQL Server instance only if the option is set to yes.

=item CheckDatabases 

The script queries each database to verify whether the database is usable only if the option is set to yes.

=item CheckSQLAgent  

The script tries to determine whether the SQLServerAgent is online only if the option is set to yes.

=item CheckSQLMail   

The script won't check whether SQL Mail is responsive only if the option is set to yes.

=item QuietTime   

This option expects two values in the format of hh-hh, where hh is between 1 and 24, inclusive. 
This option specifies that between these two hours, no alerts should be sent.

=item AlertInterval  

This option expects an integer that specifies the number of minutes that must elapse before another 
alert on this SQL Server instance can be sent.

=item ExcludeLoading 

This option expects a comma-separated list of database names. If any of these databases is in the 
loading mode, the database usability check won�t flag it as unusable.

=item ExcludeOffline 

This option expects a comma-separated list of database names. If any of these databases is offline, 
the database won�t be flagged as unusable.

=back

=head1 DESCRIPTION

The script I<monitorAvailability.pl> monitors SQL Server availability with respect to the
following questions: 

=over

=item *

Can the script ping the server?

=item *

Can the script connect to the SQL Server instance?

=item *

Can the script query the databases?

=item *

Is SQL Server Agent running?

=item *

Is SQL Mail running?

=back

The flow of the script is nearly identical to that of the script I<monitorErrorlogs.pl>. 
It consists of the following steps:

=over

=item 1.

The script I<monitorAvailability.pl> first reads the configuration options from the configuration file 
supplied on the command line and reads the status information -- saved by the previous invocation of 
the script -- from the status file specified with the option I<StatusFile> in the configuration 
file. The script then combines the data structure for the configuration options and the data 
structure for the status information into a single data structure referenced by I<$ref>. The 
script uses the data structure $ref throughout the rest of the script.

=item 2.

The script updates the status data structure I<$ref->{Status}> with the function I<checkAvailability()>, 
which performs the specified availability checks for each of the SQL Server instances 
listed in the configuration file.

=item 3.

Next, the function I<alertAvailability()> inspects the updated I<$ref> data structure, 
applies the notification rules to decide whether to send any alert, and actually sends the 
alert if one is deemed necessary. This function also updates the I<$ref> data structure to 
record the information related to sending the alert.

=item 4.

Finally, the script calls the SQLDBA::Utility function I<dbaSaveRef()> to save the status data 
structure I<$ref->{Status}> to be used when the script runs the next time. Note that the key 
information to save for each SQL Server instance is the number of consecutively failed 
availability checks and the last time an alert is sent. These two pieces of information are 
used to help the script make better notification decisions.

=back

=head1 DETECTING DATABASE AVAILABILITY

The function I<getDBStatus()> performs the job of detecting that a database has become unusable. It
does so by running a query against the database. To determine whether the query has run into 
any problem, the function checks the ADO resultset and the error condition returned by 
executing the following query from the master database:

 SET QUOTED_IDENTIFIER ON 
 SELECT count(*) FROM "<db>"..sysobjects 
 WHERE name = 'sysobjects'

where <db> is the name of the database to be checked. When the SQL Server instance fails 
to execute this query, the resultset from the ADO Execute method is undefined. 

Things become more interesting when you need to exclude a database that's offline or 
in the loading mode from triggering an alert. To avoid having to explicitly deal with various 
versions of SQL Server, this script inspects the error message returned from executing the query 
to determine whether the error is caused by the database being offline or in the loading mode. 
It helps to review the following code fragment from the function I<getDBStatus()>:

 my $badDB = undef;
 foreach my $db (@DB) {
    $sql = qq/SET QUOTED_IDENTIFIER ON 
              SELECT count(*) FROM \"$db\"..sysobjects
               WHERE name = 'sysobjects'/;
    # construct a list of databases that cannot be queried
    unless ($rs = $conn->Execute($sql)) {
       my $dbErr = 'Msg: ' . Win32::OLE->LastError();  
       # check whether Offline mode is excluded from alerting
       next if ($dbErr =~ /Database.+is\s+offline/is and 
                dbaInStrList($db, $configRef->{EXCLUDEOFFLINE}));
       # check whether Loading mode is excluded from alerting
       next if ($dbErr =~ /Database.+is\s+in.+\s+restore/is and 
                dbaInStrList($db, $configRef->{EXCLUDELOADING}));
       $badDB .= " $db";
    } 
 }

In this case, the script examines the error message returned from I<Win32::OLE->LastError()>. 
Alternatively, you can inspect the ADO errors collection for the same error message patterns. 
Either would work. But it's easier to work with I<Win32::OLE->LastError()> because there's no 
need to iterate through a Component Object Model (COM) collection, which is what you must do 
with the ADO Errors collection.

=head1 NOTIFICATION RULE

The script implements the following notification rule:

=over

=item If    

(1) if the check for the availability problem (ping, connecting the SQL instance, querying the database, etc) is enabled, and
(2) if there is an availability problem for more than two consecutive times, and
(3) it is not quiet time, and
(4) it has been longer than the I<AlertInterval> since an alert was last sent 

=item Then    

send the alert 

=back

In addition, the alert is sent to the email addresses specified for the I<DBAPager> option in the section
for that server in the config file. If no I<DBAPager> is specified for the server, the alert is sent to
the I<DutyPager> specified in the Control section of the config file.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


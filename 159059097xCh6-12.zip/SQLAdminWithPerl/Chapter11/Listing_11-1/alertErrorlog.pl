# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaTimeDiff dbaSMTPSend dbaTime2str dbaStr2time 
                        dbaSaveRef dbaReadSavedRef dbaIsBetweenTime );
use Getopt::Std;
use Data::Dumper;

Main: {
   my %opts;
   getopts('S:a:e:r:i:s:m:q:h', \%opts);

   # check mandatory switches
   if (   $opts{'h'} 
       or !defined $opts{e} or !defined $opts{r} or !defined $opts{s} 
       or !defined $opts{a} or !defined $opts{m} or !defined $opts{S}) {
       printUsage();
       exit;
   }
   my $configRef = {
         QuietTime            => $opts{q},
         Errorlog             => $opts{e},
         SenderAccount        => $opts{a},
         StatusFile           => $opts{s},
         SMTPServer           => $opts{m},
         SQLErrAlertInterval  => $opts{i},
         DBAPager             => $opts{r},
         SQLInstance          => $opts{S}
   };

   # read saved status from the status file, if any
   my $statusRef = (-T $configRef->{StatusFile}) ? 
                            dbaReadSavedRef($configRef->{StatusFile}) : {};

   my $ref = { Config => $configRef,
               Status => $statusRef };

   # Check the errorlog for critical errors
   $ref = scanErrorlog($ref);

   #  Decide whether to send alert on critical errors
   $ref = alertErrorlog($ref);

   # Save status to the status file
   dbaSaveRef($configRef->{StatusFile}, $ref->{Status}, 'ref');
} # Main

############################
sub printUsage {
############################
    print << '--Usage--';
Usage:  

  cmd>perl alertErrorlog1.pl  [-h] -e <errorlog> -i<interval> -r<pager address> 
                           -s<status log> -q <quiet time> -m <SMTP server> 
                           -S<instance>
        -h  print this usage info
        -a  Sender account
        -e  path to the SQL Server errorlog
        -i  the minimum time interval between two alerts on the same error
        -r  alert recipient
        -s  status log file to save the current status of the errorlog scan
        -m  SMTP mail server
        -S  SQL Server instance 
--Usage--
} # printUsage

##########################
sub scanErrorlog {
##########################
   my($ref) = shift or die "***scanErrorlogs() expects a reference.\n";
   
   my $statusRef = $ref->{Status};
   
   # Remove old entries recorded in the status data structure
   # For now, if the entry is more than 24 hours old, it is old
   # Reset status (assuming eveything is fine to begin with)
   foreach my $errType (keys %{$statusRef->{SQLErr}}) {
      if ((time() - $statusRef->{SQLErr}->{$errType}->{Time})
            > 3600*24) {
         delete $statusRef->{SQLErr}->{$errType};
         next;
      }
      $statusRef->{SQLErr}->{$errType}->{OK} = 1;
   }

   my $errorlog = $ref->{Config}->{Errorlog};
   my $server = $ref->{Config}->{SQLInstance};
   
   # Now open the errorlog file and check for errors
   unless (open(LOG, "$errorlog")) {
      my $msg = "Msg: Could not open $errorlog on $server.";
      $statusRef->{SQLErr}->{FileOpen} = 
                        { 
                           OK       => 0,
                           ErrMsg   => $msg,
                           Time     => time(),
                           TimeStr  => dbaTime2str()
                        };
      return $ref;                       
   }
    
   # Now we scan the errorlog file for:
   #   Regular SQL Server errors in the format of Error <#>, Severity <#>
   my ($logTime, $logTimeStr);

   while (<LOG>) {
      ($logTimeStr) = /^\s*([\d\/\-]+\s+[\d\.\:]+)\s+/;
      # skip it if it cannot match the datetime string
      next if ($logTimeStr !~ /\d\d(\/|-)\d\d(\/|-)\d\d\s+\d\d:\d\d:\d\d/);
      $logTime = dbaStr2time($logTimeStr);

      # skip the log entries already read by a previous run of the script
      #   as remembered in the status file
      next if ($logTime <= $statusRef->{ErrorlogLastReadTime});

      # if it's a regular SQL error, we need to read in the next line
      if (/Error\s*\:\s*(\d+)\s*\,\s*Severity\s*\:\s*(\d+)/i) {
         my ($error, $severity) = ($1, $2);
         my $msg;

         # get the next line since it contains the actual error message
         $_ = <LOG>;
         /^\s*[^\s]+\s+[^\s]+[^\s]+\s+(.+)$/ and ($msg = $1);

         $msg = "Err $error, $severity on $server at $logTimeStr. $msg";
         if ($severity >= 17) {  # handle the error if severity >= 17
            $statusRef->{SQLErr}->{"$error\_$severity"} = 
                           {
                              OK       => 0,
                              ErrMsg   => $msg,
                              Time     => $logTime,
                              TimeStr  => $logTimeStr
                           };
         }
      }
   }
   close(LOG);
   $statusRef->{ErrorlogLastReadTime} = $logTime;
   $statusRef->{ErrorlogLastReadTimeStr} = $logTimeStr;

   return $ref;
}  # readErrorlog

##########################
sub alertErrorlog {
##########################
   my($ref) = shift or die "***alertErrorlog() expects a reference.\n";
   my $now = time();
   my $nowHour = (localtime)[2];
   my $nowStr = dbaTime2str(time);
   my $msg;
   my @recipients = ($ref->{Config}->{DBAPager});

   # Rule for alerting SQL Errors
   #   if 1. there is a critical SQL error
   #      2. SQL error was last alerted SQLErrAlterInterval minutes ago
   #      3. it's not SQLErr quiet time
   #   then send alert 
   
   foreach my $errType (keys %{$ref->{Status}->{SQLErr}}) {
      next if $ref->{Status}->{SQLErr}->{$errType}->{OK};
      my $errRef = $ref->{Status}->{SQLErr}->{$errType};

      if ( ($now - $errRef->{LastAlertedTime}) 
                     > 60*$ref->{Config}->{SQLErrAlertInterval} and 
          !dbaIsBetweenTime($ref->{Config}->{QuietTime}) ) {
          
             # send alert for this error
             $errRef->{SendAlertOK} = 0; # default to failed unless proven otherwise
             if ( dbaSMTPSend($ref->{Config}->{SMTPServer}, 
                              \@recipients, 
                              $ref->{Config}->{SenderAccount},
                              undef,
                              $errRef->{ErrMsg} )) {
                  $errRef->{LastAlertedTime} = time();
                  $errRef->{LastAlertedTimeStr} = dbaTime2str(time);
                  $errRef->{SendAlertOK} = 1;

                  printf " ***%s Sent to %s; %s\n", dbaTime2str(), 
                                        $ref->{Config}->{DBAPager},
                                        $errRef->{ErrMsg};
             }
      }
      $ref->{Status}->{SQLErr}->{$errType} = $errRef;
   }
   return $ref;
} # alertErrorlog

__END__

=head1 NAME

alertErrorlog - Monitoring SQL Server errorlogs: the basic version

=head1 SYNOPSIS

  cmd>perl alertErrorlog1.pl  [-h] -e <errorlog> -i<interval> -r<pager address> 
                           -s<status log> -q <quiet time> -m <SMTP server> 
                           -S<instance>
        -h  print this usage info
        -a  Sender account
        -e  path to the SQL Server errorlog
        -i  the minimum time interval between two alerts on the same error
        -r  alert recipient
        -s  status log file to save the current status of the errorlog scan
        -m  SMTP mail server
        -S  SQL Server instance 

=head1 USAGE EXMAPLE

To monitor the errorlog of SQL Server instance SQL1\APOLLO, you can schedule to run the 
script I<alertErrorlog.pl> as follows (with the command and all the parameters on a single 
line) at a regular interval:

 cmd>perl alertErrorlog.pl  -e \\SQL1\e$\mssql\mssql$apollo\log\errorlog 
                            -a sql@linchi.com
                            -i 20 
                            -s d:\dba\log\status.log 
                            -S SQL1
                            -r 4321557@myTel.com 
                            -m mail.linchi.com 
                            -q 22-7 

=head1 COMMAND-LINE OPTIONS

=over

=item -a <SMTP account> 

Specifies the account of the SMTP email sender.

=item -e <Errorlog>  

Specifies the SQL Server errorlog in Uniform Naming Convention (UNC).

=item -i <Min alert interval> 

Specifies the minimum amount of time in minutes between two consecutive alerts for the same error.

=item -s <Status log file> 

Specifies the file to which the data structure representing the errorlog monitoring status will be saved. The saved information gives the script memory of what has taken place and helps it make better notification decisions.

=item -S <SQL Server name> 

Specifies the name of the SQL Server instance to be identified in the notification message.

=item -r <Recipient> 

The email address of the alert recipient. Often, this is the email address of a pager.

=item -m <SMTP server>  

The SMTP mail server, typically in the format of mail.linchi.com.

=item -q <Quiet time>   

Specifies a period of time in the format of hh-hh where hh is hours between 0 and 24, inclusive. No alerts will be sent between these two hours.

=item -h 

When specified, the script only prints the usage information.

=back

For example, you could schedule to run this script once every five minutes. In this example, 
whenever the script I<alertErrorlog.pl> runs, it scans the errorlog file in the 
folder \\SQL1\e$\mssql\mssql$apollo\log. If it finds a critical error in the errorlog 
and it's between 7 A.M. and 10 P.M., the script notifies the alert recipient, which is a 
pager at 4321557@myTel.com specified with argument -r. 

The script sends the alert message in an email using the SMTP server I<mail.linchi.com> 
specified with the argument -m. To the recipient, the message appears to be sent by I<sql@linchi.com>, 
which is introduced with the argument -a.

The script I<alertErrorlog.pl> reads the previously saved status from the file I<d:\dba\log\status.log>, 
which is specified with the argument -s. The script then updates the status with the 
current information from the errorlog and saves the status to be used next time around.


=head1 DESCRIPTION

The script scans the errorlog of a single server for errors of severity level 17 or higher. The overall 
structure of the script is as follows:

=over

=item 1.

The script first organizes the command-line arguments with a more readable hash record 
referenced by I<$configRef>. It would be cumbersome to refer to each command-line argument with 
a separate variable.

=item 2.

The script then reads the previously saved status information, if any, into the data structure 
I<$statusRef> with the SQLDBA::Utility function I<dbaReadSavedRef()>. 

=item 3.

The script merges the two data structures -- I<$configRef> and I<$statusRef> -- into a single 
hash structure under the reference I<$ref>.

=item 4.

The data structure I<$ref> is passed to the function I<scanErrorlog()>, which scans the errorlog 
with the help of the configuration options in I<$ref->{Config}> and updates the status hash 
values in I<$ref->{Status}>.

=item 5.

The function I<alertErrorlog()> then examines the data structure I<$ref> with the updated status 
information and decides whether to send an alert. If an alert is deemed necessary, the function 
sends the alert with a call to the function I<dbaSMTPSend()>.

=item 6.

Finally, the SQLDBA::Utility function I<dbaSaveRef()> saves the data structure I<$ref->{Status}> 
to the text file, specified with the command-line option -s.

=back

Using a single reference to the configuration data structure and the status data structure 
makes clear the logic of the script. Because a reference-based Perl data structure can arbitrarily 
and dynamically grow and shrink, a reference can point to any Perl data structure. As a result, 
the monitoring scripts in this chapter all use such a single-reference approach at the top level 
of the scripts to keep their overall flow consistent, nearly identical, and succinct.

=head2 The Status Data Structure

The folowing is an example of the data structure that stores the status of monitoring a SQL Server 
errorlog

 $ref->{Status} = {
   ErrorlogLastReadTime => '1028950362',
   ErrorlogLastReadTimeStr => '2002-08-09 23:32:42.45'
   SQLErr => {
      '50000_17' => {
         OK => '0',
         ErrMsg => 'Err 50000, 17 on SQL1 at 2002-08-09 23:32. Test message.',
         Time    => '1028950362'
         TimeStr => '2002-08-09 23:32:42.45',
         SendAlertOK => 1,
         LastAlertedTime    => '1028950366',
         LastAlertedTimeStr => '2002/08/09 23:32:46 ',
      },
      '1105_17' => {
         OK => '0',
         ErrMsg => 'Err 1105, 17 on SQL1 at 2002-08-09 23:32. Could not ...',
         Time    => '1028950362'
         TimeStr => '2002-08-09 23:32:42.45',
         SendAlertOK => 1,
         LastAlertedTime    => '1028950366',
         LastAlertedTimeStr => '2002/08/09 23:32:46 ',
      },
      '50000_19' => {
         OK => '0',
         ErrMsg => 'Err 50000, 19 on SQL1 at 2002-08-09 23:32. Test message.',
         Time    => '1028950362'
         TimeStr => '2002-08-09 23:32:42.45',
         SendAlertOK => 1,
         LastAlertedTime    => '1028950366',
         LastAlertedTimeStr => '2002/08/09 23:32:46 ',
      },
   },
 };

There are three keys underneath I<$ref->{Status}>. Besides the time of the last entry in the errorlog 
(I<ErrorlogLastReadtime> and I<ErrorlogLastReadtimeStr>), I<SQLErr> references the data structure 
that records the necessary details of each error found in the errorlog. 

The script relies on I<ErrorlogLastReadTime> to avoid repeatedly considering the log entries that 
have already been scanned when the script was previously invoked:

 next if ($logTime <= $statusRef->{ErrorlogLastReadTime});

One level deeper in the nested data structure underneath I<$ref->{Status}->{SQLErr}> is a 
hash key for each SQL Server error encountered during the errorlog scan. In the example shown above, 
there are three errors. For each error, a hash with the keys described below are recorded or updated:

=over

=item OK 

A value of 0 indicates that an entry for the error is found during the current scan. 
A value of 1 indicates that no critical error is found during the current scan and that 
the hash record for the error, if any, is carried over from a previous run of the script, 
and it's not updated during the current scan.

=item ErrMsg   

The message to be sent in the alert. The message includes the error number, the severity level, the 
SQL Server instance name, the date/time of the error, and the error message text.

=item Time  

Date/time of the error as recorded in the errorlog. The format is epoch seconds -- the number of 
non-leap seconds since 00:00:00 on January 1, 1970 GMT.

=item TimeStr  

Date/time of the error as recorded in the errorlog in the readable format of YYYY-MM-DD hh:mi:ss.mm.

=item SendAlertOK 

Value 1 indicates that the alert for this error is sent successfully, and 0 indicates otherwise.

=item LastAlertTime  

Date/time when the alert is sent in the epoch seconds.

=item LastAlertTimeStr  

Date/time when the alert is sent in the format of YYYY-MM-DD hh:mi:ss.mm.

=back

Note that each of the date/time related values in the status data structure is recorded in two 
formats: the epoch seconds -- the number of non-leap seconds since 00:00:00 on Jan. 1, 1970 Greenwich 
mean time (GMT) -- and a readable string in the format of YYYY-MM-DD hh:mi:ss.mm. This is a practice 
I use in most of my scripts to avoid constantly having to convert back and forth between the two 
formats. I sacrifice a little extra space for a gain in programming convenience and readability -- a 
worthwhile tradeoff. 

As mentioned, the hash key for an error (for instance, error 1105) is the concatenation of its error 
number and its severity level (1105_17 in this case), and the hash record for this error 
(referenced by I<$ref->{Status}->{SQLErr}->{1105_17}> in this case) is updated whenever such an error 
is found during the scan of the errorlog. Because the script scans the errorlog in the chronological 
order, only the information from the last occurrence of the error is kept. This is precisely 
desirable because it guarantees that the DBA is notified of this particular error at most once 
during each scan.

Note that as more errors are found in the errorlog, the number of hash records under 
I<$ref->{Status}->{SQLErr}> will increase. For troubleshooting and review purposes, you don't 
want to immediately remove all the information for an error from the hash even if no new 
occurrence of this error is found during the next scan of the errorlog. However, you don't 
want to keep the information forever either. In this script, the entry for an error is removed 
if it was last logged more than 24 hours ago. The following code segment in the function I<scanErrorlog()>
implements this logic:

 # Remove old entries recorded in the status data structure
 # For now, if the entry is more than 24 hours old, it is old.
 foreach my $errType (keys %{$statusRef->{SQLErr}}) {
    if ((time() - $statusRef->{SQLErr}->{$errType}->{Time})
              > 3600*24) {
        delete $statusRef->{SQLErr}->{$errType};  # remove from the hash
        next;
    }
    # if the entry is not that old, reset its status to good
    $statusRef->{SQLErr}->{$errType}->{OK} = 1;
 }

=head2 Notification Rule

The script I<alertErrorlog.pl> implements the following notification rule:

 If    (1) there's a new SQL Server error matching the configured criticality 
           criteria (any error with severity level 17 or higher) 
       (2) SQL error was last alerted SQLErrAlertInterval minutes ago
       (3) it's not in the quiet time period
 Then  send an alert

The quiet time period is the time in which you don't want to be alerted no matter what error 
is logged in the errorlog. This is useful for a SQL Server instance that's not being supported 
on a 24/7 basis. For such a system, you may not appreciate being paged at 3 A.M.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


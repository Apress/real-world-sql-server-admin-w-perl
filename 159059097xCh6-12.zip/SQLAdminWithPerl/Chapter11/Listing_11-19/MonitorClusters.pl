# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaSMTPSend dbaTime2str dbaSaveRef dbaSetDiff
                        dbaReadSavedRef dbaSetCommon dbaIsBetweenTime 
                        dbaReadINI dbaInSet );
use Win32::OLE qw(in);
use Data::Dumper;

Main: {
   my $configFile = shift;
   unless ($configFile) { printUsage(); exit; }

   (-T $configFile) or 
         die "***Specified config file $configFile does not exist.\n";


   # Read config file into $configRef
   my $configRef = dbaReadINI($configFile);

   # Validate config options and set defaults
   $configRef = validateConfig($configRef);

   my $savedStatusRef = 
         (-T $configRef->{CONTROL}->{STATUSFILE}) ? 
          dbaReadSavedRef($configRef->{CONTROL}->{STATUSFILE}) : {};

   my $ref = { Config => $configRef,
               SavedStatus => $savedStatusRef };

   # get current status
   $ref = getStatus($ref);
   
   # check the current status and compare it with the saved one
   $ref = checkStatus($ref);

   #  Decide whether to send an alert
   $ref = alertStatus($ref);

   # Save status to the status file
   dbaSaveRef($configRef->{CONTROL}->{STATUSFILE}, 
              $ref->{CurrentStatus}, 'ref');
#print Dumper($ref);   
} # Main

#####################
sub printUsage {
#####################
    print << '--Usage--';
Usage:
  cmd>perl monitorClusters.pl <Config File>
    <Config File>   file to specify config options for monitoring clusters 
--Usage--
}

#######################
sub validateConfig {
#######################
   my $configRef = shift or 
         die "***validateConfig() expects a reference.\n";
   
   foreach my $cluster (sort keys %{$configRef}) {
      next if $cluster =~ /^control$/i;
      next if $configRef->{$cluster}->{DISABLED} =~ /^y/i;
      
      if (!defined $configRef->{$cluster}->{ALERTINTERVAL} or
          $configRef->{$cluster}->{ALERTINTERVAL} !~ /\d+/) {
          $configRef->{$cluster}->{ALERTINTERVAL} = 15;
      }
   }   
   return $configRef;
} # validateConfig

#######################
sub getStatus {
#######################
   my $ref = shift or 
      die "***getStatus() expects a reference.\n";

   my %nodeState  = ( -1 => 'Unkown', 0 => 'Up', 1 => 'Down', 
                       2 => 'Paused', 3 => 'Joining');
   my %groupState = ( -1 => 'Unkown', 0 => 'Online', 1 => 'Offline', 
                     2 => 'Failed', 3 => 'PartialOnline', 4 => 'Pending');

   foreach my $cluster (sort keys %{$ref->{Config}}) {
      next if $cluster =~ /^CONTROL/i;
      next if $ref->{Config}->{$cluster}->{DISABLED} =~ /^y/i;
      
      my $statusRef;
      my $savedStatusRef = $ref->{SavedStatus}->{$cluster};
      my ($clusterName) = $cluster =~ /^CLUSTER\s*:\s*(.+)$/i;

      my $clusRef = Win32::OLE->new('MSCluster.Cluster');
      unless ($clusRef) {
         my $err = Win32::OLE->LastError();
         $statusRef->{OK} = 0;
         $statusRef->{AlertStatus}->{FailedQuery}->{Times} =
                $savedStatusRef->{AlertStatus}->{FailedQuery}->{Times} + 1;
         $statusRef->{AlertStatus}->{FailedQuery}->{Msg} =
                  "Failed new('MSCluster.Cluster'). $err.";
         $ref->{CurrentStatus}->{$cluster} = $statusRef;
         return $ref;
      };
      
      $clusRef->Open($clusterName);
      if (my $err = Win32::OLE->LastError()) {
         print "***unable to open $cluster. $err\n";
         $statusRef->{OK} = 0;
         $statusRef->{AlertStatus}->{FailedQuery}->{Times} =
                $savedStatusRef->{AlertStatus}->{FailedQuery}->{Times} + 1;
         $statusRef->{AlertStatus}->{FailedQuery}->{Msg} =
                  "Failed open($clusterName). $err.";
         $ref->{CurrentStatus}->{$cluster} = $statusRef;
         next;
      }

      # loop throught the Nodes collection
      foreach my $node (in ($clusRef->Nodes)) {
         next unless $node;   
         $statusRef->{ClusterStatus}->{Nodes}->{$node->{Name}}->{Status} 
                           = $nodeState{$node->{State}};
      }

      # loop through the ResourceGroups collection
      foreach my $group (in ($clusRef->ResourceGroups)) {
        next unless $group;
        
        my $grpRef= $statusRef->{ClusterStatus}->{Groups}->{$group->{Name}};
        $grpRef->{Status} = $groupState{ $group->{State} };
        $grpRef->{Node} = $group->{OwnerNode}->{Name};
        # loop through the PreferredOwnerNodes collection
        foreach my $preferredNode (in ($group->{PreferredOwnerNodes})) {
           next unless $preferredNode;
           push @{$grpRef->{PreferredOwnerNodes}},
              $preferredNode->{Name};
        }
        $statusRef->{ClusterStatus}->{Groups}->{$group->{Name}} = $grpRef;
      }

      $statusRef->{OK} = 1;
      $ref->{CurrentStatus}->{$cluster} = $statusRef;
   }   
   return $ref;
}  # getStatus

############################
sub checkStatus {
############################
   my ($ref) = shift or die "***checkStatus() expects a reference.";

   foreach my $cluster (sort keys %{$ref->{Config}}) {
      next if $cluster =~ /^CONTROL/i;
      next if $ref->{Config}->{$cluster}->{DISABLED} =~ /^y/i;
      
      my ($clusterName) = $cluster =~ /^CLUSTER\s*:\s*(.+)$/i;
      my $savedRef = $ref->{SavedStatus}->{$cluster}->{ClusterStatus};
      my $curRef = $ref->{CurrentStatus}->{$cluster}->{ClusterStatus};
      my $alertRef;

      my @diff = ();
      my @savedNodes = keys %{$savedRef->{Nodes}};
      my @currentNodes = keys %{$curRef->{Nodes}};
      my @savedGroups = keys %{$savedRef->{Groups}};
      my @currentGroups = keys %{$curRef->{Groups}};

      # check if a node is not Up
      foreach my $node (@currentNodes) {
         if ($curRef->{Nodes}->{$node}->{Status} !~ /^Up$/i) {
            $alertRef->{NodeNotUp}->{Msg} .= "$node,";
            $ref->{CurrentStatus}->{$cluster}->{OK} = 0;
         }
      }

      # check if a group is not online
      foreach my $group (@currentGroups) {
         my $status = $curRef->{Groups}->{$group}->{Status};
         if ($status !~ /^Online$/i) {
            $alertRef->{GroupNotOnline}->{Msg} .= "$group,";
            $ref->{CurrentStatus}->{$cluster}->{OK} = 0;
         }
      }

      # check preferred owner nodes for each group
      if ($ref->{Config}->{$cluster}->{CHECKPREFERREDOWNERNODES} =~ /^y/i) {
        foreach my $group (@currentGroups) {
          if (defined $curRef->{Groups}->{$group}->{PreferredOwnerNodes}) {
             unless (dbaInSet($curRef->{Groups}->{$group}->{Node}, 
                     $curRef->{Groups}->{$group}->{PreferredOwnerNodes})) {
              $alertRef->{GroupNotOnPreferredOwnerNode}->{Msg} .= "$group,";
              $ref->{CurrentStatus}->{$cluster}->{OK} = 0;
             }
          }
        }
      }
      
      # check if a node is evicted
      if (@diff = dbaSetDiff(\@savedNodes, \@currentNodes)) {
         my $nodes = join(',', map {"'" . $_ ."'"} @diff);
         $alertRef->{NodeEvicted}->{Msg} = $nodes;
         $ref->{CurrentStatus}->{$cluster}->{OK} = 0;
      }

      # check if a group is removed
      if (@diff = dbaSetDiff(\@savedGroups, \@currentGroups)) {
         my $groups = join(',', map {"'" . $_ ."'"} @diff);
         $alertRef->{GroupRemoved}->{Msg} = $groups;
         $ref->{CurrentStatus}->{$cluster}->{OK} = 0;
      }

      # check if a group is moved to another node
      foreach my $group (dbaSetCommon(\@currentGroups, \@savedGroups)) {
         my $oldNode = $savedRef->{Groups}->{$group}->{Node};
         my $newNode = $curRef->{Groups}->{$group}->{Node};
         if ($oldNode ne $newNode ) {
            $alertRef->{GroupMoved}->{Msg} .= "$group: $oldNode->$newNode,";
            $ref->{CurrentStatus}->{$cluster}->{OK} = 0;
         }
      }
      $ref->{CurrentStatus}->{$cluster}->{AlertStatus} = $alertRef;
   }
   return $ref;
} # checkStatus

###########################
sub alertStatus {
###########################
    my $ref = shift or die "***alertStatus() expects a reference.";

   foreach my $cluster (sort keys %{$ref->{Config}}) {
      next if $cluster =~ /^CONTROL/i;
      next if $ref->{CurrentStatus}->{$cluster}->{OK};
      next if $ref->{Config}->{$cluster}->{DISABLED} =~ /^y/i;
      
      my ($clusterName) = $cluster =~ /^CLUSTER\s*:\s*(.+)$/i;
      my $alertRef = $ref->{CurrentStatus}->{$cluster}->{AlertStatus};
      my $currentRef = $ref->{CurrentStatus}->{$cluster};
      my $savedRef = $ref->{SavedStatus}->{$cluster};
      my @receivers = ( $ref->{Config}->{$cluster}->{DBAPAGER} );

      foreach my $alertType (sort keys %{$alertRef}) {
         # try twice before quitting
         next if (     $alertType eq 'AccessFailed' 
                   and $alertRef->{AccessFailed}->{Times} <= 2);
         # was an alert sent recently
         next if (time() - 
                 $savedRef->{AlertSent}->{$alertType}->{AlertSentTime}) 
                    < ($ref->{Config}->{$cluster}->{ALERTINTERVAL})*60;
         # don't alert if it's in the quiet time period
         next if dbaIsBetweenTime($ref->{Config}->{$cluster}->{QUIETTIME});
                         
         # tidy up the message
         $alertRef->{$alertType}->{Msg} =~ s/,$//;
         $alertRef->{$alertType}->{Msg} 
                      = 'Cluster ' . $clusterName .
                        " $alertType: " . $alertRef->{$alertType}->{Msg};
         # send via SMTP    
         if (dbaSMTPSend($ref->{Config}->{CONTROL}->{SMTPSERVER}, 
                         \@receivers, 
                         $ref->{Config}->{CONTROL}->{SMTPSENDER},
                         undef,
                         $alertRef->{$alertType}->{Msg})) {
                      
            $currentRef->{AlertSent}->{$alertType}->{OK} = 1;
            $currentRef->{AlertSent}->{$alertType}->{AlertSentTimeStr}
                              = dbaTime2str();
            $currentRef->{AlertSent}->{$alertType}->{AlertSentTime}
                              = time();
            $currentRef->{AlertSent}->{$alertType}->{Msg} 
                        = $alertRef->{$alertType}->{Msg};
            # log it to a file                        
            if (open(LOG, ">>$ref->{Config}->{CONTROL}->{ALERTLOGFILE}")) {
               printf LOG "%s  %s. Sent to %s\n", dbaTime2str(), 
                         $alertRef->{$alertType}->{Msg},
                         $ref->{Config}->{$cluster}->{DBAPAGER};
               close(LOG);
            }
         }
         else {
            $currentRef->{AlertSent}->{$alertType}->{OK} = 0;
            $currentRef->{AlertSent}->{$alertType}->{AlertSentTimeStr}
                              = undef;
            $currentRef->{AlertSent}->{$alertType}->{AlertSentTime}
                              = undef;
         }
      }
      $ref->{CurrentStatus}->{$cluster} = $currentRef;
   }
   return $ref;
} # alertStatus

__END__

=head1 NAME

monitorClusters - Monitoring SQL Server clusters: the robust version

=head1 SYNOPSIS

  cmd>perl monitorClusters.pl <Config File>

    <Config File>   file to specify config options for monitoring clusters 


=head1 CONFIGURATION OPTIONS

The following is a sample configuration file accepted by the script. The file includes the options for
two clusters, NYCLSQL01 and NYCLSQL02.

 [Control]
 AlertLogFile=d:\dba\clusters\Alert.log
 StatusFile=d:\dba\clusters\status.log
 SMTPServer=mail.linchi.com
 SMTPSender=sql@linchi.com
 
 [Cluster:NYCLSQL01]
 Disabled=no
 DBAPager=72001@myTel.com
 QuietTime=20-8
 AlertInterval=15
 CheckPreferredOwnerNodes=yes
 
 [Cluster:NYCLSQL02]
 Disabled=no
 DBAPager=74321@myTel.com
 QuietTime=24-6
 AlertInterval=30
 CheckPreferredOwnerNodes=no

The configuration options are explained below.

=over

=item AlertLogFile   

A log entry is made to this text file every time an alert is sent.

=item StatusFile  

This is the file where the cluster status data structure will be saved. 
The monitorClusters.pl script reads from this file the next time it runs.

=item SMTPServer  

The SMTP mail server.

=item SMTPSender  

This is the SMTP account to identify the sender of the alert.

=item Disabled 

When this is set to yes, the script doesn't monitor the cluster.

=item DBAPager 

All alerts for this cluster will be sent to this address.

=item QuietTime   

This option accepts two values in the format of hh-hh, where hh is between 1 and 24, 
inclusive. When this is specified, no alerts for this cluster will be sent between these two hours.

=item AlertInterval  

This option specifies the minimum amount of time in minutes that must elapse before another alert 
for this cluster can be sent again.

=item CheckPreferredOwnerNodes   

This is a toggle with values yes or no. When it's set to no, the script won't check whether a group 
is running on its preferred owner node.

=back


=head1 DESCRIPTION

The script I<monitorClusters.pl> monitors multiple SQL Server clusters for the following seven 
cluster-related events:

=over

=item *

The cluster isn't accessible.

=item *

A node is evicted from the cluster.

=item *

The status of a node isn't up.

=item *

The status of a group isn't online.

=item *

A group moves from one node to another.

=item *

A group isn't running on its preferred owner node.

=item *

A group has been removed from the cluster.

=back

The first five events are the same as the ones monitored by the script I<alertCluster.pl> 
in Listing 11-17. 

The requirement for monitoring whether a group is running on its preferred 
owner node is a practical one. When you have multiple SQL Server instances running in a 
cluster, a given instance is often configured to run on a specific node -- its preferred owner node -- 
under normal circumstances for performance and administrative purposes. 
Even though the instance works on any node, you want to make sure it's on the preferred owner node, 
if at all possible.

=head1 OBTAINING CLUSTER STATUS

The script retrieves the cluster node and group status using the Cluster Automation Server. The 
function I<getStatus()> first invokes the Cluster Automation Server as follows: 

 my $clusRef = Win32::OLE->new('MSCluster.Cluster');

Contrast this with the use of the command-line utility I<cluster.exe> in the script I<alertCluster.pl> 
in Listing 11-17. The Cluster Automation Server provides a more controlled interface to access all aspects 
of a cluster.

=head1 CLUSTER STATUS DATA STRUCTURE

The following is an example of the data structure for the cluster NYCLSQL01. It illustrates the addition 
of the level immediately below I<$ref->{CurrentStatus}> in the data structure hierarchy.

 $ref->{CurrentStatus}->{'CLUSTER:NYCLSQL01'} = {
       OK => '0',
       ClusterStatus => {
             Nodes => {
                     NYCLSQL01NODE1 => { Status => 'Up' },
                     NYCLSQL01NODE2 => { Status => 'Up' }
              }
             Groups => {
                    MSSQL01 => {
                         PreferredOwnerNodes => [ 'NYCLSQL01NODE1' ],
                         Status => 'Online',
                         Node => 'NYCLSQLNODE2'
                     },
                    MSSQL02 => {
                         PreferredOwnerNodes => [ 'NYCLSQL01NODE1' ],
                         Status => 'Partial Online',
                         Node => 'NYCLSQL01NODE1'
                     },
                    ClusterGroup => {
                         Status => 'Online',
                         Node => 'NYCLSQL01NODE2'
                     }
              },
        }
       AlertStatus => {
             GroupNotOnPreferredOwnerNode => {
                  Msg => 'Cluster NYCLSQL01 GroupNotOnPreferredOwnerNode: MSSQL01'
              },
             GroupNotOnline => {
                  Msg => 'Cluster NYCLSQL01 GroupNotOnline: MSSQL02'
              }
        },
   };

Compare this data structure with that in Listing 11-17. They're identical with the exception of 
the additional keys under the individual group to capture the list of preferred owner nodes.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


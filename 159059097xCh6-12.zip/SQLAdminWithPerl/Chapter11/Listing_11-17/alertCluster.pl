# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA:Utility
use SQLDBA::Utility qw( dbaSMTPSend dbaTime2str dbaSaveRef dbaSetDiff
                        dbaReadSavedRef dbaSetCommon );
use Getopt::Std;
use Data::Dumper;

Main: {
   my %opts;
   getopts('c:s:r:a:m:', \%opts);

   unless ($opts{c} and $opts{a} and $opts{s} and $opts{m} and $opts{r}) {
      printUsage();
      exit;
   }
   my $configRef = {
         Cluster              => $opts{c},
         SenderAccount        => $opts{a},
         StatusFile           => $opts{s},
         SMTPServer           => $opts{m},
         DBAPager             => $opts{r}
   };

   # read saved status from the status file, if any
   my $statusRef = (-T $configRef->{StatusFile}) ? 
                       dbaReadSavedRef($configRef->{StatusFile}) : {};

   my $ref = { Config => $configRef,
               SavedStatus => $statusRef };

   # get current status
   $ref = getStatus($ref);

   # check the current status and compare it with the saved one
   $ref = checkStatus($ref);
   
   #  Decide whether to send an alert
   $ref = alertStatus($ref);
print Dumper($ref);

   # Save status to the status file
   dbaSaveRef($configRef->{StatusFile}, $ref->{CurrentStatus}, 'ref');
} # Main

#####################
sub printUsage {
#####################
    print << '--Usage--';
Usage:
  cmd>perl alertCluster.pl -C <cluster> -s <statusFile> -r <dbaPager>
                           -a <senderAccount> -m <SMTPServer>
                         
      -C <cluster>     Name of the cluster to be moitored
      -s <statusFile>  Name of the file to record the cluster status
      -r <dbaPager>    pager email address
      -a <sendAccount> Account of the sender on the SMTP server
      -m <SMTPServer>  SMTP server
--Usage--
}

#######################
sub getStatus {
#######################
   my $ref = shift or 
      die "***getStatus() expects a reference.\n";

   my $statusRef;
   my $cluster = $ref->{Config}->{Cluster};
   
   # get node names and status    
   my $msg = `cluster $cluster node`;
   my @status = split /[\n\r\f]+/, $msg;
   # skip to the result row
   1 while (shift @status) !~ /^----/;

   unless (@status) {
      $msg =~ s/\s+/ /g;
      $msg =~ s/\s*$//;
      $statusRef->{OK} = 0;
      $statusRef->{AlertStatus}->{FailedQuery}->{Times} =
               $ref->{SavedStatus}->{AlertStatus}->{FailedQuery}->{Times} + 1;
      $statusRef->{AlertStatus}->{FailedQuery}->{Msg} =
               "cluster $cluster node. $msg.";
      $ref->{CurrentStatus} = $statusRef;
      return $ref;
   }

   foreach (@status) {
      my ($node, $status) = $_ =~ /^\s*(\w+)\s+\d+\s+(.+)/;
      $status =~ s/\s*$//;
      $statusRef->{ClusterStatus}->{Nodes}->{$node}->{Status} = $status;
   }

   # get group names and status
   $msg = `cluster $cluster group`;
   @status = split /[\n\r\f]+/, $msg;
   # skip to the result row
   1 while (shift @status) !~ /^----/;

   unless (@status) {
      $msg =~ s/\s+/ /g;
      $msg =~ s/\s*$//;
      $statusRef->{OK} = 0;
      $statusRef->{AlertStatus}->{FailedQuery}->{Times} =
               $ref->{SavedStatus}->{AlertStatus}->{FailedQuery}->{Times} + 1;
      $statusRef->{AlertStatus}->{FailedQuery}->{Msg} =
               "cluster $cluster group. $msg.";
      $ref->{CurrentStatus} = $statusRef;
      return $ref;
   }

   my $node_re = join('|', keys %{$statusRef->{ClusterStatus}->{Nodes}});
   foreach (@status) {
      my ($group, $node, $status) = $_ =~ /^\s*(.+)\s+($node_re)\s+(.+)/;
      $group =~ s/\s*$//;
      $statusRef->{ClusterStatus}->{Groups}->{$group}->{Status} = $status;
      $statusRef->{ClusterStatus}->{Groups}->{$group}->{Node} = $node;
   }
   $statusRef->{OK} = 1;
   $ref->{CurrentStatus} = $statusRef;
   return $ref;
}  # getStatus

############################
sub checkStatus {
############################
   my ($ref) = shift or die "***checkStatus() expects a reference.";
   my $savedRef = $ref->{SavedStatus}->{ClusterStatus};
   my $currentRef = $ref->{CurrentStatus}->{ClusterStatus};
   my $alertStatusRef;

   my @diff = ();
   my @savedNodes = keys %{$savedRef->{Nodes}};
   my @currentNodes = keys %{$currentRef->{Nodes}};
   my @savedGroups = keys %{$savedRef->{Groups}};
   my @currentGroups = keys %{$currentRef->{Groups}};

   # check if a node is not UP
   foreach my $node (@currentNodes) {
      if ($currentRef->{Nodes}->{$node}->{Status} !~ /^Up$/i) {
         $alertStatusRef->{NodeNotUp}->{Msg} .= "$node,";
         $ref->{CurrentStatus}->{OK} = 0;
      }
   }

   # check if a group is not online
   foreach my $group (@currentGroups) {
      my $status = $currentRef->{Groups}->{$group}->{Status};
      if ($status !~ /^Online$/i) {
         $alertStatusRef->{GroupNotOnline}->{Msg} .= "$group,";
         $ref->{CurrentStatus}->{OK} = 0;
      }
   }

   # check if a node is evicted
   if (@diff = dbaSetDiff(\@savedNodes, \@currentNodes)) {
      my $nodes = join(',', map {"'" . $_ ."'"} @diff);
      $alertStatusRef->{NodeEvicted}->{Msg} = $nodes;
      $ref->{CurrentStatus}->{OK} = 0;
   }

   # check if a group is moved to another node
   foreach my $group (dbaSetCommon(\@currentGroups, \@savedGroups)) {
      my $oldNode = $savedRef->{Groups}->{$group}->{Node};
      my $newNode = $currentRef->{Groups}->{$group}->{Node};
      if ($oldNode ne $newNode ) {
         $alertStatusRef->{GroupMoved}->{Msg} .= "$group: $oldNode->$newNode,";
         $ref->{CurrentStatus}->{OK} = 0;
      }
   }
   $ref->{CurrentStatus}->{AlertStatus} = $alertStatusRef;
   return $ref;
} # checkStatus

###########################
sub alertStatus {
###########################
    my $ref = shift or die "***alertStatus() expects a reference.";
    return $ref if $ref->{CurrentStatus}->{OK};

    my $alertStatusRef = $ref->{CurrentStatus}->{AlertStatus};
    my @receivers = ( $ref->{Config}->{DBAPager} );
    
    foreach my $alertType (sort keys %{$alertStatusRef}) {
      next if (     $alertType eq 'AccessFailed' 
                and $alertStatusRef->{AccessFailed}->{Times} <= 2);
      # tidy up the message
      $alertStatusRef->{$alertType}->{Msg} =~ s/,$//;
      $alertStatusRef->{$alertType}->{Msg} 
                   = 'Cluster ' . $ref->{Config}->{Cluster} .
                     " $alertType: " . $alertStatusRef->{$alertType}->{Msg};
      # send via SMTP    
      if (dbaSMTPSend($ref->{Config}->{SMTPServer}, 
                   \@receivers, 
                   $ref->{Config}->{SenderAccount},
                   $alertStatusRef->{$alertType}->{Msg})) {
         $ref->{CurrentStatus}->{AlertSent}->{$alertType}->{OK} = 1;
         $ref->{CurrentStatus}->{AlertSent}->{$alertType}->{AlertSentTimeStr}
                           = dbaTime2str();
         printf "%s  %s. Sent to %s\n", dbaTime2str(), 
                   $alertStatusRef->{$alertType}->{Msg},
                   $ref->{Config}->{DBAPager};
      }
      else {
         $ref->{CurrentStatus}->{AlertSent}->{$alertType}->{OK} = 0;
         $ref->{CurrentStatus}->{AlertSent}->{$alertType}->{AlertSentTimeStr}
                           = undef;
      }
    }
    return $ref;
} # alertStatus

__END__

=head1 NAME

alertCluster - Monitoring SQL Server cluster: the basic version

=head1 SYNOPSIS

  cmd>perl alertCluster.pl -C <cluster> -s <statusFile> -r <dbaPager>
                           -a <senderAccount> -m <SMTPServer>
                         
      -C <cluster>     Name of the cluster to be moitored
      -s <statusFile>  Name of the file to record the cluster status
      -r <dbaPager>    Pager email address
      -a <sendAccount> Account of the sender on the SMTP server
      -m <SMTPServer>  SMTP server


=head1 COMMAND-LINE OPTIONS

=over

=item -C <cluster> 

Specifies the name of the cluster to be monitored

=item -s <statusFile>  

Specifies the file to which the cluster status data structure will be saved

=item -r <dbaPager> 

Specifies the email address of the alert recipient

=item -a <sendAccount> 

Specifies the account of the SMTP email sender

=item -m <SMTPServer>  

Specifies the SMTP mail server

=back


=head1 DESCRIPTION

The script I<alertCluster.pl> monitors the following five cluster-specific events:

=over

=item *

The cluster isn't accessible.

=item *

A cluster node is evicted from the cluster.

=item *

The status of a cluster node isn't up.

=item *

The status of a cluster group isn't online.

=item *

A group has moved from one node to another.

=back


The script runs the I<cluster.exe> command line utility to retrieve the status of the cluster nodes and the
cluster groups.

=head1 Cluster.exe

Assume that the name of the cluster is NYCLUSTER, you can issue the following command to 
obtain the status of the cluster nodes:


 cmd>cluster NYCLUSTER node
 
 Listing status for all available nodes:
 
 Node                       Node ID       Status
 -------------------------- ------------- ---------------------
 NYCLSQLNODE1               1             Up
 NYCLSQLNODE2               2             Up

This result is intuitive, which shows that both nodes of the cluster are up. 
If the status of any of the nodes isn't Up, the DBA should know. Likewise, you can issue the following 
command to get a cluster group status report:

 cmd>cluster NYCLUSTER group
 
 Listing status for all available resource groups:
 
 Group                Node            Status
 -------------------  --------------  ---------
 Cluster Group        NYCLSQLNODE1    Online
 SQL Server           NYCLSQLNODE1    Online

In this case, the cluster has two groups. They're both online and currently both running on 
node NYCLSQLNODE1. The DBA should be notified if a group status isn't Online.

Note that there is no need to check the status of the individual cluster resources because (1) the
bad status at the resource usually will bubble up to the group level, and (2) the SQL-related 
resources are already monitored when you monitor the SQL errorlogs and SQL instance availability.

=head1 CLUSTER STATUS DATA STRUCTURE

The core of the script is to run the I<cluster.exe> utility, parse the output for the node and group 
status information, and store the status information in the cluster status data structure. A sample 
cluster status data structure for a single cluster is shown below:

 $ref->{CurrentStatus} = {
    OK => '0',
    ClusterStatus => {
       Nodes => {
              NYCLSQLNODE1 => { 'Status' => 'Up' },
              NYCLSQLNODE2 => { 'Status' => 'Paused' }
       }
       Groups => {
            'ClusterGroup' => {    # group named ClusterGroup
                   Status => 'Online',
                   Node   => 'NYCLSQLNODE2'
            },
             'MSSQL01' => {        # group named MSSQL01
                   Status => 'Online',
                   Node'=> 'NYCLSQLNODE1'
             },
             'MSSQL02' => {        # group named 'MSSQL02'
                   Status => 'Partially Online',
                   Node => 'NYCLSQLNODE1'
             }
       }
    },
    AlertStatus => {
       GroupNotOnline => {
             Msg => 'Cluster NYCLUSTER GroupNotOnline: MSSQL02'
       },
       NodeNotUp => { 
             Msg => 'Cluster NYCLUSTER NodeNotUp: NYCLSQLNODE2'
       }
    }
 };

The function I<checkStatus()> in the script is responsible for populating this data structure.

In the hash record of I<$ref->{CurrentStatus}> show above, there are three keys: 
I<OK>, I<ClusterStatus>, and I<AlertStatus>. The hash key OK is an overall indicator of the cluster status. 
If it's set to 1, the cluster is in a good condition; there's no need to look at any more detail, 
and no alert is necessary. If it's set to 0, the function I<alertStatus()> will go through the hash 
record I<$ref->{CurrentStatus}->{AlertStatus}> to send out an alert for each of the following keys, 
if its value is defined:

=over

=item *  

FailedQuery

=item *

NodeNotUp

=item *

NodeEvicted

=item *

GroupNotOnline

=item *

GroupMoved

=back

For instance, by inspecting the information in the hash record I<$ref->{CurrentStatus}->{ClusterStatus}> shown above, 
the script I<alertCluster.pl> found two events: I<GroupNotOnline> and I<NodeNotUp>. Thus, there are 
two keys under I<$ref->{CurrentStatus}->{AlertStatus}>, I<GroupNotOnline> and I<NodeNotUp>, to record 
these two events. The messages associated with these two keys will be sent. 

Notice that the keys correspond to the five cluster events this script monitors. Given the nature of 
these events, it's possible that more than one of them are detected and recorded in the data structure. 
For instance, in a cluster, a group can be taken offline while another group is moved to a different 
node and one node is offline. As a result, the DBA may receive multiple alerts in a row, each on a 
different cluster event.

Also note that to determine whether a node is evicted or a group is moved, the script must 
compare the current cluster status with the previous cluster status. The previous cluster status 
is read from the status file and kept in the hash record I<$ref->{SavedStatus}>. Its structure is 
the same as that of the current cluster status. 

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


# This test script tries out the Cluster Automation Server (CAS). The program ID for CAS
# is MSCluster. You typically start with the Cluster object. Thus, it'sc ommon to see
# Win32:OLE->('MSCluster.Cluster')

use strict;
use Win32::OLE qw(in);
use Data::Dumper;

my @clusters = ('SQL01', 'SQL02');   # Two cluster names are hard coded for test purposes
my $serverRef;

$serverRef = getStatus(\@clusters);
print Dumper($serverRef);


####################
sub getStatus {
####################
   my $clustersRef = shift or die "***getStatus() expects a reference.\n";
   my $ref;
   my $root;
   my @status;

   my %nodeState  = ( -1 => 'Unkown', 0 => 'Up', 1 => 'Down', 
                       2 => 'Paused', 3 => 'Joining');
   my %groupState = ( -1 => 'Unkown', 0 => 'Online', 1 => 'Offline', 
                     2 => 'Failed', 3 => 'PartialOnline', 4 => 'Pending');

   foreach my $cluster (@{$clustersRef}) {
      my $clusRef = Win32::OLE->new('MSCluster.Cluster');
      unless ($clusRef) {
         my $err = Win32::OLE->LastError();
         print "***could not create the COM object MSCluster.Cluster. $err\n";
         return;
      };
      
      $clusRef->Open($cluster);
      if (my $err = Win32::OLE->LastError()) {
         print "***unable to open $cluster. $err\n";
         next;
      }

      my $myRef;
      # loop throught the Nodes collection
      foreach my $node (in ($clusRef->Nodes)) {
         next unless $node;   
         $myRef->{Nodes}->{ $node->{Name} }->{Status} 
                           = $nodeState{$node->{State}};
      }
      # loop through the ResourceGroups collection
      foreach my $group (in ($clusRef->ResourceGroups)) {
         next unless $group;
         $myRef->{Groups}->{ $group->{Name} }->{Status} 
                           = $groupState{ $group->{State} };
         $myRef->{Groups}->{ $group->{Name} }->{Node} 
                           = $group->{OwnerNode}->{Name};
         # loop through the PreferredOwnerNodes collection
         foreach my $preferredNode (in ($group->{PreferredOwnerNodes})) {
            next unless $preferredNode;
            push @{$myRef->{Groups}->{$group->{Name}}->{PreferredOwnerNodes}},
               $preferredNode->{Name};
         }
      }
      $ref->{$cluster} = $myRef;
   }
   return $ref;
}  # getStatus

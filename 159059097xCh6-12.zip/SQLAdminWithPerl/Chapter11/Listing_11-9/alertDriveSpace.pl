# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw ( dbaReadINI dbaTime2str dbaStr2time );
use Win32::ODBC;
use Data::Dumper;

Main: {
   my $configFile = shift or do { printUsage(); exit; };

   (-T $configFile) or 
      die "***specified config file $configFile does not exist.\n";

   # Read config file into $configRef
   my $ref = dbaReadINI($configFile);

   # check free drive space for each drive and alert accordingly
   $ref = checkFreeSpace($ref);
print Dumper($ref);   
} # Main

####################
sub printUsage {
####################
   print << '--Usage--';
Usage:  
  cmd>perl alertDriveSpace.pl <Config File> 
  
       <Config File>   Config file that specifies what servers to check 
--Usage--
} # printUsage

#########################
sub checkFreeSpace {
#########################
   my $ref = shift or die "***checkFreeSpace() expects a reference.\n";

   foreach my $server (sort keys %$ref) {
      next if $server =~ /^control$/i;
      next if $ref->{$server}->{DISABLED} =~ /^y/i;
      next unless $ref->{$server}->{FREESPACETHRESHOLD} =~ /^\d+/;
      
      my ($instance) = $server =~ /^server\s*:\s*(.+)/i;   
      $instance ||= $server;
   
      my $sql;
      my $connStr = "Driver={SQL Server};Server=$instance;" .
                           "Trusted_Connection=Yes;Database=master";
      my $db = new Win32::ODBC ($connStr);
      unless ($db) {
         print "***could not connect to server $instance.\n";
         next;
      };

      $sql = 'EXEC master..xp_fixeddrives';
      unless ($db->Sql($sql)) {
         while ($db->FetchRow()) {
           my ($d, $s) = $db->Data;
           $ref->{$server}->{FREEDRIVESPACE}->{$d} = $s;
         }
      }        
      else {
         print "***executing $sql. ", Win32::ODBC::Error(), "\n"; 
      }

      # decide whether to alert
      foreach my $drive (sort keys %{$ref->{$server}->{FREEDRIVESPACE}}) {
         if ($ref->{$server}->{FREEDRIVESPACE}->{$drive} < 
                         $ref->{$server}->{FREESPACETHRESHOLD}) {
             $sql = "raiserror('$drive drive on $instance is below " . 
                                $ref->{$server}->{FREESPACETHRESHOLD} . 
                                "MB',18, -1) with log";
             unless ($db->Sql($sql)) {
                1 while $db->FetchRow();
             }
             else {
                 print "***executing $sql.\n"; 
             }
         }            
      }

      $db->Close();
      return $ref;
   }
}  # checkFreeSpace

__END__

=head1 NAME

alertDriveSpace -- Alerting low free local drive space  

=head1 SYNOPSIS

 cmd>perl alertDriveSpace.pl <config file>

=head1 DESCRIPTION

The script I<alertSQLErrorlog.pl> takes a configuration file. If the file path is not specified, 
the config file must be in the current directory. See L<CONFIGURATION FILE> for details.

This script reads the server names and an optional free disk space threshold from 
the configuration file, checks each local hard drive for free space via SQL Server 
xp_fixeddrives, and logs an entry in the SQL Server errorlog if the free space falls 
below the specified threshold for any local hard drive on that server. 
If the threshold is not explicitly specified, a default 
of 200MB is used.

This script is intended to identify critically low free space, and is best run sereral 
times during the day via a separately scheduled job. 

The script does not directly send out any alerts itself. It expects a monitoring program to pick
up the error logged in the SQL Server errorlog.


=head1 CONFIGURATION FILE

The expected config file entries look like the following:

 [SQLServerA]
 Disabled=no
 FreeDriveSpaceThreshold=200
 
 [SQLServerB\Instance1]
 Disabled=yes
 FreeDriveSpaceThreshold=200

The config file can have any other entries for use by other scripts. 
All other entries are simply ignored by this script.

There is no need to use a separate config file for this script alone, though it is perfectly accceptable. 
It is better to piggy-back on 
the config file used by scripts such as I<monitorErrorlogs.pl>. The script reads the server names
from the section headings of the config file. It will ignore any section marked by I<Disabled=yes>. 

Under each instance section heading (i.e. all except [Control]), one can specify the option 
I<FreeDriveSpaceThreshold>. For instance, I<FreeDriveSpaceThreshold=300> indicates that the free drive
space threshold is 300MB. If a drive has less that amount of free space, an error will be logged
in its SQL Server errorlog.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

Version 2002.08.09

=cut


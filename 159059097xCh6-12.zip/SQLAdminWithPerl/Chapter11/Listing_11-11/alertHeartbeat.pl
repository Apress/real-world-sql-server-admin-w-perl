use strict;
use Getopt::Std;
use Win32::OLE;
use SQLDBA::Utility qw( dbaTimeDiff dbaSMTPSend dbaTime2str dbaStr2time 
                        dbaSaveRef dbaReadSavedRef dbaIsBetweenTime );
use Data::Dumper;

Main: {
   my %opts;
   getopts('S:a:s:m:r:q:h', \%opts);

   # check mandatory switches
   if (   $opts{'h'} 
       or !defined $opts{S} or !defined $opts{a} or !defined $opts{s} 
       or !defined $opts{m} or !defined $opts{r} ) {
       printUsage();
       exit;
   }
   my $configRef = {
         SQLInstance          => $opts{S},
         SenderAccount        => $opts{a},
         StatusFile           => $opts{s},
         SMTPServer           => $opts{m},
         DBAPager             => $opts{r},
         QuietTime            => $opts{q}
   };

   # read saved status from the status file, if any
   my $statusRef = (-T $configRef->{StatusFile}) ? 
                       dbaReadSavedRef($configRef->{StatusFile}) : {};

   my $ref = { Config => $configRef,
               Status => $statusRef };

   $ref->{Status}->{RunStart} = dbaTime2str();
   # Check availability
   $ref = checkAvailability($ref);

   #  Decide whether to send an alert
   $ref = alertAvailability($ref);
   $ref->{Status}->{RunFinish} = dbaTime2str();

   # Save status to the status file
   dbaSaveRef($configRef->{StatusFile}, $ref->{Status}, 'ref');
print Dumper($ref);   
} # Main

############################
sub printUsage {
############################
    print << '--Usage--';
Usage:    
cmd>perl alertHeartbeat.pl [-h] -S <instance> -a <sender account>
                                -s <status file> -m <SMTP server>
                                -r <recipient> -q <quiet time>
                                  
        -h    print this usage info
        -S    SQL Server instance 
        -a    Sender account
        -s    status log file to save the current availability status
        -m    SMTP mail server
        -r    alert recipient
        -q    quiet time
--Usage--
} # printUsage

##########################
sub checkAvailability {
##########################
   my $ref = shift or 
         die "***checkAvailability() expects a reference.\n";
   my $server = $ref->{Config}->{SQLInstance};

   CheckHeartbeat: {
      if (isPingOK($server)) {
         $ref->{Status}->{Ping}->{OK} = 1;
      }
      else {
         $ref->{Status}->{Ping}->{OK} = 0;
         $ref->{Status}->{Ping}->{LastFailed} = dbaTime2str();
         $ref->{Status}->{FailedTimes}++;
         $ref->{Status}->{ErrMsg} = 'Failed to ping ' . $server;
         last CheckHeartbeat;
      }
      
      if (isSQLConnectOK($server)) {
         $ref->{Status}->{SQLConnect}->{OK} = 1;
      }
      else {
         $ref->{Status}->{SQLConnect}->{OK} = 0;
         $ref->{Status}->{SQLConnect}->{LastFailed} = dbaTime2str();
         $ref->{Status}->{FailedTimes}++;
         $ref->{Status}->{ErrMsg} = 'Failed to connect to ' . $server;
         last CheckHeartbeat;
      }
   }   
   
   if ($ref->{Status}->{Ping}->{OK} &&
       $ref->{Status}->{SQLConnect}->{OK}) {
      $ref->{Status}->{OK} = 1;
      $ref->{Status}->{FailedTimes} = 0;
   }
   else {
      $ref->{Status}->{OK} = 0;
   }
   return $ref;
} # checkAvailability

####################
sub isPingOK {
####################
    my $server = shift or
      die "***IsPingOK() expects a server name.\n";

    $server =~ s/\\.+$//;  # remove the instance name, if any

    use Net::Ping;
    my $p = Net::Ping->new("icmp");
    my $r = $p->ping($server, 2);
    $p->close();
    return $r;
} # IsPingOK

###########################
sub isSQLConnectOK {
###########################
   my $server = shift or 
      die "***IsSQLConnectOK() expects a server name.\n";

   my $db = Win32::OLE->new('ADODB.Connection');
   $db->{ConnectionTimeout} = 2;
   $db->Open("Driver={SQL Server};Server=$server;Trusted_Connection=yes");
   my $err = Win32::OLE->LastError();
   $db->Close();
   $err ? return 0 : return 1;
} # isSQLConnectOK

#############################
sub alertAvailability {
#############################
   my $ref = shift or die "***alertAvailability() expects a reference.\n";

   my @recipients = ($ref->{Config}->{DBAPager});

   # if there is a problem and is not quiet time
   # send an alert
   if ($ref->{Status}->{OK} == 0 and
       $ref->{Status}->{FailedTimes} > 2 and 
       !dbaIsBetweenTime($ref->{Config}->{QuietTime})) {
         if (dbaSMTPSend($ref->{Config}->{SMTPServer}, 
                      \@recipients, 
                      $ref->{Config}->{SenderAccount},
                      $ref->{Status}->{ErrMsg})) {
            $ref->{Status}->{AlertSent} = 1;
            $ref->{Status}->{LastAlertSent} = dbaTime2str();
            $ref->{Status}->{FailedTimes} = 0;

            printf "%s  %s Sent to %s\n", dbaTime2str(), 
                                      $ref->{Status}->{ErrMsg},
                                      $ref->{Config}->{DBAPager};
         }
   }
   return $ref;
} # alertAvailability
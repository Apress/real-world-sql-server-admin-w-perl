# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use Win32::OLE;

# Import the functions from the module SQLDBA:Utility
use SQLDBA::Utility qw( dbaTimeDiff dbaSMTPSend dbaTime2str dbaStr2time 
                        dbaSaveRef dbaReadSavedRef dbaIsBetweenTime );
use Net::Ping;                        
use Data::Dumper;

Main: {
   my %opts;
   getopts('S:a:s:m:r:q:h', \%opts);

   # check mandatory switches
   if (   $opts{'h'} 
       or !defined $opts{S} or !defined $opts{a} or !defined $opts{s} 
       or !defined $opts{m} or !defined $opts{r} ) {
       printUsage();
       exit;
   }
   my $configRef = {
         SQLInstance          => $opts{S},
         SenderAccount        => $opts{a},
         StatusFile           => $opts{s},
         SMTPServer           => $opts{m},
         DBAPager             => $opts{r},
         QuietTime            => $opts{q}
   };

   # read saved status from the status file, if any
   my $statusRef = (-T $configRef->{StatusFile}) ? 
                       dbaReadSavedRef($configRef->{StatusFile}) : {};

   my $ref = { Config => $configRef,
               Status => $statusRef };

   # Check availability
   $ref = checkAvailability($ref);

   #  Decide whether to send an alert
   $ref = alertAvailability($ref);

   # Save status to the status file
   dbaSaveRef($configRef->{StatusFile}, $ref->{Status}, 'ref');
print Dumper($ref);   
} # Main

############################
sub printUsage {
############################
    print << '--Usage--';
Usage:    
cmd>perl alertAvailability.pl [-h] -S <instance> -a <sender account>
                                   -s <status file> -m <SMTP server>
                                   -r <recipient> -q <quiet time>
                                  
        -h    print this usage info
        -S    SQL Server instance 
        -a    Sender account
        -s    status log file to save the current availability status
        -m    SMTP mail server
        -r    alert recipient
        -q    quiet time
--Usage--
} # printUsage

##########################
sub checkAvailability {
##########################
   my $ref = shift or 
         die "***checkAvailability() expects a reference.\n";
   my $server = $ref->{Config}->{SQLInstance};

   CheckHeartbeat: {
      if (isPingOK($server)) {
         $ref->{Status}->{Ping}->{OK} = 1;
      }
      else {
         $ref->{Status}->{Ping}->{OK} = 0;
         $ref->{Status}->{Ping}->{LastFailed} = dbaTime2str();
         $ref->{Status}->{BadStatusCounter}++;
         $ref->{Status}->{ErrMsg} = 'Failed to ping ' . $server;
         last CheckHeartbeat;
      }
      
      if (isSQLConnectOK($server)) {
         $ref->{Status}->{SQLConnect}->{OK} = 1;
      }
      else {
         $ref->{Status}->{SQLConnect}->{OK} = 0;
         $ref->{Status}->{SQLConnect}->{LastFailed} = dbaTime2str();
         $ref->{Status}->{BadStatusCounter}++;
         $ref->{Status}->{ErrMsg} = 'Failed to connect to ' . $server;
         last CheckHeartbeat;
      }
   }  # CheckHeartbeat
   
   if ($ref->{Status}->{Ping}->{OK} &&
       $ref->{Status}->{SQLConnect}->{OK}) {
      $ref->{Status}->{OK} = 1;
      $ref->{Status}->{BadStatusCounter} = 0;
   }
   else {
      $ref->{Status}->{OK} = 0;
   }
   return $ref;
} # checkAvailability

####################
sub isPingOK {
####################
    my $server = shift or
      die "***IsPingOK() expects a server name.\n";

    $server =~ s/\\.+$//;  # remove the instance name, if any

    my $p = Net::Ping->new("icmp");
    my $r = $p->ping($server, 2);
    $p->close();
    return $r;
} # IsPingOK

###########################
sub isSQLConnectOK {
###########################
   my $server = shift or 
      die "***IsSQLConnectOK() expects a server name.\n";

   my $db = Win32::OLE->new('ADODB.Connection');
   $db->{ConnectionTimeout} = 2;
   $db->Open("Driver={SQL Server};Server=$server;Trusted_Connection=yes");
   my $err = Win32::OLE->LastError();
   $db->Close();
   $err ? return 0 : return 1;
} # isSQLConnectOK

#############################
sub alertAvailability {
#############################
   my $ref = shift or die "***alertAvailability() expects a reference.\n";

   my @recipients = ($ref->{Config}->{DBAPager});
   $ref->{Status}->{AlertSent} = 0; # assume nothing is sent

   # if there is a problem and is not quiet time
   # send an alert
   if ($ref->{Status}->{OK} == 0 and
       $ref->{Status}->{BadStatusCounter} > 2 and 
       !dbaIsBetweenTime($ref->{Config}->{QuietTime})) {
         if (dbaSMTPSend($ref->{Config}->{SMTPServer}, 
                      \@recipients, 
                      $ref->{Config}->{SenderAccount},
                      $ref->{Status}->{ErrMsg})) {
            $ref->{Status}->{AlertSent} = 1;
            $ref->{Status}->{LastAlertSent} = dbaTime2str();
            $ref->{Status}->{BadStatusCounter} = 0;

            printf "%s  %s Sent to %s\n", dbaTime2str(), 
                                      $ref->{Status}->{ErrMsg},
                                      $ref->{Config}->{DBAPager};
         }
   }
   return $ref;
} # alertAvailability

__END__

=head1 NAME

alertAvailability - Monitoring SQL Server availability: the basic version

=head1 SYNOPSIS

 cmd>perl alertAvailability.pl [-h] -S <instance> -a <sender account>
                                    -s <status file> -m <SMTP server>
                                    -r <recipient> -q <quiet time>
                                   
         -h    print this usage info
         -S    SQL Server instance 
         -a    Sender account
         -s    status log file to save the current availability status
         -m    SMTP mail server
         -r    alert recipient
         -q    quiet time

=head1 USAGE EXMAPLE

To monitor the SQL Server instance SQL1 and send alerts to dba@myTel.com, you can 
schedule to run the script I<alertAvailability.pl> as follows (all should be on a single command line):

 cmd>perl alertAvailability.pl -S NJSQL01 -a sql@linchi.com -s status.log
                               -m smtp.linchi.com -r dba@myTel.com -q 22-7

=head1 COMMAND-LINE OPTIONS

The list below describes all the command-line arguments accepted by the script I<alertAvailability.pl>.

=over

=item -S <SQL Server name> 

Specifies the name of the SQL Server instance to be checked for availability.

=item -s <Status file>  

The file to which the availability monitoring status will be saved.

=item -r <Recipient> 

The email address of the alert recipient.

=item -m <SMTP server>  

The SMTP mail server.

=item -a <SMTP account> 

Specifies the account of the SMTP email sender.

=item -q <Quiet time>   

Specifies a period of time -- in the format of hh-hh -- in which no alerts will be sent, 
where hh is between 1 and 24, inclusive.

=item -h 

When specified, the script only prints out the usage information.

=back

=head1 DESCRIPTION

The script I<alertAvailability.pl> monitors SQL Server availability. Its objectives are two fold: 

=over

=item *

To accurately and promptly detect that SQL Server isn't available

=item *

To sufficiently notify the DBA of the unavailability with minimal redundancy in notification

=back

To accomplish these two objectives, the script I<alertAvailability.pl> monitors SQL Server availability 
as follows:

=over

=item 1.

The script runs from a job scheduler at a regular interval -- about once every five minutes.

=item 2.

The script performs two availability checks on the SQL Server instance: First, it pings the 
machine using the Net::Ping module, and second, if the ping is successful, it attempts to connect 
to the SQL Server instance via ActiveX Data Objects (ADO).

=item 3.

If one of the availability checks fails, the availability status is set to bad, and a bad status 
counter is incremented to record the consecutive number of times the bad status is reported.

=item 4.

If both availability checks are successful, the availability status is set to good, and the bad status 
counter is reset to zero.

=item 5.

If the value of the bad status counter reaches three, the script sends a notification to the DBA.

=item 6.

The script saves the data structure representing the status of the availability monitoring to a 
text file to be used when the script runs next time.

=back

=head1 NOTIFICATION RULE

The script implements the following notification rule: 

 If    (1) one of the availability checks fails, 
       (2) the availability checks have failed for more than two consecutive
           times, and it is not in the quiet time period
 Then  send an alert.

It's no accident to insist that the availability check must have failed three consecutive 
times before an alert is sent. This number came out of using such a script in practice for 
an extended time. The primary motivation is to minimize the number of nuisance alerts that 
may be caused by a variety of network problems or hiccups without unduly prolonging the time 
it takes to get notified.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


use strict;
use SQLDBA::Utility qw( dbaReadINI dbaSMTPSend dbaTime2str dbaStr2time 
                        dbaSaveRef dbaReadSavedRef dbaIsBetweenTime );
use Win32::ODBC;                        
use Data::Dumper;

Main: {
   my $configFile = shift;
   unless ($configFile) { printUsage(); exit; }

   (-T $configFile) or 
         die "***Specified config file $configFile does not exist.\n";

   # Read config file into $configRef
   my $configRef = dbaReadINI($configFile);

   # validate config options and set defaults
   $configRef = validateConfig($configRef);

   my $statusRef = (-T $configRef->{CONTROL}->{STATUSFILE}) 
                 ? dbaReadSavedRef($configRef->{CONTROL}->{STATUSFILE}) : {};

   my $ref = { Config => $configRef, Status => $statusRef };

   # Check the errorlog files for critical errors
   $ref = scanErrorlogs($ref);

   #  Decide whether to send alert on critical errors
   $ref = alertErrorlogs($ref);

   # Save status to the status file
   dbaSaveRef($configRef->{CONTROL}->{STATUSFILE}, $ref->{Status}, 'ref');
} # Main

############################
sub printUsage {
############################
    print << '--Usage--';
Usage:  

 perl monitorErrorlogs.pl <Config File> 
    <Config File>   file to specify config options for alerting errorlogs 
--Usage--
}

#########################
sub validateConfig {
#########################
   my $ref = shift or die "***validateConfigRef() expects a reference.\n";

   # make sure that status file is specified
   defined $ref->{CONTROL}->{STATUSFILE} 
      or die "***StatusFile option is not specified.\n";

   # Make sure that SQL errorlog is identified for each server
   #   intervals and thresholds are set
   foreach my $server (keys %$ref) {
      next if ($server =~ /^CONTROL$/i);
      $server =~ /^server\s*:/i or 
         die "***Server name $server in the section " . 
             "heading must be prefixed with Server:\n";
      defined $ref->{$server}->{SQLERRORLOG} or
         die "***SQLErrorlog is not specified for \[$server\].\n";

      # intervals are all in minutes. If they are not set explicitly 
      # in the config file, their default values are set here.
      $ref->{$server}->{CONFIGERRALERTINTERVAL} ||= 60;     # in minutes
      $ref->{$server}->{ERRORLOGSIZEALERTINTERVAL} ||= 120; # in minutes
      $ref->{$server}->{SQLERRALERTINTERVAL} ||= 10;        # in minutes
      $ref->{$server}->{ONPATTERNALERTINTERVAL} ||= 20;     # in minutes
      $ref->{$server}->{ERRORLOGSIZETHRESHOLD} ||= 4000;    # in KB

      # strip off KB postfix, if any. The threshold is always 
      # in KB regardless of the postfix.
      $ref->{$server}->{ERRORLOGSIZETHRESHOLD} =~ s/\s*(K|KB)\s*$//i;
      
      # validate OnPattern regular expressions
      foreach my $aos (grep /^\s*OnPattern\d*\s*$/i, keys %{$ref->{$server}}) {
         $ref->{$server}->{$aos} =~ /^(.+)\s*,\s*\[([^\[]+)\]$/;
         my ($exp, $email) = ($1, $2);
         $exp = "qr$exp" if $exp =~ /^\s*\//;
         eval $exp;
         if ($@) {
            print "***$exp is not a valid regular expression.\n";
            next;
         }
         else {
            my %addresses;  # use its keys to get unique email addresses
            map { $addresses{$_} = 1; } split /[,;\s]+/, $email;
            $ref->{$server}->{$aos} = { 'REGEX' => $exp,
                                        'EMAIL' => [ keys %addresses ]
                                      }
         }
      }
   }
   return $ref;
}  # validateConfig

#########################
sub scanErrorlogs {
#########################
   my $ref = shift or die "***scanErrorlogs() expects a reference.\n";

   SERVER_LOOP:
   foreach my $server (sort keys %{$ref->{Config}}) {
      next if $server =~ /^CONTROL$/i;
      next if $ref->{Config}->{$server}->{DISABLED} =~ /y/i;
      my ($serverName) = $server =~ /^server\s*:\s*(.+)$/i;
      print "Scanning $serverName errorlog ...\n";
   
      # reset the status indicators 
      # (assuming eveything is fine to begin with)
      # This will also initialize the hash elements, if not exist already
      $ref->{Status}->{$server}->{ErrorlogOK} = 1;
      $ref->{Status}->{$server}->{Exception}->{ConfigErr}->{OK} = 1;
      $ref->{Status}->{$server}->{Exception}->{ErrorlogSize}->{OK} = 1;
      $ref->{Status}->{$server}->{Exception}->{SQLErr}->{OK} = 1;
      $ref->{Status}->{$server}->{Exception}->{OnPattern}->{OK} = 1;
      $ref->{Status}->{$server}->{Exception}->{SQLStartup}->{OK} = 1;
      
      # these intermediate variables are used to shorten expressions
      my $statusRef    = $ref->{Status}->{$server};
      my $exceptionRef = $ref->{Status}->{$server}->{Exception};
      my $configRef    = $ref->{Config}->{$server};
      
      # Remove old entries recorded in the status data structure.
      # For now, if the entry is more than 2 days old, it is removed.
      # Reset status (assuming eveything is fine to begin with)
      foreach my $err (keys %{$exceptionRef->{SQLErr}}) {
         next if $err eq 'OK';   
         if ((time() - $exceptionRef->{SQLErr}->{$err}->{Time})
                           > 3600*24*2) {
            delete $exceptionRef->{SQLErr}->{$err};
            next;
         }
         $exceptionRef->{SQLErr}->{$err}->{OK} = 1; 
      }
      # do the same for OnPattern entries
      foreach my $err (keys %{$exceptionRef->{OnPattern}}) {
         next if $err eq 'OK';
         if ((time() - $exceptionRef->{OnPattern}->{$err}->{Time})
                     > 3600*24*2) {
            delete $statusRef->{Exception}->{OnPattern}->{$err};
            next;
         }
         $exceptionRef->{OnPattern}->{$err}->{OK} = 1;
      }
      
      my $errorlog = $configRef->{SQLERRORLOG};

      # Check the size of the errorlog if the threshold is specified.
      $exceptionRef->{ErrorlogSize}->{ActualErrorlogSize} 
                     = int((stat($errorlog))[7] /1024);  # in KB
      if ($exceptionRef->{ErrorlogSize}->{ActualErrorlogSize} 
                 > $configRef->{ERRORLOGSIZETHRESHOLD}) {
         my $msg = "$errorlog on $server too big. Scan not performed.";
         $statusRef->{ErrorlogOK} = 0;
         $exceptionRef->{ErrorlogSize}->{OK} = 0;
         $exceptionRef->{ErrorlogSize}->{ErrMsg} = $msg;
         print "  ***$msg\n";

         # if AutoCycleErrorlog not set, don't even open the errorlog
         next SERVER_LOOP if $configRef->{AUTOCYCLEERRORLOG} !~ /y/i;
      }

      # Now open the errorlog file and check for errors
      my $Tries = 0;
      while (!open(LOG, "$errorlog")) {
         if (++$Tries < 3) { sleep(2); next; }
         else {
            my $msg = "$Tries tries. Couldn't open $errorlog on $server.";
            $statusRef->{ErrorlogOK} = 0;
            $exceptionRef->{ConfigErr}->{OK} = 0;
            $exceptionRef->{ConfigErr}->{ErrMsg} = $msg;
            $exceptionRef->{ConfigErr}->{Time} = time();
            $exceptionRef->{ConfigErr}->{TimeStr} = dbaTime2str();
            
            print "  ***$msg\n";
            next SERVER_LOOP;  # can't open, then quit trying this errorlog
         }
      }
      
      # Now we scan the errorlog file
      my ($time, $timeStr, $error, $severity, $msg);
      while (<LOG>) {
         $statusRef->{MajorVersion}=6 if (/Microsoft\s+SQL\s+Server\s+6/i);
         ($timeStr) = /^\s*([\d\/\-]+\s+[\d\.\:]+)\s+/;

         # skip it if it cannot match the leading datetime string
         next if ($timeStr !~ /\d\d(\/|-)\d\d(\/|-)\d\d\s+\d\d:\d\d:\d\d/);
         $time = dbaStr2time($timeStr);  

         if (/SQL Server is starting/i) {
            if (time() - $time < 7*60) {
print "Checking SQLStartup ...\n":            
               my $msg = "SQL Server restarted at $timeStr";
               $exceptionRef->{SQLStartup}->{OK} = 0;
               $exceptionRef->{SQLStartup}->{ErrMsg} = $msg;
               $exceptionRef->{SQLStartup}->{Time} = time();
               $exceptionRef->{SQLStartup}->{TimeStr} = dbaTime2str();
            }
         }
         
         # skip the log entries already read by a previous run
         next if $time <= $statusRef->{ErrorlogLastReadTime};

         # skip the entries older than IgnoreRecordOlderThan minutes
         next if (time() - $time) > 60*$configRef->{IGNORERECORDOLDERTHAN};

         # if it's a regular SQL error, we need to read in the next line
         if (/Error\s*\:\s*(\d+)\s*\,\s*Severity\s*\:\s*(\d+)/i) {
            ($error, $severity)  = ($1, $2);
            # get the next line since it contains the actual error message
            $_ = <LOG>;
            /^\s*[^\s]+\s+[^\s]+[^\s]+\s+[^\s]+\s+(.+)$/ && ($msg = $1);
            $_ = "Error: $error, Severity: $severity, $msg";
         }

         # if matching one or more of the text patterns
         if (my $emailAddressRef = matchOnPattern($server, $ref, $_)) {
            chomp($_);
            my $errMsg = "$timeStr OnPattern on $serverName " . $_;
            $statusRef->{ErrorlogOK} = 0;
            $exceptionRef->{OnPattern}->{OK} = 0;
            $exceptionRef->{OnPattern}->{$msg} = {
                                       Time         => $time,
                                       TimeStr      => $timeStr,
                                       ErrMsg       => $errMsg,
                                       EmailAddress => $emailAddressRef
                                    };
            print "  ***$errMsg\n";
            next;  # perform no more check on this log entry
         }

         # Critical SQL Server errors with numbers and severities
         if (/Error\s*\:\s*(\d+)\s*\,\s*Severity\s*\:\s*(\d+)/i) {
            my ($error, $severity) = ($1, $2);
            my $errMsg = "$timeStr Err: $error, Severity: $severity " .
                         "on $server. $msg";
            # skip it if this error is on the exclusion list
            next if ($configRef->{EXCLUDESQLERRORS} =~ /\b$error\b/i);

            #  if it's on the severity list
            if ($configRef->{INCLUDESQLSEVERITIES} =~ /\b$severity\b/i) {
               $statusRef->{ErrorlogOK} = 0;
               $exceptionRef->{SQLErr}->{OK} = 0;
               $exceptionRef->{SQLErr}->{"$error\_$severity"} = {
                                       Time => $time,
                                       TimeStr => $timeStr,
                                       ErrMsg  => $errMsg
                                    }; 
               print "  ***$errMsg\n";
            }
         }
      } # while
      close(LOG);
      $statusRef->{ErrorlogLastReadTime} = $time;
      $statusRef->{ErrorlogLastReadTimeStr} = $timeStr;
   }
   return $ref;
}  # scanErrorlogs

#############################
sub matchOnPattern {
#############################
   my ($server, $ref, $msg) = @_;
   ($server && $ref && $msg) or 
         die "***matchOnPattern() expects a server, a reference," .
                        " and the message body.\n";
   my %addresses;
   my $configRef = $ref->{Config}->{$server};
   
   foreach my $aos (grep /^\s*OnPattern\d*\s*$/i, keys %$configRef) {
      my $re = eval $configRef->{$aos}->{REGEX};  # already validated
      if ($msg =~ /$re/) {
         map {$addresses{$_} = 1;} @{$configRef->{$aos}->{EMAIL}};
      }
   }
   my @emails = keys %addresses;
   scalar @emails ? return [ @emails ] : return undef; 
} # matchOnPattern

##########################
sub alertErrorlogs {
##########################
   my $ref = shift or die "***alertrrorlogs() expects a reference.\n";
   my ($server, $msg);
   my ($nowHour, $nowStr) = ((localtime)[2], dbaTime2str());

   foreach $server (sort keys %{$ref->{Status}}) {
      # these two intermediate variables are used to shorten expressions
      my $statusRef = $ref->{Status}->{$server};
      my $configRef = $ref->{Config}->{$server};

      next if ($configRef->{DISABLED} =~ /y/i);
      next if $statusRef->{ErrorlogOK};    # if there is no problem

   # Rule for alerting a config error
   # if 1. config error alert is enabled,
   #    2. there is a config error,
   #    3. it's not ConfigErr quiet time, and
   #    4. Last config error alerted ConfigErrorAlertInterval minutes ago
   # then  send ConfigErr alert
      my $configErrRef = $statusRef->{Exception}->{ConfigErr};
      if ( ($configRef->{ALERTCONFIGERR} =~ /y/i) &&
          ($configErrRef->{OK} == 0) &&
          ( !dbaIsBetweenTime($configRef->{CONFIGERRQUIETTIME}) ) &&
          ((time() - $configErrRef->{LastAlertedTime}) 
                         > ($configRef->{CONFIGERRALERTINTERVAL})*60 ) ) {
             $ref = sendAlert($server, $ref, 'ConfigErr');
             next;
      }

   # Rule for alerting an Errorlog Size error
   # if  1. ErrorlogSize alert is enabled
   #     2. ActualErrorlogSize > Errorlog Size Threshold 
   #     3. Last ErrorlogSize alerted ErrorlogSizeAlertInterval minutes old
   #     4. it is not ErrorlogSize quiet time
   # then  send Errorlog Size Alert
      my $errorlogSizeRef = $statusRef->{Exception}->{ErrorlogSize};
      if (($configRef->{ALERTERRORLOGSIZE} =~ /y/i) &&
          ($errorlogSizeRef->{OK} == 0) &&
          ($errorlogSizeRef->{ActualErrorlogSize} 
                     > $configRef->{ERRORLOGSIZETHRESHOLD})  &&
          ((time() - $errorlogSizeRef->{LastAlertedTime}) 
                     > 60*$configRef->{ERRORLOGSIZEALERTINTERVAL}) &&
           !dbaIsBetweenTime($configRef->{ERRORLOGSIZEQUIETTIME}) ) {
               $ref = sendAlert($server, $ref, 'ErrorlogSize');
      }

   # Rule for alerting on text patterns
   # if    1. there is a error message matching a pattern
   #       2. This error was last alerted OnPatternInterval minutes ago
   #       3. it's not OnPatternQuietTime
   # then  send alert 
      my $onPatternRef = $statusRef->{Exception}->{OnPattern};
      if (!$onPatternRef->{OK} and  
          !dbaIsBetweenTime($configRef->{ONPATTERNQUIETTIME})) {
         foreach my $err (keys %{$onPatternRef}) {
            next if $err =~ /^OK$/i;
            next if $onPatternRef->{$err}->{OK};
            
            if ((time() - $onPatternRef->{$err}->{LastAlertedTime}) 
                     > 60*$configRef->{ONPATTERNALERTINTERVAL}) {
               $ref = sendAlert($server, $ref, 'OnPattern', $err);
            }
         }
      }

   # Rule for alerting SQL Errors
   # if    1. SQLErr alert is enabled
   #       2. there is a critical SQL error
   #       3. This error was last alerted SQLErrAlterInterval minutes ago
   #       4. it's not SQLErr quiet time
   # then  send alert 
      my $SQLErrRef = $statusRef->{Exception}->{SQLErr};
      if (!$SQLErrRef->{OK} and
          !dbaIsBetweenTime($configRef->{SQLERRQUIETTIME})) {
         foreach my $err (keys %{$SQLErrRef}) {
            next if $err =~ /^OK$/i;
            next if $SQLErrRef->{$err}->{OK};
            
            if ( (time() - $SQLErrRef->{$err}->{LastAlertedTime}) 
                           > 60*$configRef->{SQLERRALERTINTERVAL} ) {
               $ref = sendAlert($server, $ref, 'SQLErr', $err);
            }
         }
      }

   # Rule for alerting SQLStartup
   # if    1. SQLStartup alert is enabled
   #       2. SQL Server restarted within 7 minutes
   #       4. it's not SQLStartup quiet time
   # then  send alert 
      my $SQLStartupRef = $statusRef->{Exception}->{SQLStartup};
      if (($SQLStartUpRef->{OK} == 0) &&
           !dbaIsBetweenTime($configRef->{SQLSTARTUPQUIETTIME}) ) {
               $ref = sendAlert($server, $ref, 'SQLStartup');
      }

   # Rule for cycling errorlog 
   # if    1. AutoCycleErrorlog is enabled
   #       2. ActualErrorlogSize > Errorlog Size Threshold 
   #       3. It's not SQL6.5
   # then  cycle the errorlog
      if ( ($configRef->{AUTOCYCLEERRORLOG} =~ /y/i) &&
          ($statusRef->{Exception}->{ErrorlogSize}->{ActualErrorlogSize} 
                     > $configRef->{ERRORLOGSIZETHRESHOLD})  &&
           $statusRef->{MajorVersion} != 6 ) {
                 $ref = cycleErrorlog($server, $ref);
      }
   }
   return $ref;
} # alertErrorlogs

####################
sub sendAlert {
####################
   my($server, $ref, $type, $err) = @_;

   # $type must one of ConfigErr, ErrorlogSize, SQLErr, OnPattern
   unless ($type =~ /^(ConfigErr|ErrorlogSize|SQLErr|OnPattern)$/i) {
      print "***$type not among ConfigErr,ErrorlogSize,SQLErr,OnPattern\n";
      return $ref;
   }
   
   my $configRef = $ref->{Config};
   my $statusRef = $ref->{Status}->{$server}->{Exception}->{$type};
   my @recipients;
   if ($type eq 'OnPattern') {
      @recipients = @{$statusRef->{$err}->{EmailAddress}};
   }
   else {
      @recipients = split (/[;,\s]+/, $configRef->{$server}->{DBAPAGER});
      @recipients = ($configRef->{CONTROL}->{DUTYPAGER}) if !@recipients;
   }
   
   if ($type =~ /^(OnPattern|SQLErr)$/i ) {
      my $errRef = $statusRef->{$err};
      $errRef->{SendAlertOK} = 0;
      if (dbaSMTPSend($configRef->{CONTROL}->{SMTPSERVER}, 
                   \@recipients, 
                   $configRef->{CONTROL}->{SMTPSENDER},
                   $errRef->{ErrMsg})) {
         $errRef->{LastAlertedTime} = time();
         $errRef->{LastAlertedTimeStr} = dbaTime2str();
         $errRef->{SendAlertOK} = 1;
         
         my $logFile = $configRef->{CONTROL}->{ALERTLOGFILE};
         if (open (LOG, ">>$logFile")) {
            printf LOG "%s  %s  %s Sent to %s\n", dbaTime2str(), 
                       $type, $errRef->{ErrMsg}, join(',', @recipients);
            close(LOG);
         }
         else { print "***Failed to open $logFile\n"; }
      }
      $ref->{Status}->{$server}->{Exception}->{$type}->{$err} = $errRef;
   }

   if ($type =~ /^(ConfigErr|ErrorlogSize|SQLStartup)$/i ) {   
      my $typeRef = $ref->{Status}->{$server}->{Exception}->{$type};
      $typeRef->{SendAlertOK} = 0;
      if (dbaSMTPSend($configRef->{CONTROL}->{SMTPSERVER}, 
                   \@recipients, 
                   $configRef->{CONTROL}->{SMTPSENDER},
                   $typeRef->{ErrMsg})) {
         $typeRef->{LastAlertedTime} = time();
         $typeRef->{LastAlertedTimeStr} = dbaTime2str();
         $typeRef->{SendAlertOK} = 1;

         my $logFile = $configRef->{CONTROL}->{ALERTLOGFILE};
         if (open (LOG, ">>$logFile")) {
            printf LOG "%s  %s  %s Sent to %s\n", dbaTime2str(), 
                       $type, $typeRef->{ErrMsg}, join(',', @recipients);
            close(LOG);
         }
         else { print "***Failed to open $logFile\n"; }
      }
      $ref->{Status}->{$server}->{Exception}->{$type} = $typeRef;
   }
   return $ref;
}  # sendAlert

#########################
sub cycleErrorlog {
#########################
   my($server, $ref) = @_;
   ($server && $ref) or 
      die "***cycleErrorlog() expects server and reference.\n";

   my $db;
   my $cycleRef = $ref->{Status}->{$server}->{Exception}->{CycleErrorlog};
   my ($serverName) = $server =~ /^server\s*:\s*(.+)$/i;
   my $connStr = "Driver={SQL Server};Server=$serverName;" .
                 "Trusted_Connection=Yes;Database=master";
                 
   unless($db = new Win32::ODBC ($connStr)) {
     $cycleRef->{OK} = 0;
     $cycleRef->{ErrMsg} = 
            "ODBC failed to connect to $server. " . Win32::ODBC::Error();
     $cycleRef->{CycleErrorlogTimeStr} = dbaTime2str();
     $cycleRef->{CycleErrorlogTime} = time();
     $ref->{Status}->{$server}->{Exception}->{CycleErrorlog} = $cycleRef;
     return $ref;
   }
   
   # execute DBCC errorlog to recycle the errorlog
   if ($db->Sql( 'DBCC errorlog' )) {
     $cycleRef->{OK} = 0;
     $cycleRef->{ErrMsg} = 
            "ODBC couldn't execute DBCC ERRORLOG. " . Win32::ODBC::Error();
     $cycleRef->{CycleErrorlogTimeStr} = dbaTime2str();
     $cycleRef->{CycleErrorlogTime} = time();
   }
   else {
     1 while $db->FetchRow();
     $cycleRef->{OK} = 1;
     $cycleRef->{ErrMsg} = "Errorlog on $server cycled";
     $cycleRef->{CycleErrorlogTimeStr} = dbaTime2str();
     $cycleRef->{CycleErrorlogTime} = time();

     if (open (LOG, ">>$ref->{Config}->{CONTROL}->{ALERTLOGFILE}")) {
        printf LOG "%s  %s\n", dbaTime2str(), $cycleRef->{ErrMsg};
        close(LOG);
     }
     else {
        print "***Couldn't open $ref->{Config}->{CONTROL}->{ALERTLOGFILE}\n";
     }
   }
   $ref->{Status}->{$server}->{Exception}->{CycleErrorlog} = $cycleRef;
   return $ref;
}  # cycleErrorlog
# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaReadINI dbaSMTPSend dbaTime2str dbaStr2time 
                        dbaSaveRef dbaReadSavedRef dbaIsBetweenTime );
use Win32::ODBC;                        
use Data::Dumper;
# direct STDERR to STDOUT
open(STDERR, ">&STDOUT") or die "***Err: couldn't dup STDOUT.";

Main: {
   my $configFile = shift;
   unless ($configFile) { printUsage(); exit; }

   (-T $configFile) or 
         die "***Specified config file $configFile does not exist.\n";

   # Read config file into $configRef
   my $configRef = dbaReadINI($configFile);

   # validate config options and set defaults
   $configRef = validateConfig($configRef);

   # read from the status file
   my $statusRef = (-T $configRef->{CONTROL}->{STATUSFILE}) 
                 ? dbaReadSavedRef($configRef->{CONTROL}->{STATUSFILE}) : {};

   my $ref = { Config => $configRef, Status => $statusRef };

   # initialize the status data structure, if necessary
   $ref = initializeStatus($ref);

   # Check the errorlog files for critical errors
   $ref = scanErrorlogs($ref);

   #  Decide whether to send alert on critical errors
   $ref = alertErrorlogs($ref);

print Dumper($ref);
   # Save status to the status file
   dbaSaveRef($configRef->{CONTROL}->{STATUSFILE}, $ref->{Status}, 'ref');
} # Main

############################
sub printUsage {
############################
    print << '--Usage--';
Usage:  

 perl monitorErrorlogs.pl <Config File> 
    <Config File>   file to specify config options for alerting errorlogs 
--Usage--
}

#########################
sub validateConfig {
#########################
   my $ref = shift or die "***validateConfigRef() expects a reference.\n";

   # make sure that status file is specified
   defined $ref->{CONTROL}->{STATUSFILE} 
      or die "***StatusFile option is not specified.\n";

   # Make sure that SQL errorlog is identified for each server
   #   intervals and thresholds are set
   foreach my $server (keys %$ref) {
      next if ($server =~ /^CONTROL$/i);
      $server =~ /^server\s*:/i or 
         die "***Err: $server in the heading must be prefixed with Server:\n";
      defined $ref->{$server}->{SQLERRORLOG} or
         die "***Err: SQLErrorlog is not specified for \[$server\].\n";

      # intervals are all in minutes. If they are not set explicitly 
      # in the config file, their default values are set here.
      $ref->{$server}->{CONFIGERRALERTINTERVAL} ||= 60;     # in minutes
      $ref->{$server}->{ERRORLOGSIZEALERTINTERVAL} ||= 120; # in minutes
      $ref->{$server}->{SQLERRALERTINTERVAL} ||= 10;        # in minutes
      $ref->{$server}->{ONPATTERNALERTINTERVAL} ||= 20;     # in minutes
      $ref->{$server}->{IGNOREENTRYOLDERTHAN} ||= 600;     # in minutes
      $ref->{$server}->{ERRORLOGSIZETHRESHOLD} ||= 4000;    # in KB

      # strip off KB postfix, if any. The threshold is always 
      # in KB regardless of the postfix.
      $ref->{$server}->{ERRORLOGSIZETHRESHOLD} =~ s/\s*(K|KB)\s*$//i;
      
      # validate OnPattern regular expressions
      foreach my $op (grep /^\s*OnPattern\d*\s*$/i, keys %{$ref->{$server}}) {
         $ref->{$server}->{$op} =~ /^(.+)\s*,\s*\[([^\[]+)\]$/;
         my ($exp, $email) = ($1, $2);
         $exp = "qr$exp" if $exp =~ /^\s*\//;
         eval $exp;
         if ($@) {
            print "***Err: $exp is not a valid regular expression.\n";
            next;
         }
         else {
            my %addresses;  # use its keys to get unique email addresses
            map { $addresses{$_} = 1; } split /[,;\s]+/, $email;
            $ref->{$server}->{$op} = { 'REGEX' => $exp,
                                       'EMAIL' => [ keys %addresses ]
                                     }
         }
      }
   }
   return $ref;
}  # validateConfig

###########################
sub initializeStatus {
###########################
   my $ref = shift or die "***Err: initializeStatus() expects a reference.\n";

   foreach my $server (sort keys %{$ref->{Config}}) {
      next if $server =~ /^CONTROL$/i;
      # skip the server if flagged as disabled
      next if $ref->{Config}->{$server}->{DISABLED} =~ /y/i;
      # remove the Server: prefix
      my ($serverName) = $server =~ /^SERVER\s*:\s*(.+)$/i;

      # reset and/or initialize the status indicators 
      # (assuming eveything is fine to begin with)
      # This will also initialize the hash elements, if not exist already
      $ref->{Status}->{$server}->{ErrorlogOK} = 1;
      $ref->{Status}->{$server}->{Exception}->{ConfigErr}->{OK} = 1;
      $ref->{Status}->{$server}->{Exception}->{ErrorlogSize}->{OK} = 1;
      $ref->{Status}->{$server}->{Exception}->{SQLErr}->{OK} = 1;
      $ref->{Status}->{$server}->{Exception}->{OnPattern}->{OK} = 1;
      
      # these intermediate variables are used to shorten expressions
      my $exceptionRef = $ref->{Status}->{$server}->{Exception};
      my $configRef    = $ref->{Config}->{$server};
      
      # Remove old entries from the status data structure 
      # for each exception category. 

      # Exception category: ConfigErr
      if ((time() - $exceptionRef->{ConfigErr}->{Time})
                     > 3600*24*$configRef->{REMOVESAVEDSTATUSOLDERTHAN}) {
         $exceptionRef->{ConfigErr} = { OK => 1 };
      }
      # Exception category: ErrorlogSize
      if ((time() - $exceptionRef->{ErrorlogSize}->{Time})
                     > 3600*24*$configRef->{REMOVESAVEDSTATUSOLDERTHAN}) {
         $exceptionRef->{ErrorlogSize} = { OK => 1 };
      }
      # Exception category: SQLErr
      foreach my $err (keys %{$exceptionRef->{SQLErr}}) {
         next if $err eq 'OK';   
         if ((time() - $exceptionRef->{SQLErr}->{$err}->{Time})
                     > 3600*24*$configRef->{REMOVESAVEDSTATUSOLDERTHAN}) {
            delete $exceptionRef->{SQLErr}->{$err};
            next;
         }
         $exceptionRef->{SQLErr}->{$err}->{OK} = 1; 
      }
      # Exception category: OnPattern
      foreach my $err (keys %{$exceptionRef->{OnPattern}}) {
         next if $err eq 'OK';
         if ((time() - $exceptionRef->{OnPattern}->{$err}->{Time})
                     > 3600*24*$configRef->{REMOVESAVEDSTATUSOLDERTHAN}) {
            delete $exceptionRef->{OnPattern}->{$err};
            next;
         }
         $exceptionRef->{OnPattern}->{$err}->{OK} = 1;
      }
   }
   return $ref;
} # initializeStatus

#########################
sub scanErrorlogs {
#########################
   my $ref = shift or die "***scanErrorlogs() expects a reference.\n";

   SERVER_LOOP:
   foreach my $server (sort keys %{$ref->{Config}}) {
      next if $server =~ /^CONTROL$/i;
      next if $ref->{Config}->{$server}->{DISABLED} =~ /y/i;
      my ($serverName) = $server =~ /^server\s*:\s*(.+)$/i;
      print "Scanning $serverName errorlog ...\n";
   
      # these intermediate variables are used to shorten expressions
      my $statusRef    = $ref->{Status}->{$server};
      my $exceptionRef = $ref->{Status}->{$server}->{Exception};
      my $configRef    = $ref->{Config}->{$server};
      my $errorlog     = $configRef->{SQLERRORLOG};

      # Errorlog size check, if the threshold is specified.
      $exceptionRef->{ErrorlogSize}->{ActualErrorlogSize} 
                     = int((stat($errorlog))[7] /1024);  # in KB
      if ($exceptionRef->{ErrorlogSize}->{ActualErrorlogSize} 
                 > $configRef->{ERRORLOGSIZETHRESHOLD}) {
         my $msg = "$errorlog on $server too big. Scan not performed.";
         $statusRef->{ErrorlogOK} = 0;
         $exceptionRef->{ErrorlogSize}->{OK} = 0;
         $exceptionRef->{ErrorlogSize}->{ErrMsg} = $msg;
         $exceptionRef->{ErrorlogSize}->{Time} = time();
         $exceptionRef->{ErrorlogSize}->{TimeStr} = dbaTime2str();
         print "  ***$msg\n";
         # if AutoCycleErrorlog not set, don't even open the errorlog
         next SERVER_LOOP if $configRef->{AUTOCYCLEERRORLOG} !~ /y/i;
      }

      # Now open the errorlog file and check for errors
      my $Tries = 0;
      while (!open(LOG, "$errorlog")) {
         if (++$Tries < 3) { sleep(2); next; }
         else {
            my $msg = "$Tries tries. Couldn't open $errorlog on $server.";
            $statusRef->{ErrorlogOK} = 0;
            $exceptionRef->{ConfigErr}->{OK} = 0;
            $exceptionRef->{ConfigErr}->{ErrMsg} = $msg;
            $exceptionRef->{ConfigErr}->{Time} = time();
            $exceptionRef->{ConfigErr}->{TimeStr} = dbaTime2str();
            print "  ***$msg\n";
            next SERVER_LOOP;  # can't open, then quit trying this errorlog
         }
      }
      
      # Now we scan the errorlog file
      my ($time, $timeStr, $error, $severity, $msg);
      while (<LOG>) {
         $statusRef->{MajorVersion}=6 if (/Microsoft\s+SQL\s+Server\s+6/i);
         ($timeStr) = /^\s*([\d\/\-]+\s+[\d\.\:]+)\s+/;
         # skip it if it cannot match the leading datetime string
         next if ($timeStr !~ /\d\d(\/|-)\d\d(\/|-)\d\d\s+\d\d:\d\d:\d\d/);
         $time = dbaStr2time($timeStr);  

         # skip the log entries already read by a previous run
         next if $time <= $statusRef->{ErrorlogLastReadTime};
         # skip the entries older than IgnoreEntryOlderThan minutes
         next if (time() - $time) > $configRef->{IGNOREENTRYOLDERTHAN};

         # if it's a regular SQL error, we need to read in the next line
         if (/Error\s*\:\s*(\d+)\s*\,\s*Severity\s*\:\s*(\d+)/i) {
            ($error, $severity)  = ($1, $2);
            # get the next line since it contains the actual error message
            $_ = <LOG>;
            /^\s*[^\s]+\s+[^\s]+[^\s]+\s+[^\s]+\s+(.+)$/ && ($msg = $1);
            $_ = "Error: $error, Severity: $severity, $msg";
         }

         # checking OnPattern exceptions
         if (my $emailAddressRef = matchOnPattern($server, $ref, $_)) {
            chomp($_);
            s/Error\s*\:\s*(\d+)\s*\,\s*Severity\s*\:\s*(\d+)//i; # keep msg only
            my $errMsg = "$timeStr, $serverName, " . $_;
            $statusRef->{ErrorlogOK} = 0;
            $exceptionRef->{OnPattern}->{OK} = 0;
            $exceptionRef->{OnPattern}->{$msg}->{OK} = 0;
            $exceptionRef->{OnPattern}->{$msg}->{Time} = $time;
            $exceptionRef->{OnPattern}->{$msg}->{TimeStr} = $timeStr;
            $exceptionRef->{OnPattern}->{$msg}->{ErrMsg} = $errMsg;
            $exceptionRef->{OnPattern}->{$msg}->{EmailAddress} 
                                                = $emailAddressRef;
            print "  ***$errMsg\n";
            next;  # perform no more check on this log entry
         }

         # checking SQLErr exceptions
         if (/Error\s*\:\s*(\d+)\s*\,\s*Severity\s*\:\s*(\d+)/i) {
            my ($error, $severity) = ($1, $2);
            my $errMsg = "$timeStr Err: $error, Severity: $severity " .
                         "on $server. $msg";
            # skip it if this error is on the exclusion list
            next if ($configRef->{EXCLUDESQLERRORS} =~ /\b$error\b/i);

            #  if it's on the severity list
            if ($configRef->{INCLUDESQLSEVERITIES} =~ /\b$severity\b/i) {
               $statusRef->{ErrorlogOK} = 0;
               $exceptionRef->{SQLErr}->{OK} = 0;
               my $sqlErr = "$error\_$severity";
               $exceptionRef->{SQLErr}->{$sqlErr}->{OK} = 0;
               $exceptionRef->{SQLErr}->{$sqlErr}->{Time} = $time;
               $exceptionRef->{SQLErr}->{$sqlErr}->{TimeStr} = $timeStr;
               $exceptionRef->{SQLErr}->{$sqlErr}->{ErrMsg} = $errMsg;
               print "  ***$errMsg\n";
            }
         }
      } # while
      close(LOG);
      $statusRef->{ErrorlogLastReadTime} = $time;
      $statusRef->{ErrorlogLastReadTimeStr} = $timeStr;
   }
   return $ref;
}  # scanErrorlogs

#############################
sub matchOnPattern {
#############################
   my ($server, $ref, $msg) = @_;
   ($server && $ref && $msg) or 
         die "***matchOnPattern() expects a server, a reference," .
                        " and the message body.\n";
   my %addresses;
   my $configRef = $ref->{Config}->{$server};
   print "$msg\n";
   
   foreach my $op (grep /^\s*OnPattern\d*\s*$/i, keys %$configRef) {
      my $re = eval $configRef->{$op}->{REGEX}; # already validated
      if ($msg =~ /$re/) {
         map {$addresses{$_} = 1;} @{$configRef->{$op}->{EMAIL}};
      }
   }
   my @emails = keys %addresses;
   scalar @emails ? return [ @emails ] : return undef; 
} # matchOnPattern

##########################
sub alertErrorlogs {
##########################
   my $ref = shift or die "***alertrrorlogs() expects a reference.\n";
   my ($server, $msg);
   my ($nowHour, $nowStr) = ((localtime)[2], dbaTime2str());

   foreach $server (sort keys %{$ref->{Status}}) {
      # these two intermediate variables are used to shorten expressions
      my $statusRef = $ref->{Status}->{$server};
      my $configRef = $ref->{Config}->{$server};

      next if ($configRef->{DISABLED} =~ /y/i);
      next if $statusRef->{ErrorlogOK};    # if there is no problem

   # Rule for alerting a config error
   # if 1. config error alert is enabled,
   #    2. there is a config error,
   #    3. it's not ConfigErr quiet time, and
   #    4. Last config error alerted ConfigErrorAlertInterval minutes ago
   # then  send ConfigErr alert
      my $configErrRef = $statusRef->{Exception}->{ConfigErr};
      if ( ($configRef->{ALERTCONFIGERR} =~ /y/i) &&
          ($configErrRef->{OK} == 0) &&
          ( !dbaIsBetweenTime($configRef->{CONFIGERRQUIETTIME}) ) &&
          ((time() - $configErrRef->{LastAlertedTime}) 
                         > ($configRef->{CONFIGERRALERTINTERVAL})*60 ) ) {
             $ref = sendAlert($server, $ref, 'ConfigErr');
             next;
      }

   # Rule for alerting an Errorlog Size error
   # if  1. ErrorlogSize alert is enabled
   #     2. ActualErrorlogSize > Errorlog Size Threshold 
   #     3. Last ErrorlogSize alerted ErrorlogSizeAlertInterval minutes old
   #     4. it is not ErrorlogSize quiet time
   # then  send Errorlog Size Alert
      my $errorlogSizeRef = $statusRef->{Exception}->{ErrorlogSize};
      if (($configRef->{ALERTERRORLOGSIZE} =~ /y/i) &&
          ($errorlogSizeRef->{OK} == 0) &&
          ($errorlogSizeRef->{ActualErrorlogSize} 
                     > $configRef->{ERRORLOGSIZETHRESHOLD})  &&
          ((time() - $errorlogSizeRef->{LastAlertedTime}) 
                     > 60*$configRef->{ERRORLOGSIZEALERTINTERVAL}) &&
           !dbaIsBetweenTime($configRef->{ERRORLOGSIZEQUIETTIME}) ) {
               $ref = sendAlert($server, $ref, 'ErrorlogSize');
      }

   # Rule for alerting on text patterns
   # if    1. there is a error message matching a pattern
   #       2. This error was last alerted OnPatternInterval minutes ago
   #       3. it's not OnPatternQuietTime
   # then  send alert 
      my $onPatternRef = $statusRef->{Exception}->{OnPattern};
      if (!$onPatternRef->{OK} and  
          !dbaIsBetweenTime($configRef->{ONPATTERNQUIETTIME})) {
         foreach my $err (keys %{$onPatternRef}) {
            next if $err =~ /^OK$/i;
            next if $onPatternRef->{$err}->{OK};
            
            if ((time() - $onPatternRef->{$err}->{LastAlertedTime}) 
                     > 60*$configRef->{ONPATTERNALERTINTERVAL}) {
               $ref = sendAlert($server, $ref, 'OnPattern', $err);
            }
         }
      }

   # Rule for alerting SQL Errors
   # if    1. SQLErr alert is enabled
   #       2. there is a critical SQL error
   #       3. This error was last alerted SQLErrAlterInterval minutes ago
   #       4. it's not SQLErr quiet time
   # then  send alert 
      my $SQLErrRef = $statusRef->{Exception}->{SQLErr};
      if (!$SQLErrRef->{OK} and
          !dbaIsBetweenTime($configRef->{SQLERRQUIETTIME})) {
         foreach my $err (keys %{$SQLErrRef}) {
            next if $err =~ /^OK$/i;
            next if $SQLErrRef->{$err}->{OK};
            
            if ( (time() - $SQLErrRef->{$err}->{LastAlertedTime}) 
                           > 60*$configRef->{SQLERRALERTINTERVAL} ) {
               $ref = sendAlert($server, $ref, 'SQLErr', $err);
            }
         }
      }

   # Rule for cycling errorlog 
   # if    1. AutoCycleErrorlog is enabled
   #       2. ActualErrorlogSize > Errorlog Size Threshold 
   #       3. It's not SQL6.5
   # then  cycle the errorlog
      if ( ($configRef->{AUTOCYCLEERRORLOG} =~ /y/i) &&
          ($statusRef->{Exception}->{ErrorlogSize}->{ActualErrorlogSize} 
                     > $configRef->{ERRORLOGSIZETHRESHOLD})  &&
           $statusRef->{MajorVersion} != 6 ) {
                 $ref = cycleErrorlog($server, $ref);
      }
   }
   return $ref;
} # alertErrorlogs

####################
sub sendAlert {
####################
   my($server, $ref, $type, $err) = @_;

   # $type must one of ConfigErr, ErrorlogSize, SQLErr, OnPattern
   unless ($type =~ /^(ConfigErr|ErrorlogSize|SQLErr|OnPattern)$/i) {
      print "***$type not among ConfigErr,ErrorlogSize,SQLErr,OnPattern\n";
      return $ref;
   }
   
   my $configRef = $ref->{Config};
   my $statusRef = $ref->{Status}->{$server}->{Exception}->{$type};
   my @recipients;
   if ($type eq 'OnPattern') {
      @recipients = @{$statusRef->{$err}->{EmailAddress}};
   }
   else {
      @recipients = split (/[;,\s]+/, $configRef->{$server}->{DBAPAGER});
      @recipients = ($configRef->{CONTROL}->{DUTYPAGER}) if !@recipients;
   }
   
   if ($type =~ /^(OnPattern|SQLErr)$/i ) {
      my $errRef = $statusRef->{$err};
      $errRef->{SendAlertOK} = 0;
      if (dbaSMTPSend($configRef->{CONTROL}->{SMTPSERVER},  # SMTP server
                   \@recipients,                            # recipients
                   $configRef->{CONTROL}->{SMTPSENDER},     # sender
                   undef,                                   # msg body
                   $errRef->{ErrMsg})) {                    # subject
         $errRef->{LastAlertedTime} = time();
         $errRef->{LastAlertedTimeStr} = dbaTime2str();
         $errRef->{SendAlertOK} = 1;
         
         my $logFile = $configRef->{CONTROL}->{ALERTLOGFILE};
         if (open (LOG, ">>$logFile")) {
            printf LOG "%s  %s  %s Sent to %s\n", dbaTime2str(), 
                       $type, $errRef->{ErrMsg}, join(',', @recipients);
            close(LOG);
         }
         else { print "***Failed to open $logFile\n"; }
      }
      $ref->{Status}->{$server}->{Exception}->{$type}->{$err} = $errRef;
   }

   if ($type =~ /^(ConfigErr|ErrorlogSize)$/i ) {   
      my $typeRef = $ref->{Status}->{$server}->{Exception}->{$type};
      $typeRef->{SendAlertOK} = 0;
      if (dbaSMTPSend($configRef->{CONTROL}->{SMTPSERVER}, 
                   \@recipients, 
                   $configRef->{CONTROL}->{SMTPSENDER},
                   $typeRef->{ErrMsg})) {
         $typeRef->{LastAlertedTime} = time();
         $typeRef->{LastAlertedTimeStr} = dbaTime2str();
         $typeRef->{SendAlertOK} = 1;

         my $logFile = $configRef->{CONTROL}->{ALERTLOGFILE};
         if (open (LOG, ">>$logFile")) {
            printf LOG "%s  %s  %s Sent to %s\n", dbaTime2str(), 
                       $type, $typeRef->{ErrMsg}, join(',', @recipients);
            close(LOG);
         }
         else { print "***Failed to open $logFile\n"; }
      }
      $ref->{Status}->{$server}->{Exception}->{$type} = $typeRef;
   }
   return $ref;
}  # sendAlert

#########################
sub cycleErrorlog {
#########################
   my($server, $ref) = @_;
   ($server && $ref) or 
      die "***cycleErrorlog() expects server and reference.\n";

   my $conn;
   my $cycleRef = $ref->{Status}->{$server}->{Exception}->{CycleErrorlog};
   my ($serverName) = $server =~ /^server\s*:\s*(.+)$/i;
   my $connStr = "Driver={SQL Server};Server=$serverName;" .
                 "Trusted_Connection=Yes;database=master";
                 
   unless($conn = new Win32::ODBC ($connStr)) {
     $cycleRef->{OK} = 0;
     $cycleRef->{ErrMsg} = 
            "ODBC failed to connect to $server. " . Win32::ODBC::Error();
     $cycleRef->{CycleErrorlogTimeStr} = dbaTime2str();
     $cycleRef->{CycleErrorlogTime} = time();
     $ref->{Status}->{$server}->{Exception}->{CycleErrorlog} = $cycleRef;
     return $ref;
   }
   
   # execute DBCC errorlog to recycle the errorlog
   if ($conn->Sql( 'DBCC errorlog' )) {
     $cycleRef->{OK} = 0;
     $cycleRef->{ErrMsg} = 
            "ODBC couldn't execute DBCC ERRORLOG. " . Win32::ODBC::Error();
     $cycleRef->{CycleErrorlogTimeStr} = dbaTime2str();
     $cycleRef->{CycleErrorlogTime} = time();
   }
   else {
     1 while $conn->FetchRow();
     $cycleRef->{OK} = 1;
     $cycleRef->{ErrMsg} = "Errorlog on $server cycled";
     $cycleRef->{CycleErrorlogTimeStr} = dbaTime2str();
     $cycleRef->{CycleErrorlogTime} = time();

     if (open (LOG, ">>$ref->{Config}->{CONTROL}->{ALERTLOGFILE}")) {
        printf LOG "%s  %s\n", dbaTime2str(), $cycleRef->{ErrMsg};
        close(LOG);
     }
     else {
        print "***Couldn't open $ref->{Config}->{CONTROL}->{ALERTLOGFILE}\n";
     }
   }
   $ref->{Status}->{$server}->{Exception}->{CycleErrorlog} = $cycleRef;
   return $ref;
}  # cycleErrorlog

__END__

=head1 NAME

monitorErrorlogs - Monitoring SQL Server errorlogs: the robust version

=head1 SYNOPSIS

  cmd>perl alertErrorlog1.pl  <config file> 


=head1 DESCRIPTION

This script monitors the SQL Server errorlogs for the following exceptions:

=over

=item *

Exceptions caused by inappropriate configurations of the monitoring script itself.

=item *

Exceptions caused by excessively large errorlog size.

=item *

Exceptions caused by SQL Server errors.

=item *

Exceptions as the result of matching string patterns in the errorlog. 

=back

The exceptions in the same category are detected and notified with the same logic. 

=head2 Configuration Options

The script I<monitorErrorlogs.pl> accepts a configuration file on the command line. All
configurations are specified in this configuration file. The folloiwng is 
a sample configuration file for the errorlogs of SQL Server instances, SQL1 and SQL1\APOLLO.

 [Control]
 DutyPager=74321@myTel.com
 SMTPServer=mail.linchi.com
 SMTPSender=sql@linchi.com
 AlertLogFile=e:\dba\alertErrorlog\Alert.log
 StatusFile=e:\dba\alertErrorlog\Status.log
 
 [Server:SQL1]  
 SQLErrorlog=\\SQL1\D$\MSSQL\LOG\Errorlog
 Disabled=no
 DBAPager=75114@myTel.com        
 IgnoreEntryOlderThan=300
 RemoveSavedStatusOlderThan=2
 
 AlertConfigErr=yes
 ConfigErrAlertInterval=50
 ConfigErrQuietTime=23-7
 
 AlertErrorlogSize=yes
 ErrorlogSizeThreshold=3000
 ErrorlogSizeAlertInterval=120
 ErrorlogSizeQuietTime=18-8
 
 AlertSQLErr=yes
 IncludeSQLSeverities=17,18,19,20,21,22,23,24,25
 ExcludeSQLErrors=1608,17832,17824
 SQLErrAlertInterval=5
 SQLErrQuietTime=22-7
 
 OnPattern01=/BACKUP failed.+database (SMD|RMD)\s/i, [75114@myTel.com]
 OnPattern02=/Fatal error in database (?!(pubs|NorthWind)\b)/i,[73056@myTel.com]
 OnPatternQuietTime = 22-7
 OnPatternAlertInterval = 2
 
 [Server:SQL1\APOLLO]
 SQLErrorlog=\\SQL1\E$\MSSQL\MSSQL$APOLLO\LOG\Errorlog
 Disabled=no
 DBAPager=74321@myTel.com        
 IgnoreEntryOlderThan=300
 RemoveSavedStatusOlderThan=2
 
 AlertConfigErr=yes
 ConfigErrAlertInterval=60
 ConfigErrQuietTime=12-7
 
 AlertErrorlogSize=yes
 ErrorlogSizeThreshold=3000
 ErrorlogSizeAlertInterval=120
 ErrorlogSizeQuietTime=18-8
 
 AlertSQLErr=yes
 IncludeSQLErrors=
 IncludeSQLSeverities=17,18,19,20,21,22,23,24,25
 ExcludeSQLErrors=1608,17832,17824
 SQLErrAlertInterval=5
 SQLErrQuietTime=22-7

The Control section includes the options that aren't particular to any individual SQL Server errorlog. 
Rather, they apply to the overall working of the script. 

=over

=item DutyPager

Alerts for a SQL Server errorlog will be sent to the address of DutyPager if no pager address is 
specified with the option DBAPager under the section for that specific SQL Server errorlog. 
In other words, DutyPager in the Control section is used as a convenient fallback or default pager. 

=item SMTPServer 

Specifies the address of the SMTP server that handles all the outgoing notification emails. 

=item SMTPSender 

Identifies the sender of all the SMTP emails. 

=item AlertLogFile 

Specifies the location of the file in which the script will record an entry after it has 
successfully sent an alert. This log file gives the DBA a history of the alerts sent by the 
script and is useful for troubleshooting purposes. 

=item StatusFile

The script persists the errorlog monitoring status to the file specified by the option StatusFile. 
The information in the status file helps the script I<monitorErrorlogs.pl> make better decisions 
when it runs again.

=back

Underneath the section heading for each SQL Server instance, the following options can be specified:

=over

=item SQLErrorlog 

Specifies which SQL Server errorlog to open and scan. A filename using Uniform Naming Convention (UNC) 
is expected for this option so that the script can always find the errorlog no matter where it may 
be running. 

=item Disabled 

This is an option to enhance the usability of the script. By setting this option to yes, 
you can conveniently exclude an errorlog from being monitored while keeping its configuration 
values intact in case you need to later turn on the monitoring again. 

=item DBAPager 

Identifies the email address to which the script sends notifications for this particular 
SQL Server errorlog. This can be any email address -- not necessarily that of a pager. 
If a list of comma-separated email addresses is specified, the notification is sent to 
each address on the list.

=item IgnoreEntryOlderThan=300 

This tells the script to ignore any errorlog entries recorded more than 300 minutes ago. 
This essentially says that as far as monitoring errorlogs is concerned, you don't care about 
any entries if they are that old. The option is useful when there�s no previously saved status 
information to tell the script where to start scanning in the errorlog, such as when the script 
is run for the first time. 

=item RemoveSavedStatusOlderThan=2 

This tells the script to remove from the saved status file any exception entries that are older 
than two days. 

=item AlertConfigErr=yes 

This enables the script to monitor configuration exceptions. If this is set to no, the script 
ignores configuration exceptions.

=item ConfigErrAlertInterval=50 

This instructs the script to send an alert on a configuration exception only when the previous 
alert for a configuration exception was sent more than 50 minutes ago. 

=item ConfigErrQuietTime=23-7 

This specifies that between 23:00 and 07:00, the script should suppress any alert caused by a 
configuration exception.

=item ExcludeSQLErrors=1608,17832,17824 

This tells the script to ignore the errors with these error numbers regardless of their severity levels.

=item IncludeSQLSeverities=17,18,19,20,21,22,23,24,25 

This instructs the script to alert only on the errors whose severity levels are on the list.

=item OnPattern options

These options are distinguished from one another by postfixing each with a sequence number. 
The script monitorErrorlogs.pl doesn't care what these sequence numbers are as long as they're unique. 
Furthermore, you can specify as many of these OnPattern options as you want. 
An OnPattern option has two parts -- a Perl regular expression and a list of comma-separated email 
addresses enclosed in a pair of square brackets. Any errorlog entry matching the pattern causes an alert 
to be sent to each of the email addresses listed immediately after the regular expression. 
If an errorlog entry matches more than one OnPattern regular expression, an alert goes to all 
the email addresses associated with the matched patterns. If multiple errorlog entries match an 
OnPattern regular expression, only the last one is included in the alert. 

=back

=head2 The Structure of the Script

The script first reads the configurations from the file into a data structure referenced by I<$configRef>, 
and then it validates with the function I<validateConfig()> that the key configuration options are 
properly specified.

If the status file exists, the script reads the previously saved errorlog monitoring status from the 
status file into the data structure I<$statusRef>. This happens with the SQLDBA::Utility function 
I<dbaReadSavedRef()> in the following code fragment from the main body of the script:

 # read from the status file
 my $statusRef = (-T $configRef->{CONTROL}->{STATUSFILE})
               ? dbaReadSavedRef($configRef->{CONTROL}->{STATUSFILE}) : {};

After both the configuration data structure and the status data structure are merged under a 
single reference I<$ref>, the script calls the function I<initializeStatus()> to initialize the 
status data structure for each exception category under each enabled SQL Server instance and removes 
status entries that are older than the threshold specified with the option I<RemoveSavedStatusOlderThan> 
in the configuration file.

Next, the function I<scanErrorlogs()> loops through all the errorlogs listed in the configuration 
file to scan for the specified exceptions and update the data structure I<$ref->{Status}> 
accordingly along the way. The function I<scanErrorlogs()> is where the bulk of the work happens.

When all the errorlogs have been scanned, the script now has the updated status data structure with 
the information on the exceptions found in the errorlogs. The script then calls the function 
I<alertErrorlogs()> to examine the status data structure to do the following:

=over

=item 1.

Decide whether any alerts should be sent

=item 2.

Actually send the alerts, if any 

=item 3.

Update the status data structure to record the status of sending the alerts

=back

Finally, the script saves the updated status data structure back to the status file by calling the 
SQLDBA::Utility function I<dbaSaveRef()>, overwriting any content already in the file. The status 
file is now ready to be read when the script runs the next time.

=head2 Scheduling

I typically schedule to run this script once every five minutes. If you have a lot of SQL Server instances
to monitor, you may need to perform some experiments before deciding on a proper interval. In general,
you want the interval to be long enough so that the script has the time to finish checking all the 
errorlogs. At the same time, you want the interval to be short enough so that you can catch any
severe errors in time.

I found the Windows 2000 task scheduler to be a good scheduler to run this script.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


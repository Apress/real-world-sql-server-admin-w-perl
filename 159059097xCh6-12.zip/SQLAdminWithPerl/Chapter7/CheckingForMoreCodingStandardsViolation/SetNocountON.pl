# This is not a complete Perl script.
# This code fragment checks a stored procedure script for missing
# SET NOCOUNT ON at the beginning of the script.
#
# You should plug this code fragment into the script reviewSP.pl

# Standard: SET NOCOUNT ON at the beginning of a proc
foreach my $batch (@{$sqlRef->{code}}) {
   if ($batch =~ /CREATE\s+PROC(EDURE)?\s+([^\s]+)/i) {
      my $proc = $2;
      if ($batch !~ /CREATE\s+PROC(EDURE)?\s+[^\s]+
                       (.+)?
                       AS\s+
                       (.+)
                       SET\s+NOCOUNT\s+ON/isx) {  # if not found at all
         push @{$reviewRef->{comments}}, 
              "NOCOUNT not set at the beginning of $proc";
      }
      else {   # if found, check what comes before it
         my $code = $3;
         if ($code =~ /(?<![\w\@\#\$]) # if any of these comes before, gripe
                           ( SELECT\s+(?!\@) |
                             INSERT\s        |
                             DELETE\s        |
                             UPDATE\s  
                           )
                      /ix) {
            push @{$reviewRef->{comments}}, 
                 "NOCOUNT not set at the beginning of $proc";
         }
      }
   }
}

# This is not a complete Perl script.
# This code fragment checks a stored procedure script for not explicitly
# setting ANSI_NULLS and QUOTED_IDENTIFIER to ON.
#
# You should plug this code fragment into the script reviewSP.pl

# Standard: Create SP with ANSI_NULLS and QUOTED_IDENTIFIER set ON
my $ansi_nulls = 'off';            # default to off
my $quoted_identifier = 'off';     # default to off
foreach my $batch (@{$sqlRef->{code}}) {
   if ($batch =~ /SET\s+ANSI\_NULLS\s+ON/i) {
      $ansi_nulls = 'on';          # set to on
   }
   if ($batch =~ /SET\s+QUOTED\_IDENTIFIER\s+ON/i) {
      $quoted_identifier = 'on';   # set to on
   }
   
   if ($batch =~ /(?<![\w\@\#\$])  # it's a CREATE PRC batch
                      CREATE\s+PROC(EDURE)?\s+([^\s]+)
                 /ix) {
      my $proc = $2;
      if ($ansi_nulls ne 'on') {    # ansi_nulls shouldn't be off by now
            push @{$reviewRef->{comments}}, 
               "ANSI_NULLS not set before $proc";
      }
      if ($quoted_identifier ne 'on') {  # quoted_id shouldn't be off by now
            push @{$reviewRef->{comments}}, 
               "QUOTED_IDENTIFIER not set before $proc";
      }
   }
}

set showplan_text on
go
set statistics profile on
go
    SELECT 'SELECT', authors.au_id, authors.au_lname, 
        SUM(titles.price * sales.qty) 
    FROM authors INNER JOIN titleauthor 
        ON authors.au_id = titleauthor.au_id INNER JOIN titles
        ON titleauthor.title_id = titles.title_id INNER JOIN sales
        ON titles.title_id = sales.title_id inner join stores
        on sales.stor_id = stores.stor_id
    WHERE authors.au_id LIKE '8%'
      and stores.stor_name like 'Eric the%
abc 
'
    GROUP BY authors.au_id, authors.au_lname

set showplan_text off
go
sp_help sales
sp_help stores

select * from stores

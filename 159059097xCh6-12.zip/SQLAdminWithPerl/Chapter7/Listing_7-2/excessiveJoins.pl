use strict;

my $joinNum = 8;
# define a new line separator
$/ = "\n Execution Tree\n";
while (<>) {  # get a new query plan
   s{$/}{};             # remove the line separator
   s/^\s*//; s/\s*$//;  # remove leading or trailing spaces
   s/^\s*\-+\s*\n//;    # remove the line of hyphens

   my @joins = /\n[\s\-\|]*?([\s\w]+?\s*\([\s\w]+?\s+join)/ig;
   if (scalar @joins > $joinNum) {  # number of join operators
      print "$_\n\n";
   }
}


__END__

=head1 NAME

excessiveJoins - Fining excessive joins in a query plan file

=head1 SYNOPSIS

   cmd>perl filterQueryPlans.pl <Query Plan file>

=head1 DESCRIPTION

One of commonly cited poor query design practices is the use of excessive joins. If you have 
obtained query plans for a workload, it's useful to find all the joins that are considered 
excessive, and then you can focus your attention on these joins to check whether they cause
any performance problem. 

This script scans query plans in a file, and find all the joins that include 6 or more tables. The
threshold of 6 way joins is set at the beginning of the script and can be set to a different value.

You can obtain query plans using SQL Profiler, setting statistics profile on, or setting 
showplan_text on. The I<excessiveJoins.pl> script works with query plans regardless how you obtain them.

The script counts the cardinality of a join by counting the number of logical join operators used 
in the join. The following logical join operators are documented in the SQL Server 2000 Books Online:

=over

=item *

Inner join

=item *

Left outer join

=item *

Left semi join

=item *

Left anti semi join

=item *

Right outer join

=item *

Right semi join

=item *

Right anti semi join

=back

The following are some examples of the join operators, taken from actual query plans:

 1. Nested Loops(Inner Join)
 2. |--Hash Match(Inner Join, HASH:([b].[Name])=([p].[Name]), RESIDUAL: ...
 3. |    |         |--Nested Loops(Inner Join, OUTER REFERENCES:([g].[Name]))
 4. |--Nested Loops(Left Semi Join, DEFINE:([Expr1004] = [PROBE VALUE]))
 5. |--Merge Join(Inner Join, MANY-TO-MANY MERGE:([a].[Code])=([b].[Code]), ...

The regular expression that matches the join operators is in the following statement:

 my @joins = /\n[\s\-\|]*?([\s\w]+?\s*\([\s\w]+?\s+join)/ig;

It uses the /g modifier to get all the matched strings into the array @joins. Then, 
it is a matter of counting the number of elements in the array.

Note that not all 6-way joins are bad. But they are good candidates for performance analysis. Once they 
are identified, you need to evaluate each join on a case by case basis.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

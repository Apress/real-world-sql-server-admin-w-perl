# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use Win32::OLE;

my %opts;
getopts('S:d:t:', \%opts);
my ($server, $db, $threshold) = ($opts{S}, $opts{d}, $opts{t});
(defined $server and defined $db and defined $threshold) or printUsage();

Main: {
   my $cn = Win32::OLE->new('ADODB.Connection') or 
      die "***Err: unable to create the ADODB.Connection object.\n";
   $cn->{ConnectionTimeout} = 2;
   $cn->Open("Driver={SQL Server};Server=$server;Trusted_Connection=yes");

   my $sql = qq/SELECT SPID, RowNumber, EventClass, TextData 
                  FROM $db..TraceData
                 WHERE EventClass in (12,13,68)
               ORDER BY SPID, RowNumber/;
   my $rs = $cn->Execute($sql);

   my $planRef;
   if ($rs) {
      while ( !$rs->{EOF} ) {
         $planRef = findBadJoins($rs, $planRef, $threshold);
         $rs->MoveNext();
      }
   }
   else {
      print '***Err: ' . Win32::OLE->LastError() . "\n";
   }
   $cn->Close;
} # Main

sub findExcessiveJoins {
   my($rs, $planRef, $threshold) = @_;
   
   $planRef->{spid} = $rs->Fields('SPID')->value unless $planRef->{spid};
   if ($rs->Fields('EventClass')->value == 13) {  # BatchStarting
      $planRef->{BatchStart} = $rs->Fields('TextData')->value;
      $planRef->{BatchStart} =~ s/\s*$//;
      $planRef->{BatchStart} =~ s/^\s*//;
   }
   if ($rs->Fields('EventClass')->value == 68) {  # Execution Plan
      my $plan = $rs->Fields('TextData')->value;
      if (hasExcessiveJoins($plan, $threshold)) {
         $plan =~ s/\s*$//;
         $planRef->{Plan} .= $plan;
      }
   }
   if ($rs->Fields('EventClass')->value == 12) {  # BatchCompleted
      $planRef->{BatchComplete} = $rs->Fields('TextData')->value;
      $planRef->{BatchComplete} =~ s/\s*$//;
      $planRef->{BatchComplete} =~ s/^\s*//;
      if ($planRef->{spid} == $rs->Fields('SPID')->value) {
         if ($planRef->{BatchStart} eq $planRef->{BatchComplete}) {
            if (defined $planRef->{Plan}) {
               print "\nTSQL: \n$planRef->{BatchStart}";
               $planRef->{Plan} =~ s/\n/\n\t/g;
               print "\n\n\t", $planRef->{Plan};
            }
            undef $planRef;
         }
         else {
            print "***Err: the SQL statement for BatchStart didn't match";
            print " that for BatchComplete. This is not expected.\n";
         }
      }
      else {
         print "***Err: it has crossed the spid boundary. ";
         print "This is not expected.\n";
      }
   }
   return $planRef;
} # findExcessiveJoins

sub hasExcessiveJoins {
   my ($plan, $threshod) = @_;

   my @joins = $plan =~ m{ \-\-([\s\w]+?\s*\([\s\w]+?\s+join) }igx;
   if (scalar @joins > $threshold) {  # number of joins > the threshold
      return 1;
   }
   else {
      return 0;
   }
} # hasExcessiveJoins

sub printUsage {
    print << '--Usage--';
Usage:    
   cmd>perl queriesWithExcessiveJoins.pl -S <SQL server or instance> 
                                         -d <database name>
                                         -t <join threshold>
--Usage--
exit;
} # printUsage


__END__

=head1 NAME

queriesWithExcessiveJoins - Finding T-SQL queries with excessive joins

=head1 SYNOPSIS

   cmd>perl queriesWithExcessiveJoins.pl -S <SQL server or instance> 
                                         -d <database name>
                                         -t <join threshold>

=head1 USAGE EXAMPLE

Assume that you have saved the trace data in the table I<TraceData> in the pubs database on 
the server NYSQL01\APOLLO. Run the script as follows to find and print out the queries with 
six-way or more complex joins:

 cmd>perl queriesWithExcessiveJoins.pl -S NYSQL01\APOLLO -d pubs -t 6

=head1 DESCRIPTION

This script analyzes the query plans and finds the queries with excessive joins. A join is considered
excessive if it involves too many tables. How many tables is considered excessive? There is no straight
answer. The script expects the threshold on the command line with the option -t.

The difference between this script and the script in Listing 7-2 is that the latter finds excessive
joins, whereas this script finds the actual queries with excessive joins.

This script relies on analyzing the execution plans captured with SQL Profiler to tell whether a join 
is excessive (has too many tables). It correlates an execution plan with its original SQL statement 
by tracing both the event class I<SQL:BatchStarting> and the event class I<SQL:BatchCompleted>, 
in addition to tracing the I<Execution Plan> event class. The event classes I<SQL:BatchStarting>
and I<SQL:BatchCompleted> capture the same batch of SQL queries at different points in time. 
The former captures the queries at the beginning of the batch, and the latter captures 
the queries when the batch has completed. For a given connection, the execution plans captured 
by the event class I<Execution Plan> will appear chronologically between I<SQL:BatchStarting>
and I<SQL:BatchCompleted>. This fact allows the script to relate execution plans to 
their SQL statements.

Unlike in Listing 7-2 where the Perl script needs to split the query plans saved in a text file into 
individual plans -- one for each SQL statement -- this script retrieves individual plans and 
their associated SQL statements from the database table where the SQL Profiler trace data 
is saved. It retrieves the query plans with this SQL statement:

 SELECT SPID, RowNumber, EventClass, TextData 
   FROM $db..TraceData
  WHERE EventClass in (12,13,68)
 ORDER BY SPID, RowNumber

Through Perl's variable interpolation, the $db variable in this query will be replaced with the 
database name, specified on the command line with the -d parameter, before the query is sent to 
SQL Server. Also note that in this SQL query, the event number 13 is for the event class 
I<SQL:BatchStarting>, the event number 12 is for the event class I<SQL:BatchCompleted>, and 
the event number 68 is for the event class I<Performance:Execution Plan>. The result of the SQL 
query guarantees that for each SQL batch, the trace data for the event class I<SQL:BatchStarting>
will comes first, followed by one or more execution plans, and then the trace 
data for the event class I<SQL:BatchCompleted>.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use SQLDBA::Utility qw( dbaSetDiff );

# get command line parameters
my %opts;
getopts('S:d:q:', \%opts);
my ($server, $db, $query_plan) = ($opts{S}, $opts{d}, $opts{q});
printUsage() unless (-e $query_plan);

Main: {
   # get the indexes and operators from query plans
   my $idxRef = getIdxOperators($query_plan);

   # print a summary of the indexes/operators
   printIdxOperators($db, $idxRef);

   # get and print unused indexes
   if ($server && $db) {
      my $unIdxRef = getUnusedIdx($server, $db, $idxRef);
      printUnusedIdx($db, $unIdxRef);
   }
} # Main

sub getIdxOperators {
    my ($query_plan) = shift or 
      die "***Err: getIdxOperators() expects a file name.\n";
    my $idxRef;
    
    open(LOG, "$query_plan") 
       or die "***Err: could not open $query_plan.";
    while(<LOG>) {
      # e.g. look for Index Scan(OBJECT:([pubs].[dbo].[jobs].[jobs_ix])
      if (m{^[\s | \d | \|]*\|\-\-
            ( Clustered\s+Index\s+Seek | Clustered\s+Index\s+Scan |
              Clustered\s+Index\s+Delete | Clustered\s+Index\s+Update |
              Clustered\s+Index\s+Insert | Index\s+Seek | Index\s+Scan |
              Index\s+Delete | Index\s+Update | Index\s+Insert | Table\s+Scan
            )
              \(OBJECT\:\( 
                (   
                  (\[([^\]] | \]\])+\])
                   \.\[([^\]] | \]\])+\]
                   \.\[([^\]] | \]\])+\]
                   (\.\[([^\]] | \]\])+\])?
                )
              \)
            }ix) {

        # count the index and operator usage
        my ($ops, $obj, $db) = ($1, $2, $3);
        if ($db =~ /tempdb/i) {
           $obj =~ s/\_{4,}\w+//; # remove the appendix of a temp table
        }
        $idxRef->{$db}->{$obj}->{count}++;
        $idxRef->{$db}->{$obj}->{ops}->{$ops}->{count}++;
      }
    }
    close(LOG);
     
    return $idxRef;
} # getIdxOperators

sub printIdxOperators {
    my ($database, $idxRef) = @_;

    # exclusde system tables from summary
    my @systables = qw( sysobjects syscolumns syscomments sysindexes 
                        sysdepends sysreferences sysfiles sysfilegroups 
                        syspermissions sysprotects sysindexkeys 
                        sysforeignkeys sysallocations sysusers systypes);

    print "\nIndex summary for database $database...\n\n";
    printf " %-75s %-5s %-7s %-25s\n", 'Index/Table', 'Total', 
                     'Op Cnt', 'Operator';
    printf " %-75s %-5s %-7s %-25s\n", '-' x 75, '-' x 5, 
                     '-' x 7, '-' x 25;
    foreach my $db (keys %{$idxRef}) {
      next if defined $db and $db ne "[$database]";

      foreach my $idx (sort keys %{$idxRef->{$db}}) {
         # skip system table indexes
         next if grep {$idx =~ /\[dbo\]\.\[$_\]/i} @systables;
            
         printf " %-75s %s\n", $idx, $idxRef->{$db}->{$idx}->{count}; 
         foreach my $op (sort keys %{$idxRef->{$db}->{$idx}->{ops}}) {
            printf " %-75s %-5s %-7s %-25s\n", ' ' x 75, ' ' x 5, 
                 $idxRef->{$db}->{$idx}->{ops}->{$op}->{count}, $op;
         }
       }
    }
} # printIdxOperators

sub getUnusedIdx {
    my ($server, $database, $idxRef) = @_;
    unless (defined $server and defined $database) {
      die "***Err: getUnusedIdx() expects both server and database.\n";
    }
    
    # get indexes from the database
    my $sql = "use $database " . 
              q/SET NOCOUNT ON 
                SELECT quotename(db_name()) + '.' +
                       quotename(user_name(o.uid)) + '.' +
                       quotename(o.name) + '.' + quotename(i.name)
                  FROM sysindexes i, sysobjects o
                 WHERE i.indid > 0 AND i.indid < 255 AND (i.status & 64) = 0
                   AND o.id = i.id
                   AND OBJECTPROPERTY(o.id, 'IsMSShipped') <> 1/;

    my @result = `osql -S$server -E -Q\"$sql\" -n -h-1 -l2`;
    my @allIndexes;
    foreach (@result) {
        s/\s+$//; s/^\s+//;
        next if /^\s*$/;
        push @allIndexes, $_;
    }
    
    # get the list of indexes used in the query plan     
    my @usedIndexes = ();
    foreach my $db (keys %$idxRef) {
         next unless ($db eq $database) or ($db =~ /\[$database\]/);
         @usedIndexes = keys %{$idxRef->{$db}};
    }

    # compare the two lists to get a list of unused indexes
    dbaSetDiff(\@allIndexes, \@usedIndexes);    
} # getUnusedIdx

sub printUnusedIdx {
    my ($database, $unusedIdxRef) = @_;

    if (scalar @$unusedIdxRef) {
         print "\nUnused indexes in database $database...\n\n";
         foreach (sort @$unusedIdxRef) {
            print " $_\n";
         }
    }
    else {
         print "\nNo unused indexes in database $database.\n";
    }
} # printUnusedIdx

sub printUsage {
    print << '--Usage--';
Usage:    
   cmd>perl IndexSummary.pl [ -S <SQL server or instance> ]
                            [ -d <database name> ]
                              -q <Query plan log>
--Usage--
   exit;
} # printUsage


__END__

=head1 NAME

indexSummary - Summarizing the index usage

=head1 SYNOPSIS

   cmd>perl IndexSummary.pl [ -S <SQL server or instance> ]
                            [ -d <database name> ]
                              -q <Query plan log>

=head1 USAGE EXAMPLE

 cmd>perl indexSummary.pl  -S SQL01 -d pubs  -q QueryPlan.log

In this example, the script I<IndexSummary.pl> scans the query plans saved in the text file 
I<QueryPlan.log> for the indexes used in the pubs database on the server SQL01.

The following is a sample output of the indexSummary.pl:

Index summary for database pubs...
                           
  Index/Tabe            Total   Cnt     Operator                 
  --------------------- ------- ------- -----------------------
  authors               3
                                3       Table Scan               
  authors.PK_auidind    9
                                1       Clustered Index Scan     
                                6       Clustered Index Seek     
                                1       Clustered Index Update   
                                1       Clustered Index Delete   
  authors.aunmind       5
                                1       Index Seek               
                                4       Index Scan               
  publishers.PK_pub     3
                                3       Clustered Index Seek     
  roysched              2
                                2       Table Scan               
  sales.titleidind      4
                                3       Index Seek               
                                1       Index Scan               
  titles.PK_idind       13
                                7       Clustered Index Scan     
                                4       Clustered Index Seek     
                                2       Clustered Index Update   
 
 Unused indexes in database pubs...
 
  employee.PK_emp_id
  jobs.PK__jobs__22AA2996
  pub_info.UPKCL_pubinfo
  roysched.titleidind
  stores.UPK_storeid
  titleauthor.UPKCL_taind 
  titles.titleind

Among other things, this index summary tells you that the I<authors> table is table scanned 
three times, the clustered index I<authors.PK_auidind> is used nine times, and the nonclustered 
index I<authors.aunmind> is used five times. In addition, out of the five times the 
I<authors.aunmind> index is used, the script counts Index Seek once and Index Scan four times. 
More than that, toward the end, the report also highlights the indexes that are not used with 
respect to the captured execution plans of the workload. For instance, the index 
I<employee.PK_emp_id> is not used by the workload. 

=head1 DESCRIPTION

This script gives you an overview of how the indexes in a database is used by summarizing how 
the index operators use indexes in query plan. Three observations are central to this
script. The first observation is that a query plan consists of a series of operators such as 
Index Seek, Bookmark Lookup, and Table Scan. 

The second observation is that an index is used by one of these operators in query plans: 

=over

=item *

Clustered Index Seek

=item *

Clustered Index Scan

=item *

Clustered Index Delete

=item *

Clustered Index Update 

=item *

Clustered Index Insert

=item *

Index Seek

=item *

Index Scan

=item *

Index Delete

=item *

Index Update

=item *

Index Insert 

=back

The third observation is that each operator identifies an index in a query plan with a 
consistent four-part name, fully qualifying the index with the database name, 
the owner name, and the table name. For instance, the query plan operator Index 
Seek may specify I<OBJECT: ([pubs].[dbo].[authors].[authors_idx1])> as its argument, 
where [authors_idx1] is the index.

The script consists of four major functions. The function I<getIdxOperators()> extracts indexes 
and their operators from the query plan and stores the information in a hash structure referenced 
by $idxRef; the function I<printIdxOperators()> prints a summary of the indexes in terms of how often 
each is used, and by what query plan operator, using the information captured in the hash structure $idxRef. 
To produce a list of indexes that aren�t used, the function I<getUnusedIdx()> retrieves the complete 
list of indexes from the database and compares it with the list of indexes obtained from the 
query plans. Finally and logically, I<printUnusedIdx()> prints the indexes unused in the database. 

The heart of the script is the regular expression in the I<getIdxOperators()> function:

 m{^[\s | \d | \|]*\|\-\-
      ( Clustered\s+Index\s+Seek | Clustered\s+Index\s+Scan |
        Clustered\s+Index\s+Delete | Clustered\s+Index\s+Update |
        Clustered\s+Index\s+Insert | Index\s+Seek | Index\s+Scan |
        Index\s+Delete | Index\s+Update | Index\s+Insert | Table\s+Scan
        )       
        \(OBJECT\:\( 
          (   
            ( \[ ([^\]] | \]\])+ \] )      # database name
              \.\[ ([^\]] | \]\])+ \]      # owner
              \.\[ ([^\]] | \]\])+ \]      # object
            ( \.\[ ([^\]] | \]\])+ \] )?   # index
          )
        \)
 }ix

If you already have a database workload in the form of a T-SQL script, 
you can obtain its query plans in one of three ways. Recall that you can set 
SHOWPLAN_TEXT on to cause SQL Server to return the estimated 
execution plans for the workload queries. Alternatively, you can 
set STATISTICS PROFILE before executing the queries in the workload, which 
will capture the actual execution plans. In addition, you can use SQL Profiler 
to trace the Execution Plan event class. The script doesn't care how you obtain the 
query plans; it works with execution plans produced with any of these three alternatives.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


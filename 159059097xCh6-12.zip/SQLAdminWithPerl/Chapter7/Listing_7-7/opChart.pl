# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use Data::Dumper;

# get command line parameters
my %opts;
getopts('tq:', \%opts);
my ($include_tempdb, $query_plan) = ($opts{t}, $opts{q});
printUsage() unless (-e $query_plan);

# exclusde system tables from summary
my @systables = qw( sysprocesses sysjobservers sysxlogins
                    sysobjects syscolumns syscomments 
                    sysindexes sysdepends sysreferences 
                    sysfiles sysfilegroups syspermissions 
                    sysprotects sysindexkeys sysforeignkeys 
                    sysallocations sysusers systypes
                    sysservers sysdatabases sysjobhistory 
                    sysjobschedules sysjobsteps sysjobs
                    syslanguages syslockinfo sysmembers 
                    backupfile backupmediaset backupmediafamily
                    sysdbmaintplan_databases sysdbmaintplan_history );

my $objRef;
open(PLAN, "$query_plan") or 
   die "***Err: couldn't open file $query_plan.\n";
while(<PLAN>) {
   if (m{^[\s|\d|\|]*(?:\|\-\-)?
          (\w[\s\w]+\w) \s* \(OBJECT:\((.+?)\)
        }ix) {
      my ($op, $obj) = ($1, $2);
      # remove the trailing appendix of a temp table name
      $obj =~ s/\[(\#\w+?)\_{4,}\w+\]/\[$1\]/g;
      # remove as [...]
      $obj =~ s/\s+AS\s+\[.+\]$//;
      # add [tempdb].[dbo] prefix, if not present
      if ($obj =~ /^\[\#.+\]$/) {
         $obj = '[tempdb].[dbo].' . $obj;
      }
      # skip system tables
      next if grep {$obj =~ /^\[.+\]\.\[.+\]\.\[$_\]/i} @systables;
      
      # decide whether to skip tempdb objects
      unless ($include_tempdb) {
         next if $obj =~ /^\[.+\]\.\[.+\]\.\[\#.+\]/;
      }
      if ($obj =~ /^(\[.+\]\.\[.+\]\.\[.+\])\.(\[.+\])$/) {
         $objRef->{$1}->{$2}->{$op}++;
      }
      else {
         $objRef->{$obj}->{$op}++;
      }
   } 
}
close(PLAN);
print Data::Dumper->Dump([$objRef], ['objRef']);

sub printUsage {
    print << '--Usage--';
Usage:    
   cmd>perl opChart.pl [ -t ] -q <Query plan log>
--Usage--
   exit;
} # printUsage


__END__

=head1 NAME

opChart - Creating a chart of query operators

=head1 SYNOPSIS

 cmd>perl opChart.pl [ -t ] -q <Query plan log>

   -t tells the script to include the operators on temporary tables
   -q introduces the file that contains execution plans

=head1 USAGE EXAMPLE

Assume that the execution plans of a SQL workload are captured in the text file I<queryPlans.log>. Running 
the Perl script as follows produces a chart of the query plan operators:

 cmd>perl opChart.pl -q queryPlans.log

The following is a sample report from the script, printed out using the I<Dumper()> function from 
the Data::Dumper module.

 $objRef = {
       '[Trade].[dbo].[Client]' => {
                  'Table Scan'      => '9',
                  '[Client_Index1]' => { 'Index Seek' => '170' },
                  '[Client_Index2]' => { 'Index Seek' => '18' }
             },
       '[Trade].[dbo].[Portfolios]' => {
                 'Table Update' => '33',
                 'Table Scan'   => '667',
                 'Table Insert' => '10',
                 '[PKey]'       => { 'Index Seek' => '343' }
             },
       '[Trade].[dbo].[Account]' => {
                 'Table Delete' => '1',
                 'Table Update' => '2',
                 'Table Scan'   => '2',
                 'Table Insert' => '11'
                 '[Account_Index1]' => { 'Index Scan' => '104' },
                 '[Account_Index2]' => { 'Index Seek' => '114' },
                 '[Account_Index3]' => { 'Index Seek' => '139' },
                 '[Account_Index4]' => { 'Index Seek' => '284' },
             },
       '[Trade].[dbo].[ClientTrades]' => {
                 'Table Delete' => '8',
                 'Table Update' => '43',
                 'Table Insert' => '20',
                 '[tradeRef]'   => { 'Index Seek' => '9',
                                     'Index Scan' => '93'  },
                 '[PKey]' => { 'Index Seek' => '273' }
             },
       '[Trade].[dbo].[CDC]' => { 'Table Update' => '66',
                                  'Table Scan'   => '330' }
 };

For this given workload, the script output shows that the UPDATE statement is applied to 
the table I<[Trade].[dbo].[ClientTrades]> 43 times, and the DELETE and INSERT statements 
are applied eight and 20 times, respectively. Of the two indexes used by the workload, the 
index I<tradeRef> is used in Index Sseek nine times and in Index Sscan 93 times, and the index PKey 
s used 273 times exclusively to perform index seek. 

This chart helps you focus on the potential problem areas. For instance, if the table I<ClientTrades> 
is very large, you may want to investigate whether the scan on the index I<tradeRef>, which SQL 
Server performs 93 times in the workload, has any significant performance implication.

=head1 DESCRIPTION

With the execution plans of the critical transactions captured by SQL Profiler, you can 
proceed to use this script to summarize the access patterns in terms of how specific query 
plan operators -- such as 
Index Seek, Table Insert, Table Scan, and Clustered Index Seek -- are applied to the tables. 
In a complex SQL Server database environment or in an environment that's new to the DBA, 
such a summary can help the DBA quickly identify the trouble spots and focus attention 
on areas with high impact.

The script scans the execution plans to find the objects and the operators applied to them. 
The regular expression to capture an object and its operators is as follows:

   m{^[\s|\d|\|]*(?:\|\-\-)?
          (\w[\s\w]+\w) \s* \(OBJECT:\((.+?)\)
    }ix

Since in a query plan an object name is consistently formatted and is always preceded with the 
string I<OBEJCT:>, finding all the objects is easy. 

The script then checks whether the object is a system table. If yes, the script skips this object. 
The script also needs to decide whether to include the temprorary tables. Because sometimes knowing how 
temporary tables are used is useful, the script includes a -t option to include temporary tables in the 
query oprator chart.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


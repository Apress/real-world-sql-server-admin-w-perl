# See the embedded POD or the HTML documentation

use strict;
use Data::Dumper;
use SQLDBA::ParseSQL qw( dbaNormalizeSQL dbaSplitBatch );

Main: {
   my $dir = shift or die "***Err: $0 expects a directory name.";
   (-d $dir) or die "***Err: directory $dir does not exist.\n";

   # read the file names in the directory
   opendir(DIR, $dir) or die "could not open $dir.\n";
   my @fileNames = map { "$dir\\$_" } grep {!/^\.\.?/} readdir(DIR);
   closedir(DIR);
   
   my $counterRef;
   # now work on each file
   print "\nPerforming T-SQL stored procedure review ...\n";
   foreach my $sqlFile (sort @fileNames) {
      # read T-SQL script into a string
      my $sql;
      open(SQL, "$sqlFile") or die "***Err: couldn't open $sqlFile for read.";
      read(SQL, $sql, -s SQL);
      close(SQL);

      # replace comments, strings, and delimited identifiers
      # with unique string tokens
      my $sqlRef = dbaNormalizeSQL($sql, 1);
      next unless $sqlRef;
      
      # split the SQL code into batches by batch separator GO
      $sqlRef->{code} = dbaSplitBatch($sqlRef->{code});

      # review the batches
      my $reviewRef = reviewTSQL($sqlRef);

      # print the review for this T-SQL script file
      printReview($reviewRef, $sqlRef, $sqlFile);
      
      # update global counters
      $counterRef = updateGlobalCounters($reviewRef, $counterRef);
   }

   # print out the global counters
   printGlobalCounters($counterRef);
} # Main

####################
sub reviewTSQL {
   my ($sqlRef) = shift;
   my $reviewRef = { DynamicSQL => 0 }; # initialize dynamic SQL counter to 0
   
   # Standard: Use <db>
   foreach my $batch (@{$sqlRef->{code}}) {  # loop through all the batches
      next if $batch =~ /^\s*\-\-.+$/;       # skip comments only batch
      if ($batch !~ /^\s*use\s+\w+/is) {     # gripe if the next batch is not USE
         push @{$reviewRef->{comments}}, 'No explicit USE <DB>';
      }
      last;
   }
   
   # Standard: Use ANSI OUTER JOIN
   foreach my $batch (@{$sqlRef->{code}}) { # loop through all the bacthes
      if ($batch =~ /(=\*|\*=)/) {          # found an older outer join
         push @{$reviewRef->{comments}}, 
              'Old style non-ANSI outer join syntax used';
         last;
      }
   }

   # Standard: Do not use SELECT * to generate rowset
   foreach my $batch (@{$sqlRef->{code}}) { # loop through every batch to check
      while ($batch =~ /SELECT\s*\*/ig) {   # only interested in SELECT *
         if ($` !~ /EXISTS\s*\(\s*$/i) {    # not in an EXISTS ( )
            push @{$reviewRef->{comments}}, # found the bad SELECT *
                 'SELECT * to generate rowset';
            last;
         }
      }
   }
   
   # Standard: Use dynamic SQL sparingly
   foreach my $batch (@{$sqlRef->{code}}) { # loop through all the bacthes
      if ($batch =~ /(?<![\w\@\#\$])        # negative lookbehind
                     (  
                       EXEC(UTE)?\s+\( |    # three ways to run dynamic SQL
                       sp\_executesql\s+ | 
                       sp\_sqlexec\s+
                     )
                    /ix) {
         push @{$reviewRef->{comments}}, 'Dynamic SQL used';
         my $sql = $batch;
         ++$reviewRef->{DynamicSQL}                 # update dynamic SQL counter
              while $sql =~ / (?<![\w\@\#\$])       # the same pattern
                              (   EXEC(UTE)?\s+\( |
                                  sp\_executesql\s+ |
                                  sp\_sqlexec\s+
                                 )
                               /ixg;    # /g for as many times as it matches
      }
   }
   
   # Standard: Owner-qualify a stored procedure when executing it
   foreach my $batch (@{$sqlRef->{code}}) {  # loop through all the bacthes
      if ($batch =~ /(?<![\w\@\#\$])   # negative lookbehind
                     EXEC(UTE)?\s+     # EXEC(UTE)
                     (\@.+?=\s*)?      # optional return variable
                     ([^(\s]+)         # SP name
                    /ix) {
         my $proc = $3;
         unless ($proc =~ /([^.]+\.)?
                           [^.]+\.[^.]+   # unless it's owner qualified
                          /x) {
            push @{$reviewRef->{comments}}, 
                 "Stored proc $3 called without explicit owner";
            next;
         }
      }
   }
   
   # Standard: Create SP with ANSI_NULLS and QUOTED_IDENTIFIER set ON
   my $ansi_nulls = 'off';
   my $quoted_identifier = 'off';
   foreach my $batch (@{$sqlRef->{code}}) {  # loop through all the batches
      if ($batch =~ /SET\s+ANSI\_NULLS\s+ON/i) {
         $ansi_nulls = 'on';         # record the setting
      }
      if ($batch =~ /SET\s+QUOTED\_IDENTIFIER\s+ON/i) {
         $quoted_identifier = 'on';  # record the setting
      }
      
      if ($batch =~ /(?<![\w\@\#\$])
                       CREATE\s+PROC(EDURE)?\s+([^\s]+)
                    /ix) {
         my $proc = $2;
         if ($ansi_nulls ne 'on') {         # ansi_nulls shouldn't be off by now
               push @{$reviewRef->{comments}}, 
                  "ANSI_NULLS not set before $proc";
         }
         if ($quoted_identifier ne 'on') {  # quoted_id shouldn't be off by now
               push @{$reviewRef->{comments}}, 
                  "QUOTED_IDENTIFIER not set before $proc";
         }
      }
   }

   # Standard: Do not prefix the stored procedure name with sp_
   foreach my $batch (@{$sqlRef->{code}}) {
      if ($batch =~ /CREATE\s+PROC(EDURE)?\s+(\w+\.sp\_|sp\_)/i) {
         push @{$reviewRef->{comments}}, 
              'Stored proc name prefixed with sp_';
         last;
      }
   }
   
   # Standard: SET NOCOUNT ON at the beginning of a proc
   foreach my $batch (@{$sqlRef->{code}}) {
      if ($batch =~ /CREATE\s+PROC(EDURE)?\s+([^\s]+)/i) { # only check CREATE PROC batch
         my $proc = $2;
         if ($batch !~ /CREATE\s+PROC(EDURE)?\s+[^\s]+
                       (.+)?
                       AS\s+
                       (.+)
                       SET\s+NOCOUNT\s+ON/isx) {  # if not found at all
            push @{$reviewRef->{comments}}, 
                 "NOCOUNT not set at the beginning of $proc";
         }
         else {       # if found, check what comes before
            my $code = $3;
            if ($code =~ /(?<![\w\@\#\$])      # if any of these is found, gripe
                           ( SELECT\s+(?!\@) |
                             INSERT\s  |
                             DELETE\s  |
                             UPDATE\s  
                           )
                        /ix) {
               push @{$reviewRef->{comments}}, 
                    "NOCOUNT not set at the beginning of $proc";
            }
         }
      }
   }
   
   # Standard: Do not interleave DDL and DML
   foreach my $batch (@{$sqlRef->{code}}) {
      if ($batch =~ /(?<![\w\@\#\$])    # only interested in CREATE PRC batch
                     CREATE\s+PROC(EDURE)?\s+([^\s]+)
                    /ix) {
         my $proc = $2;
         while ($batch =~ /(?<![\w\@\#\$])    # found a DDL
                         (  CREATE\s+TABLE |
                            ALTER\s+TABLE |
                            CREATE\s+INDEX |
                            DROP\s+TABLE |
                            DROP\s+INDEX |
                            UPDATE\s+STATISTICS )
                       /ixg) {
            my $pre = $`;     # string before the DDL
            my $post = $';    # string after the DDL
            if (($pre =~ /(?<![\w\@\#\$])       # found a DML in the before
                           ( SELECT\s+(?!\@) |
                             INSERT\s  |
                             DELETE\s  |
                             UPDATE\s )
                        /ix) and
                ($post =~ /(?<![\w\@\#\$])      # found a DML in the after
                            ( SELECT\s+(?!\@) | 
                              INSERT\s | 
                              DELETE\s | 
                              UPDATE\s )
                          /ix)) {
                  push @{$reviewRef->{comments}}, 
                       "DDL interleaved with DML in $proc";
            }
         }
      }
   }
   
   # Standard: Create one stored procedure per file
   my $procFile = 0;
   foreach my $batch (@{$sqlRef->{code}}) {
      if ($batch =~ /(?<![\w\@\#\$])
                     CREATE\s+PROC(EDURE)?
                    /ix and $procFile++) {    # $procFile will be 1 the second time
         push @{$reviewRef->{comments}}, 
              "Multiple stored proc created in this file";
         last;
      }
   }
   
   return $reviewRef;
} # reviewTSQL

####################
sub printReview {
   my ($reviewRef, $sqlRef, $sqlFile) = @_;

   print "\nScript: $sqlFile\n";
   my $i = 0;
   my %seen;
   foreach my $commentWithToken (@{$reviewRef->{comments}}) {
      my $comment = restoreIdentifier($commentWithToken, $sqlRef);
      print "\t ", ++$i, ". $comment\n" unless $seen{$comment};
      $seen{$comment}++;
   }
} # printReview

##############################
sub updateGlobalCounters {
   my ($reviewRef, $counterRef) = @_;
   
   $counterRef->{DynamicSQL} += $reviewRef->{DynamicSQL};
   ++$counterRef->{FilesReviewed};

   return $counterRef;
} # updateGlobalCounters

#############################
sub printGlobalCounters {
   my $counterRef = shift;
   
   printf "\n%s\n", "Overall stats in all scripts:";
   printf "\t%-21s %s\n", "# of script files reviewed:", 
                                 $counterRef->{FilesReviewed};
   printf "\t%-21s %s\n", "# of Dynamic SQL:", $counterRef->{DynamicSQL};
} # printGlobalCounters

############################
sub restoreIdentifier {
   my ($comment, $sqlRef) = @_;

   foreach my $id (keys %{$sqlRef->{double_ids}}) {
      $comment =~ s/$id/\"$sqlRef->{double_ids}->{$id}\"/i;
   }
   foreach my $id (keys %{$sqlRef->{bracket_ids}}) {
      $comment =~ s/$id/\[$sqlRef->{bracket_ids}->{$id}\]/i;
   }
   
   return $comment;
} # restoreIdentifier


__END__

=head1 NAME

reviewSP - Checking stored procedures for violations of coding best practices

=head1 SYNOPSIS

   cmd>perl reviewSP.pl <Folder name> 

=head1 USAGE EXAMPLE

Assume that there are two T-SQL script files in a subdirectory named I<appSP> under the current 
directory. The following is an example of running the Perl script I<reviewSP.pl> and the output
it produces:

 cmd>perl reviewSP.pl .\appSP
 Performing T-SQL stored procedure review ...
 
 Script: .\appSP\Proc1and2.PRC
     1. No explicit USE <DB>
     2. SELECT * to generate rowset
     3. Dynamic SQL used
     4. Stored proc name prefixed with sp_
     5. NOCOUNT not set at the beginning of sp_proc1
     6. DDL interleaved with DML in sp_proc1
     7. Multiple stored proc created in this file
 
 Script: .\appSP\getAuthorInfo.SQL
     1. SELECT * to generate rowset
     2. Stored proc updateID called without explicit owner
 
 Overall stats in all scripts:
     # of script files reviewed: 2
     # of Dynamic SQL:     1

=head1 DESCRIPTION

=head2 Stored Procedure Coding Best Practices

The script I<reviewSP.pl> checks the T-SQL script files in a given directory for any vioation of the 
following T-SQL stored procedure cosing best practices:

=over

=item Explicitly identify the database at the beginning of each script file.

There should be a USE <database> statement at the beginning of a stored procedure script 
to identify in which database this stored procedure is created.

=item Use only ANSI outer join syntax.

Don't use the old style of outer joins that's either =* or *= in the WHERE clause. Instead, 
use LEFT OUTER JOIN or RIGHT OUTER JOIN in the FROM clause.

=item Don't use SELECT * to return a resultset that will be either inserted into another table or 
returned to the client.

Not explicitly specifying the columns can easily lead to a broken application 
when the table schema changes.

=item Owner-qualify a stored procedure when executing it.

This helps SQL Server resolve the procedure name and find a cached execution plan quickly, 
thus improving performance.

=item Don't prefix a user stored procedure name with sp_.

This prefix leads SQL Server to try to resolve the name with the special rules for 
the system procedures, resulting in wasted effort.

=item Don't interleave DDL and DML.

Mixing the DML statements (SELECT, DELETE, INSERT, and UPDATE) with the DDL statements 
(CREATE TABLE, ALTER TABLE, DROP TABLE, CREATE INDEX, and so on) forces the SQL Server 
query optimizer to recompile the stored procedure at runtime, thus degrading performance.

=item Create one stored procedure per file.

Storing multiple stored procedures in one script file makes code management a nightmare.

=item Use dynamic SQL sparingly.

Dynamic SQL queries in a production environment introduce a host of security and performance issues.

=back

=head2 Structure of the reviewSP.pl Script

This script is structured as follows to review the T-SQL scripts in a folder with respect to 
these best practices.

At the top level -- i.e. the code within the Main: { ... } block -- the script loops through 
each T-SQL script file in the directory identified on the command line. For each T-SQL file, 
the Perl script first applies the function I<dbaNormalizeSQL()> imported from the module 
SQLDBA::ParseSQL to replace the comments, the quoted strings, and the delimited identifiers 
in the T-SQL script with the unique token strings. This is necessary because you'll apply regular 
expressions to find T-SQL code patterns that aren't consistent with the best practices, and the 
T-SQL comments, the quoted strings, and the delimited identifiers may confuse the regular expressions. 

Consider the case where a pattern you're looking for happens to be inside a comment. For more 
information on I<dbaNormalizeSQL()>, see the section "Working with Commonly Used Perl Routines" in Chapter 3.

The next step is to split the T-SQL file into batches by the batch separator GO. You do this with the 
function I<dbaSplitBatch()>, which is also imported from the module SQLDBA::ParseSQL. 
Note that the individual batches that have been split are stored in an array to preserve the order of 
the batches. This is important because some best practices are concerned with the ordering of the batches. 
For instance, you typically want to see the USE <DB> statement at the beginning of a T-SQL script that 
defines a stored procedure.

The I<reviewTSQL()> function performs the actual check for the best practice violations. The function 
consists of a collection of code fragments, each checking a particular best practice standard. 
Let's look at an example: checking for the use of I<SELECT *>.

=head2 Checking SELECT *

Finding a poor use of I<SELECT *> requires slightly more effort than looking for the string 
SELECT * in a T-SQL script because it's perfectly fine to use it in an existence test such as 
EXISTS (SELECT * FROM myTable). 

The code fragment in the I<reviewSP.pl> script for checking this standard is as follows:

 # Standard: Do not use SELECT * to generate rowset
 foreach my $batch (@{$sqlRef->{code}}) {   # loop through every batch to check
   while ($batch =~ /SELECT\s*\*/ig) {     # only interested in SELECT *
      if ($` !~ /EXISTS\s*\(\s*$/i) {      # not in an EXISTS ( )
         push @{$reviewRef->{comments}},   # found the bad SELECT *
              'SELECT * to generate rowset';
         last;
      }
   }
 }

Note that I<$sqlRef->{code}> is a reference to an array of strings, each of which corresponds to a batch 
in the T-SQL script file currently being reviewed. To make sure that I<SELECT *> isn't used inside a 
T-SQL EXISTS test, the string that immediately precedes I<SELECT *> is checked as follows:

 $` !~ /EXISTS\s*\(\s*$/I
 
Recall that the predefined special variable $` captures the string immediately preceding what's matched 
by the most recently completed regular expression evaluation.

If a coding standard is violated, a comment string is pushed as a new element into the array referenced 
by I<$reviewRef->{comments}>. Upon completion, the script produces the final report by dumping out 
these comment strings.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut



# This little script accepts three parameters:
#       a file name, a start line number, and an end line number.
#
# The script scans the file and print the lines between the start line number
# and the end line number, inclusive.

# This script shows how you can write a Perl script to review any section of a 
# large file.

($file, $start, $end) = @ARGV;
open(FL, $file) or die "Err: could not open $file.\n";
while(<FL>) {
   next if $. < $start; 
   exit if $. > $end;
   print;
}
close(FL);

# See the POD at the end or the HTML documentation

use strict;

my $empty = 0;
my $plan = shift or die "***Err: $0 expects a file.";
open(PLAN, $plan) or die "***Err: could not open file $plan.";

while(<PLAN>) {
   s/\s*\n$/\n/;  # remove trailing spaces
   if (/^\s*Execution\s+Tree\s*$/i) {
      my $line = $_;
      if ($_ = <PLAN>, /^\s*\-+\s*$/) {   # a line pf -'s
         $line .= $_;                     # keep the header
         # skip the query plan if its root is Constant Scan
         next if ($_ = <PLAN>, /^\s*Constant\s+Scan\s*$/i);
      } 
      print $line;
   }
   # collapse multiple blank lines into one
   if (/^\s*$/) {
      next if ++$empty > 1;
   }
   else {
      $empty = 0;
   }
   print;  # otherwise, print as is
}
close(PLAN);


__END__

=head1 NAME

filterQueryPlans - Removing the noise in a query plan file

=head1 SYNOPSIS

   cmd>perl filterQueryPlans.pl <Query Plan file>

=head1 DESCRIPTION

When you track the query plans of a large T-SQL script file, the query plans can be long. However, 
a considerable amount of data in a query plan file are not useful. They add no value other than 
help hiding the real information. 

This script removes, or filters out, the following three useless items that take up a lot of space:

=over

=item *

Trailing white spaces,

=item *

An entire query execution plan consisting of a single entry (Constant Scan), which is 
largely irrelevant for most analysis, and

=item *

Multiple consecutive blank lines

=back

Depending on the analysis you want to perform on the query plan file, there may be other items that are
useless to your analysis, and therefore can be safely filtered out.

By filtering out these three items alone, you can often achieve considerable reduction in the file size. 
For instance, in one case I applied this script to a 50MB query plan file and reduced it to a file slightly
more than 4MB, which is quite manageable.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

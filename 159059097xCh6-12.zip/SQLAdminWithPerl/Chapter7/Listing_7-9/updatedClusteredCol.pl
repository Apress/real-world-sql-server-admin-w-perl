#See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use Win32::ODBC;
use SQLDBA::Utility qw( dbaInSet );
use Data::Dumper;

# get command line parameters
my %opts;
getopts('S:d:q:', \%opts);
my ($server, $db, $queryPlan) = ($opts{S}, $opts{d}, $opts{q});
printUsage() unless (defined $server and defined $db and defined $queryPlan);

Main: {
   my $colUpdateRef = getUpdateInfo($db, $queryPlan);
   my $clusteredColRef = getClusteredColumns($server, $db);
   my $colRef = findUpdatedClusteredCol($colUpdateRef, $clusteredColRef);
   print Data::Dumper->Dump([$colRef], ['updatedClusteredCol']);
} # Main

#########################
sub findUpdatedClusteredCol {
   my ($colUpdateRef, $clusteredColRef) = @_;
   die "***Err: keepClusteredCol() expects two references.\n"
         if !ref($colUpdateRef) || !ref($clusteredColRef);

   my $ref;
   foreach my $tb (keys %$colUpdateRef) {
      foreach my $col (keys %{$colUpdateRef->{$tb}}) {
         if (dbaInSet($col, $clusteredColRef->{$tb})) {
            $ref->{$tb}->{$col} = $colUpdateRef->{$tb}->{$col};
         }
      }
   }
   return $ref;
} # findUpdatedClusteredCol

#############################
sub getUpdateInfo {
   my ($db, $queryPlan) = @_; 
   die "***Err: getUpdateInfo() expects a database name and a file name.\n"
      if !defined $db || !defined $queryPlan;

   $db = '[' . $db if $db !~ /^\[/;
   $db = $db . ']' if $db !~ /^\]/;
   $db = quotemeta($db);
   my $updateRef;
   open(PLAN, "$queryPlan") or die "***Err: could not open $queryPlan.\n";
   while(<PLAN>) {
      s/\s*\n$/\n/;
      if (/^[\s\|\-]* ([\w\s]+\s+Update)      # Update operator
                      \(OBJECT:\((.+?)\),     # Table name in (.+?)
                      \s*SET:\((.+)\)\)       # Updated column(s) in (.+)
           \s*$/ix) {
         my ($op, $table, $columns) = ($1, $2, $3);
         $columns =~ s/DEFINE:.+$//;
         $columns =~ s/WHERE:.+$//;
         my @columns = map {/(.+)=/; $1;} split /,\s*/, $columns;
         foreach my $col (@columns) {
            $col =~ s/^\[.+?\]\.//;
            if ($table =~ /^(\[.+?\])\.(\[.+?\]\.\[.+?\])/) {
               my ($database, $tb) = ($1, $2);
               next if $database !~ /^$db$/i;
               $updateRef->{$tb}->{$col}->{$op}++;
            }
            else {
               print "***Err: $table is not properly formed.\n";
            }
         }
      }
   }
   close(PLAN);
   return $updateRef;
} #getUpdateInfo

##########################
sub getClusteredColumns {
   my ($server, $db) = @_;
   
   my $updateRef;
   my $connStr = "Driver={SQL Server};Server=$server;" .
                 "Database=$db;Trusted_Connection=yes";
   my $conn = new Win32::ODBC($connStr) or 
                  die "***Err: " . Win32::ODBC::Error();

   my $sql =<< "__SQL__";
    SELECT QUOTENAME(USER_NAME(OBJECTPROPERTY(id, 'OwnerId'))) + '.' +
           QUOTENAME(OBJECT_NAME(id)) as 'tb_name', 
           QUOTENAME(COL_NAME(id, colid)) as 'column_name'
      FROM sysindexkeys
     WHERE indid = 1
       AND OBJECTPROPERTY(id, 'IsUserTable') = 1
       AND OBJECTPROPERTY(id, 'TableHasClustIndex') = 1
   ORDER BY OBJECT_NAME(id), COL_NAME(id, colid)
__SQL__

   if (! $conn->Sql($sql) ) {
      while ($conn->FetchRow()) {
         my %data = $conn->DataHash();
         push @{$updateRef->{$data{'tb_name'}}}, $data{'column_name'};
      }
   }
   else {
      die Win32::ODBC::Error();
   }
   $conn->Close();
   return $updateRef;
} # getClusteredColumns

####################
sub printUsage {
    print << '--Usage--';
Usage:    
   cmd>perl updatedClusteredCol.pl -S <SQL Server instance>
                                   -d <database name>
                                   -q <Query plan log>
--Usage--
   exit;
} # printUsage


__END__

=head1 NAME

updatedClusteredCol - Finding updates on the clustered index keys

=head1 SYNOPSIS

   cmd>perl updatedClusteredCol.pl -S <SQL Server instance>
                                   -d <database name>
                                   -q <Query plan log>

=head1 USAGE EXAMPLE

Assume that you already have the query execution plans for a workload on 
the pubs database in the file I<queryPlans.log>, you can run the script as follows to produce 
a report highlighting the updated columns of the clustered indexes in the database:

 cmd>perl updatedClusteredCol.pl -S NYSQL01 -d pubs -q queryPlans.log
 
 $updatedClusteredCol = {
             '[dbo].[publishers]' => {
                       '[pub_id]' => { 'Clustered Index Update' => '54' }
                   },
             '[dbo].[authors]' => {
                     '[au_id]' => { 'Clustered Index Update' => '31' }
                   }
 };

The report shows that for the given workload, the I<pub_id> column in the publishers table is 
updated 54 times, and the I<au_id> column in the authors table is updated 31 times. 
Each of these two columns is part of the key of their respective clustered index. 

=head1 DESCRIPTION

It's nearly universally accepted that you should not update your clustered index key columns 
frequently. For a given application or a given database, how do you know you are not violating
this best practice?

More importantly, how do you find how often a column in a clustered index is updated? 
If you have a SQL workload script, you can parse the script to find all the UPDATE statements 
and check whether a clustered index column happens to be modified in their SET clauses. But 
there's an easier way. You can again exploit the query execution plans from SQL Profiler, 
taking advantage of its well-formatted output to simplify your search.

The solution is to find, from the execution plans of a workload, all the columns that have been 
updated. Then you count how many times the columns have been updated and compare them 
with the columns used in the clustered indexes (which you can find in the database). This gives 
you the number of updates applied to each column of every clustered index in the database.

The I<updatedClusteredCol.pl> script accepts three command-line arguments: 

=over

=item *

SQL Server name following -S

=item *

Database name after -d

=item *

Filename after -q

=back

The file, specified with -q, is expected to contain the query execution plans for the workload.

To find the updated columns, you need to look for these operators in an execution plan:

=over

=item *

Table Update

=item *

Index Update

=item *

Clustered Index Update

=back

Once you find an update operator, you'll find the columns in its SET clause. 
A typical update operator in an execution plan looks like the 
following:

 |--Clustered Index Update(OBJECT:([pubs].[dbo].[authors].[UPKCL_auidind]),
                       SET:([authors].[au_id]=RaiseIfNull([Expr04])), 
                       DEFINE:([Expr04]=Convert([@1])), 
                       WHERE:([authors].[au_id]=[@2]))


There could be multiple entries in the SET clause for updating multiple columns. 
The Perl code fragment to capture the updated columns is as follows:

 if (/^[\s\|\-]* ([\w\s]+\s+Update)    # Update operator
                 \(OBJECT:\((.+?)\),   # Table name in (.+?)
                 \s*SET:\((.+)\)\)     # Updated column(s) in (.+)
      \s*$/ix) {
    my ($op, $table, $columns) = ($1, $2, $3);
    $columns =~ s/DEFINE:.+$//;
    $columns =~ s/WHERE:.+$//;
    my @columns = map {/(.+)=/; $1;} split /,\s*/, $columns;

The regular expression in the test expression of the I<if> statement is at the heart of the function 
I<getUpdateInfo()>, which reads the execution plan and returns a reference to a hash record that has 
the number of updates for each updated column. The third pair of parentheses captures the names of 
the columns in the SET clause of an UPDATE statement. Note how the column names are singled out 
using a I<split()> followed by a I<map()>.

The I<getClusteredColumns()> function retrieves the columns of the clustered indexes for all the 
user tables in the database. The following SQL query retrieves the columns of the clustered indexes:

 SELECT QUOTENAME(USER_NAME(OBJECTPROPERTY(id, 'OwnerId'))) + '.' +
        QUOTENAME(OBJECT_NAME(id)) as 'tb_name', 
        QUOTENAME(COL_NAME(id, colid)) as 'column_name'
   FROM sysindexkeys
  WHERE indid = 1
    AND OBJECTPROPERTY(id, 'IsUserTable') = 1
    AND OBJECTPROPERTY(id, 'TableHasClustIndex') = 1
 ORDER BY OBJECT_NAME(id), COL_NAME(id, colid)


With the information on both the updated columns and the columns used in the clustered indexes, 
the script is ready to check whether a clustered index column is updated and how many times 
it's updated. The function I<findUpdatedClusteredCol()> accomplishes this. 

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


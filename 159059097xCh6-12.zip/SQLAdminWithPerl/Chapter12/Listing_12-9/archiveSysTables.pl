# See the embedded POD or the HTML documentation

use strict;

# Import the functions from the module SQLDBA::Utility
use SQLDBA::Utility qw( dbaRunQueryADO dbaReadINI dbaTime2str dbaStr2time );

my $configFile = shift or die "***Err: $0 expects an INI file.";
(-T $configFile) or die "***Err: $0 couldn't open $configFile.";

Main: {
   my $configRef = dbaReadINI($configFile);
   $configRef = validateConfig($configRef);

   # bulk copy out all the system tables
   bcpSysTables($configRef);
   # purge the old directories, if any
   purgeOldDir($configRef, 'SystemTables');
} # Main

#######################
sub bcpSysTables {
   my ($configRef) = @_;

   foreach my $server (sort keys %$configRef) {
      next if $server =~ /^CONTROL$/i;
      next if $configRef->{$server}->{DISABLED} =~ /^y/i;
      
      print "\n****\n";
      print "**** Bulk copy from $server\n";
      print "****\n\n";

      # get the complete list of the system table names
      my $tableRef = getSysTableNames($configRef, $server, 'SystemTables');

      my $dir;
      # create a directory with today's date string
      $dir = createDir($configRef, $server, 'SystemTables'); 
      if ($dir && -d $dir) {                 # directory created and exists
         # loop through each system table to export it
         foreach my $table (@$tableRef) {
            # construct the bulk copy statement using trsuted connection         
            my $bcpcmd = "bcp $table out $dir\\$table\.txt -c -S$server -T";
            print "\n-- $bcpcmd\n";  # debug print
            system($bcpcmd);         # execute bcp
         }
      }
   }    
} #bcpSysTables

#######################
sub validateConfig{
   my $configRef = shift or 
      die "***Err: validateConfig() expects a reference.";

   # The path to the archive folder root must be specified
   defined $configRef->{CONTROL}->{REPOSITORYFILESHARE} or 
     die "***Err: RepositoryFileShare is not specified.";
     
   # set default configurations
   $configRef->{CONTROL}->{KEEPDAYS} ||= 10;  # default to 10 days
   $configRef->{CONTROL}->{KEEPMINIMUMNUMBER} ||= 10;  # default to 10 days

   foreach my $server (keys %$configRef) {
     if ($server !~ /^CONTROL$/i) {
         $configRef->{$server}->{DISABLED} ||= 'no'; 
     }
   }
   $configRef;
}  # validateConfig

###########################
sub getSysTableNames {
   my ($ref, $server) = @_;
   my $excludedDB = '';

   # construct the excluded DB conditions for the WHERE clause
   my @excludedDBs = split(/\s*[,;]\s*/, $ref->{$server}->{EXCLUDEDB});
   for (@excludedDBs) { $_ = q/'/ . $_ . q/'/; }
   if (@excludedDBs) {
      $excludedDB = ' AND name NOT IN (' . join(/,/, @excludedDBs) . ')';
   }

   # construct the SQL script to get all the system tables
   my $sql =<<"TSQL__";
     SET NOCOUNT ON

     CREATE TABLE \#name (name varchar(255))

     DECLARE \@db sysname,
             \@name sysname,
             \@sql varchar(255)

     DECLARE name_cr CURSOR
     FOR SELECT RTRIM(name) 
           FROM master..sysdatabases
          WHERE name NOT IN ('model', 'tempdb', 'pubs', 'Northwind')
          $excludedDB
     FOR READ ONLY

     OPEN name_cr
     FETCH name_cr INTO \@db 
     WHILE \@\@FETCH_STATUS = 0
     BEGIN
       SELECT \@sql = 'select ''' + \@db + '..'' + name 
         FROM ' + \@db + '..sysobjects 
        WHERE type = ''S''
          AND id < 100 
          AND NOT name LIKE ''MS%'''

       INSERT \#name
       EXEC (\@sql)

       FETCH name_cr INTO \@db
     END

     CLOSE name_cr
     DEALLOCATE name_cr

     SELECT * FROM \#name
TSQL__

   my @list;
   # get the first resultset (there is only one result in this case)
   my $rs = dbaRunQueryADO($server, $sql, 3);
   foreach my $r (@{shift @$rs}) {  # loop through the first resultset
      push @list, $r->{name};       # add the system table name to the list
   }
   \@list;   # return the list of system table names
} #getSysTableNames

###################
sub createDir {
    my ($ref, $server, $source) = @_;
    
    my $serverDir = $server;
    $serverDir =~ s/\\/\_/g;

    my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) 
                        = localtime();
    my $timeStr = sprintf("%04d-%02d-%02d", $year+1900, ++$mon, $mday);

    my $dir =  $ref->{CONTROL}->{REPOSITORYFILESHARE} .  
                  "\\$serverDir\\$source\\$timeStr";
    # create the directory if not exists
    `md $dir` unless (-d $dir);
    
    if (-d $dir) {
        return $dir;
    } 
    else {
        return 0;
    }
} #createDir

######################
sub purgeOldDir {
   my ($configRef, $source) = @_;

   foreach my $server (sort keys %$configRef) {
      next if $server =~ /^CONTROL$/i;
      next if $configRef->{$server}->{DISABLED} =~ /^y/i;

      my $serverDir = $server;
      $serverDir =~ s/\\/\_/g;  # change backslash to underscore

      my $dir = $configRef->{CONTROL}->{REPOSITORYFILESHARE} . 
                  "\\$serverDir\\$source";
      opendir DIR, "$dir" or 
         do {print "***Err: could not open directory $dir"; return; };
      # only get the folders whose names are date strings
      my @dirs = grep {/\d\d\d\d-\d\d-\d\d/} readdir DIR;
      close(DIR);

      my %r_dirs;   # used to help sort by date/time
      map { $r_dirs{dbaStr2time($_)} = $_ } @dirs;

      my $i = scalar @dirs;  # get the total dir count
      foreach my $d (sort keys %r_dirs) {  # sort by date/time
         # exit if the dir count is at or below the min threshold
         last if ($i <= $configRef->{CONTROL}->{KEEPMINIMUMNUMBER});
         # remove the dir if it's older than the KeepDays threshold
         if ((time() - $d) > $configRef->{CONTROL}->{KEEPDAYS}*24*3600) {
             print "Removing $dir\\$r_dirs{$d}. It's more than ", 
                     "$configRef->{$server}->{KeepDays} days old.\n";
             # remove the directory
             `rd  \/s \/q $dir\\$r_dirs{$d}` if (-d "$dir\\$r_dirs{$d}");
             $i--;
         }
      }
   }
} #purgeOldDir

__END__

=head1 NAME

archiveSysTables - Archiving the SQL Server system tables

=head1 SYNOPSIS

  cmd>perl archiveSysTables.pl  <config file>

=head1 CONFIGURATION OPTIONS

The following is an example of the configuration options you can specify in the configuration file for 
the script:

 [CONTROL]
 RepositoryFileShare=\\DBASRV1\DBARepository
 KeepDays=20
 KeepMinimumNumber=20
 
 [SQL1]
 Disabled=no
 ExcludeDB=CDReports,CTSummary
 
 [SQL1\APOLLO]
 Disabled=no
 ExcludeDB=
 
 [SQL2]
 Disabled=yes
 ExcludeDB=

The options are described below: 

=over

=item RepositoryFileShare  

Specifies a folder to store the files of the exported system tables. The exported files aren't 
directly stored in this directory but in the various subfolders.

=item KeepDays 

Specifies the number of days in which the exported files must be kept.

=item KeepMinimumNumber 

Specifies the minimum number of copies of the exported system tables you want to keep. Note that 
the KeepDays option doesn't guarantee that you'll at least have that many copies. This option 
takes precedence over KeepDays.

=item ExcludeDB   

Specifies a comma-separated list of databases whose system tables you don't care to preserve.

=back


=head1 DESCRIPTION

The script I<archiveSysTables.pl> loops through the SQL Server instances specified in the configuration
file. For each instance, it constructs a bcp command for every system table in every database on that
instance, and then bulk copies the system tables to text files by executing these bcp commands.

Let's illustrate the script with an example. Save the configurations shown previously to the 
file I<config.txt> and run the script with I<config.txt> as follows:

 cmd>perl archiveSysTables.pl config.txt

You have instructed the script to perform the following:

=over

=item * 

Bulk copy out all the system tables from the SQL Server instances SQL1 and SQL1\APOLLO. 
Note that SQL2 is disabled in I<config.txt>.

=item *

For SQL1, the system tables will be bulk copied to the directory 
I<\\DBASRV1\DBARepository\SQL1\SystemTables\2003-04-12>, if you run the script on April 12, 2003. 
For SQL1\APOLLO, the script will bulk copy all the system tables to the directory 
I<\\DBASRV1\DBARepository\SQL1_APOLLO\SystemTables\2003-04-12>.

=item *

For each SQL Server instance listed in the configuration file, if the number of subdirectories 
under the I<SystemTables> directory is more than 20 -- the value of the I<KeepMinimumNumber> 
option in the Control section of the configuration file -- the script removes the older 
subdirectories to keep the number at 20.

=back

In summary, all the system tables are exported to their respective subdirectories under 
the directory specified with the option I<RepositiryFileShare>. In the I<RepositoryFileShare> 
directory, there's a subdirectory for each SQL Server instance listed in the configuration 
file. Under the directory that bears the name of the instance, there's a I<SystemTables> 
directory whose subdirectories are all named with date strings. The intension is to run the 
script I<archiveSysTables.pl> once a day. Each time it runs, the current date string is assigned 
to a new subdirectory under the I<SystemTables> directory.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

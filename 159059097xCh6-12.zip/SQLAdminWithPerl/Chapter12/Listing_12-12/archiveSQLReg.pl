# See the embedded POD or the HTML documentation

use strict;

# import the functions from the moduel SQLDBA:Utility
use SQLDBA::Utility qw( dbaReadINI dbaTime2str dbaStr2time );
use Data::Dumper;

my $configFile = shift or die "***Err: $0 expects an INI file.";
(-T $configFile) or die "***Err: $0 couldn't open $configFile.";

Main: {
   my $configRef = dbaReadINI($configFile);
   $configRef = validateConfig($configRef);

   # export the SQL Server registry entries
   exportSQLReg($configRef);
   # purge the old directories, if any
   purgeOldDir($configRef, 'RegistryEntries');
} # Main

#######################
sub exportSQLReg {
   my ($configRef) = @_;

   foreach my $server (sort keys %$configRef) {
      next if $server =~ /^CONTROL$/i;
      next if $configRef->{$server}->{DISABLED} =~ /^y/i;
      
      print "\n****\n";
      print "**** Export SQL registry entries for $server\n";
      print "****\n\n";

      my ($dir, $instance, $regPath, $outPath, $regdmp);
      $dir = createDir($configRef, $server, 'RegistryEntries');

      # check it's a named instance or the default instance
      if ($server =~ /^([^\\]+)(\\(.+))?$/i) {
         ($server, $instance) = ($1, $3);
      }

      if ($dir && -d $dir) {                 # directory created and exists
         # 1. Export the entries under HKLM\Software\Microsoft
         #   1.a If it's the default instance, export entries in \MSSQLServer
         #   1.b If it's a named instancem export entries in 
         #                             \Microsoft SQL Server\<InstanceName>
         $outPath = "$dir\\SoftwareEntries.log";
         if ($instance) {  # a named instance
            $regPath = "HKEY_LOCAL_MACHINE\\Software\\Microsoft\\" .
                        "Microsoft SQL Server\\$instance";
         }
         else {            # the default instance
            $regPath = "HKEY_LOCAL_MACHINE\\Software\\Microsoft\\MSSQLServer";
         }
         # construct the regdmp.exe command line        
         $regdmp = "regdmp -m \\\\$server -o 2048 \"$regPath\" > $outPath";
         print "\n-- $regdmp\n";  # debug print
         system($regdmp);         # execute regdmp.exe

         # 2. Export the entries under HKLM\System\CurrentControlSet\Services
         #   2.a For default instance, export entries in \MSSQLServer and 
         #                                               \SQLServerAgent
         #   2.b For a named instancem, export entries in \MSSQL$<Instance>
         #                                                \SQLAgent$<Instance>
         $outPath = "$dir\\SystemEntries.log";
         my ($mssqlPath, $sqlAgentPath);
         if ($instance) {  # a named instance
            $mssqlPath = "HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\" .
                        "Services\\MSSQL\$$instance";
            $sqlAgentPath = "HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\" .
                        "Services\\SQLAgent\$$instance";
         }
         else {            # the default instance
            $mssqlPath = "HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\" .
                        "Services\\MSSQLServer";
            $sqlAgentPath = "HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\" .
                        "Services\\SQLServerAgent";
         }
         # construct the regdmp.exe command line for MSSQL service
         $regdmp = "regdmp -m \\\\$server -o 2048 \"$mssqlPath\" > $outPath";
         print "\n-- $regdmp\n";  # debug print
         system($regdmp);         # execute regdmp.exe

         # construct the regdmp.exe command line for SQLAgent service
         $regdmp = "regdmp -m \\\\$server -o 2048 \"$sqlAgentPath\" >> $outPath";
         print "\n-- $regdmp\n";  # debug print
         system($regdmp);         # execute regdmp.exe
      }
   }    
} #exportSQLReg

#######################
sub validateConfig{
   my $configRef = shift or 
      die "***Err: validateConfig() expects a reference.";

   # The path to the archive folder root must be specified
   defined $configRef->{CONTROL}->{REPOSITORYFILESHARE} or 
     die "***Err: RepositoryFileShare is not specified.";
     
   # set default configurations
   $configRef->{CONTROL}->{KEEPDAYS} ||= 10;  # default to 10 days
   $configRef->{CONTROL}->{KEEPMINIMUMNUMBER} ||= 10;  # default to 10 days

   foreach my $server (keys %$configRef) {
     if ($server !~ /^CONTROL$/i) {
         $configRef->{$server}->{DISABLED} ||= 'no'; 
     }
   }
   $configRef;
}  # validateConfig

###################
sub createDir {
    my ($ref, $server, $source) = @_;
    
    my $serverDir = $server;
    $serverDir =~ s/\\/\_/g;

    my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime();
    my $timeStr = sprintf("%04d-%02d-%02d", $year+1900, ++$mon, $mday);

    my $dir =  $ref->{CONTROL}->{REPOSITORYFILESHARE} .    # concatenate
                  "\\$serverDir\\$source\\$timeStr";
    # create the directory if not exists
    `md $dir` unless (-d $dir);
    
    if (-d $dir) {
        return $dir;
    } 
    else {
        return 0;
    }
} #createDir

######################
sub purgeOldDir {
   my ($configRef, $source) = @_;

   foreach my $server (sort keys %$configRef) {
      next if $server =~ /^CONTROL$/i;
      next if $configRef->{$server}->{DISABLED} =~ /^y/i;

      my $serverDir = $server;
      $serverDir =~ s/\\/\_/g;  # change backslash to underscore

      my $dir = $configRef->{CONTROL}->{REPOSITORYFILESHARE} . 
                  "\\$serverDir\\$source";
      opendir DIR, "$dir" or 
         do {print "***Err: could not open directory $dir"; return; };
      # only get the folders whose names are date strings
      my @dirs = grep {/\d\d\d\d-\d\d-\d\d/} readdir DIR;
      close(DIR);

      my %r_dirs;   # used to help sort by date/time
      map { $r_dirs{dbaStr2time($_)} = $_ } @dirs;

      my $i = scalar @dirs;  # get the total dir count
      foreach my $d (sort keys %r_dirs) {  # sort by date/time
         # exit if the dir count is at or below the min threshold
         last if ($i <= $configRef->{CONTROL}->{KEEPMINIMUMNUMBER});
         # remove the dir if it's older than the KeepDays threshold
         if ((time() - $d) > $configRef->{CONTROL}->{KEEPDAYS}*24*3600) {
             print "Removing $dir\\$r_dirs{$d}. It's more than ", 
                     "$configRef->{$server}->{KeepDays} days old.\n";
             # remove the directory
             `rd  \/s \/q $dir\\$r_dirs{$d}` if (-d "$dir\\$r_dirs{$d}");
             $i--;
         }
      }
   }
} #purgeOldDir

__END__

=head1 NAME

archiveSQLReg - Archiving the SQL Server registry entries

=head1 SYNOPSIS

  cmd>perl archiveSQLReg.pl  <config file>

=head1 CONFIGURATION OPTIONS

The following is an example of the configuration options you can specify in the configuration file for 
the script:

 [CONTROL]
 RepositoryFileShare=\\DBASRV1\DBARepository
 KeepDays=20
 KeepMinimumNumber=20
 
 [SQL1]
 Disabled=no
 ExcludeDB=CDReports,CTSummary
 
 [SQL1\APOLLO]
 Disabled=no
 ExcludeDB=
 
 [SQL2]
 Disabled=yes
 ExcludeDB=

The options are described below: 

=over

=item RepositoryFileShare  

Specifies a folder to store the files of the exported system tables. The exported files aren't 
directly stored in this directory but in the various subfolders.

=item KeepDays 

Specifies the number of days in which the exported files must be kept.

=item KeepMinimumNumber 

Specifies the minimum number of copies of the exported system tables you want to keep. Note that 
the KeepDays option doesn't guarantee that you'll at least have that many copies. This option 
takes precedence over KeepDays.

=item ExcludeDB   

Specifies a comma-separated list of databases whose system tables you don't care to preserve.

=back


=head1 DESCRIPTION

The script I<archiveSQLReg.pl> is similar to the script I<archiveSysTables.pl> except that the former
archives the registry entries of the SQL Server instances listed in the configuration file. The script 
uses the Windows NT/2000 resource kit utility I<regdmp.exe> to export the registry entries to text
files. 

The bulk of the script I<archiveSQLReg.pl> is to construct the correct command line for 
I<regdmp.exe> for the SQL Server registry entries, and manages the exported files according to
the specification of the configuration file.

More specifically, for each SQL Server instance, the script <archiveSQLReg.pl> needs to prepare
the correct registry paths.

For the default SQL Server instance, the script exports all the entries in the following three 
registry keys and their sub-keys under I<HKEY_LOCAL_MACHINE>: 

=over

=item *

Software\Microsoft\MSSQLServer

=item *

System\CurrentControlSet\Services\MSSQLServer

=item *

System\CurrentControlSet\Services\SQLServerAgent

=back

For a named instance, the script exports all the entries in the three I<HKEY_LOCAL_MACHINE> registry 
keys and their sub-keys: 

=over

=item *

Software\Microsoft\MSSQL$<InstanceName>

=item *

System\CurrentControlSet\Services\MSSQL$<InstanceName>

=item *

System\CurrentControlSet\Services\SQLServer$<InstanceName>

=back

The script I<archiveSQLReg.pl> purges the exported files to contain their total size
in exactly the same way the script I<archiveSysTables.pl> does.

The scripts I<archiveSysTables.pl> and I<archiveSQLReg.pl> together enable you to preserve 
a history of comprehensive system information for the SQL Server installations in 
your environment.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

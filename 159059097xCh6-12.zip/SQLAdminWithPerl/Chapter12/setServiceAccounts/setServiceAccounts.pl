use strict;
use Getopt::Std;
use SQLDBA::Utility qw( dbaReadINI );
use Win32::Service;
use Win32::Lanman;

my %opts;
getopts('c:u:p:', \%opts);   # get the command line arguments

my $file = $opts{c} or die "***Err: $0 expects a config file name.";
defined $opts{u} or die "***Err: $0 expects a user account.";

my $configRef = dbaReadINI($file);      # read the INI file for server names
foreach my $server (keys %$configRef) { # loop through the servers
   my %services;

   print "Server: $server\n";
   Win32::Service::GetServices($server,\%services);  # get service names
   foreach my $service (keys %services) {
      if ($service =~ /^(MSSQLServer     |   # filter for MSSQL services
                         MSSQL\$\w+      |
                         SQLServerAgent  |
                         SQLAgent\$\w+)$
                      /ix) {
         print "\tService: $service. User: $opts{u}, password: *****\n";
         if(!Win32::Lanman::ChangeServiceConfig("\\\\$server", undef, 
                                                $service,
                                                { account  => $opts{u},
                                                  password => $opts{p} })
           ) {
            my $error = Win32::Lanman::GetLastError();
            print "***Err: ", Win32::FormatMessage($error);
         }
      }
   }
}

# See the embedded POD or the HTML documentation

use strict;
use SQLDBA::Utility qw( dbaReadINI );       # import the function
use Win32::TieRegistry (Delimiter => '/');

# get the config file name from the command line
my $configFile = shift or 
   die "***Err: $0 expects a config file.";
# read the config file
my $configRef = dbaReadINI($configFile);

my %checked;   # used to determine whether a server has been checked
# loop throuhg all the servers
foreach my $server (keys %$configRef) { # loop through the servers
   next if $server =~ /^CONTROL$/i;     # skip the CONTROL section
   $server =~ /^\s*(.+?)(\\(.+))?\s*$/; # separate server from instance
   $server = $1;
   next if exists $checked{$server};    # skip if checked already
   
   print "Server: $server\n";
   $checked{$server} = 1;       # record the server name in the hash
   my $rKey = "//$server/LMachine/Software/Microsoft/Microsoft SQL Server/";
   my $sqlKey = $Registry->{$rKey};
   
   # now loop through each instance of this server
   foreach my $instance (split /\0/, $sqlKey->{'/InstalledInstances'}) {
      my $pKey;
      if ($instance !~ /^\s*MSSQLServer\s*$/) {    # named instance
         $pKey = $sqlKey->{$instance . '/MSSQLServer/Parameters/'};
      }
      else {                                       # default instance
         my $dKey = "//$server/LMachine/Software/Microsoft/MSSQLServer/";
         $dKey .= "MSSQLServer/Parameters/";
         $pKey = $Registry->{$dKey};
      }
      
      # now loop through the startup parameters
      foreach my $value (keys %{$pKey}) {  # now print the -e parameter
         my $val = $pKey->{$value};
         if ($val =~ s/^\s*\-e//) {
            print "\t$val\n";
         }
      }
   }
}   

__END__

=head1 NAME

findErrorlogs - Finding SQL Server errorlogs

=head1 SYNOPSIS

  cmd>perl findErrorlogs.pl <config file>
  

=head1 USAGE EXMAPLE

Assume that the file I<config.txt> includes the following SQL Server instances:

 [SQL1\APOLLO]
 ...
 [SQL2]
 ...
 [SQL2\PANTHEON]
 ...

Run the script I<findErrorlogs.pl> as follows to see the result it may produce:

 cmd>perl findErrorlogs.pl config.txt
 Server: SQL1
     D:\MSSQL$APOLLO\log\ERRORLOG
 Server: SQL2
     E:\MSSQL\log\ERRORLOG
     E:\MSSQL$PANTHEON\log\ERRORLOG

This finds the errorlogs for all the SQL Server instances installed on both SQL1 and SQL2. 
In this case, the script reported one errorlog for SQL1 and two errorlogs for SQL2.


=head1 DESCRIPTION

The script I<findErrorlogs.pl> relies on the following observations to find the SQL Server 
errorlogs:

=over

=item *

The location of the errorlog for a SQL Server instance is in one of the startup parameters.

=item *

For a named instance, you can find the startup parameters in the registry under the key 
I<HKLM\Software\Microsoft\Microsoft SQL Server\<InstanceName>>I<\MSSQLServer\Parameters>.

=item *

For the default instance, you can find the startup parameters in the registry under the key 
I<HKLM\Software\Microsoft\MSSQLServer\ MSSQLServer\Parameters>.

=item *

The errorlog location can be the value of any of the registry values under the I<Parameters> key.

=back

The script I<findErrorlogs.pl> reads the SQL Server names from an INI file expected on the 
command line, and for each server it finds all the SQL Server instances installed on that 
server. Depending on whether it's a named instance or the default instance, the script 
traverses to the correct registry key to read all the startup parameter values. 
The value that starts with -e is the location of the errorlog for the SQL Server instance. 

Note that the script obtains all the installed SQL Server instances by retrieving the registry value 
I<InstalledInstances> in the registry key I<HKEY_LOCAL_MACHINE/Software/Microsoft/Microsoft SQL Server>. 
The data in this registry value contains multiple strings, separated by null. Each of the strings 
is the name of an installed SQL Server instance with the default instance being represented by 
MSSQLServer. Note that the ASCII value of null is 0; thus the strings are split into a list of 
individual strings with \0.

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


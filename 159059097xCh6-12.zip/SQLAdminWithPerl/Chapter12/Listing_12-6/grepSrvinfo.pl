# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use SQLDBA::Utility qw ( dbaReadINI );  # import the function

Main: {
   my %opts;
   getopts('c:r:', \%opts); # get command line arguments

   # check and normalize command line arguments
   my $argsRef = checkArgs(\%opts);

   # run srvinfo.exe with each server, scan the output for regex matches
   grepSrvinfo($argsRef);
} # Main

#####################
sub checkArgs {
   my $argsRef = shift or die "***Err: checkArgs() expects a reference.";

   # check the -c option for config file name.
   # -c is mandatory
   defined $argsRef->{c} or die "***Err: option -c must be specified.";

   # get the server name into @temp
   my @temp;
   my $configRef = dbaReadINI($argsRef->{c});
   foreach my $instance (keys %$configRef) {
      $instance =~ /^([^\\]+)(\\.+)?/;   
      push @temp, $1 unless grep /^$1$/i, @temp;
   }
   if (@temp) {
      $argsRef->{c} = \@temp;
   }
   else {
      die "***Err: didn't find any server in the config file.";
   }

   # check the -r option for a regular expression
   # -r is optional. If not specified, all srvinfo.exe output is printed
   # if defined, it must be a valid regular expression
   if (defined $argsRef->{r}) {
      # check if it's prefixed with qr. If not, add it.
      my $re = 'qr' . $argsRef->{r} unless $argsRef->{r} =~ /^\s*qr/;
      my $regex = eval $re;
      if ($@) {
          die "***Err: $argsRef->{r} is not a valid regex.";
      }
      $argsRef->{r} = $regex;  # convert to compiled regex
   }
   return $argsRef;
} # checkArgs

#########################
sub grepSrvinfo {
   my $argsRef = shift or die "***Err: grepSrvinfo() expects a reference.";

   foreach my $server (@{$argsRef->{c}}) { # loop through the servers
      print "***\n";
      print "*** srvinfo \\\\$server\n";
      print "***\n";
      
      # execute srvinfo \\<serverName> and grep the output
      my @rs = grep /$argsRef->{r}/, `srvinfo \\\\$server`;
      foreach (@rs) {
         print "\t$_";
      }
   }
} #grepSrvinfo

__END__

=head1 NAME

grepSrvinfo - Obtaining server information with srvinfo.exe

=head1 SYNOPSIS

  cmd>perl grepSrvinfo.pl  -c <config file> -r <regular expression>
  

=head1 USAGE EXMAPLES

Assume that the file I<config.txt> includes two servers, SQL1 and SQL2:

 [SQL1]
 ...
 [SQL2]
 ...

=head2 Finding the System Up Time

To find the system up time from all the servers in your environment, you can run the script 
I<grepSrvinfo.pl> as follows:

 cmd>perl grepSrvinfo.pl -c config.txt -r "/System\s+Up\s+time/i"
 ***
 *** srvinfo \\SQL1
 ***
      System Up Time: 0 Days, 1 Hr, 40 Min, 13 Sec
 
 ***
 *** srvinfo \\SQL2
 ***
      System Up Time: 10 Days, 4 Hr, 35 Min, 21 Sec

=head2 Finding the Status of All the SQL Server Services

To find the status of all the SQL Server services in your environment, run the script as 
follows on a single line:

 cmd>perl grepSrvinfo.pl -c config.txt 
                         -r "/\[\w+\]\s+(MSSQL|SQLAgent|SQLServerAgent)/i"
 ***
 *** srvinfo \\SQL1
 ***
       [Running]     MSSQL$APOLLO
       [Running]     SQLAgent$APOLLO
 
 ***
 *** srvinfo \\SQL2
 ***
       [Stopped]     MSSQL$PANTHEON
       [Stopped]     MSSQLServer
       [Stopped]     MSSQLServerADHelper
       [Stopped]     MSSQLServerOLAPService
       [Stopped]     SQLAgent$PANTHEON
       [Stopped]     SQLServerAgent

=head2 Finding the Domains of All the SQL Servers

To find the domains of all the SQL Servers in your environment, run the script as follows:

 cmd>perl grepSrvinfo.pl -c config.txt -r "/^\s*Domain:/i"
 ***
 *** srvinfo \\SQL1
 ***
      Domain: NYRES
 
 ***
 *** srvinfo \\SQL2
 ***
      Domain: NJRES


=head1 DESCRIPTION

The script I<grepSrvinfo.pl> loops through all the servers specified in a configuration file, and 
for each server, it runs the Windows NT/2000 resource kit utility I<srvinfo.exe>. In addition,
the script allows you to specify a regular expression on the command line with the -r option. The script 
uses filters for useful information from the output of I<srvinfo.exe> using this regular expression.

This script demonstrates how you can use Perl to wrap around an existing tool and therefore expand its
scope. The script lets the I<srvinfo.exe> utility do the hard work of retrieving the system 
information. All that left for the script to do is to pick and choose what you need from the 
output of I<srvinfo.exe>. 

=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut



# See the embedded POD or the HTML documentation

use strict;
use SQLDBA::Utility qw( dbaReadINI dbaRunQueryADO dbaRunOsql ); #Import the functions

my $configFile = shift or die "***Err: $0 expects a config file.";
my $configRef = dbaReadINI($configFile);

# loop through the SQL instances to get their memory configurations
foreach my $server (sort keys %$configRef) {
   next if $server =~ /^CONTROL$/i;
   
   # need to determine the SQL version first because some memory
   # configurations are version dependent
   my $ver = dbaRunOsql($server, 'select @@version', 
                                 {'-E' => undef, '-d' => 'master'});
   next unless $ver =~ /(7.00|8.00)/; # only applies to SQL7 or SQL2000

   print "\n***\n***Server: $server\n***\n";
   if ($ver =~ /(\d.00.\d+)/) { print " Version: $1\n"; }

   # get the total physical memory
   my $sql = "EXEC master..xp_msver \'PhysicalMemory\'";
   my $result = dbaRunQueryADO($server, $sql, 3); 
   my $rd = shift @{shift @$result};
   print " PhysicalMemory: $rd->{Internal_Value}\n";

   # get SQL instance memory configurations
   $sql = <<___ENDSQL;
      set nocount on
      EXEC sp_configure 'max server memory'
      EXEC sp_configure 'min server memory'
      if charindex('8.00.', \@\@version) > 0 # only applies to SQL2000
         EXEC sp_configure 'awe enabled'
___ENDSQL

   $result = dbaRunQueryADO($server, $sql, 3);
   printf " %-30s %-11s %-11s %-11s %-11s\n", 
          'name', 'minimum', 'maximum', 'config_value', 'run_value';
   printf " %-30s %-11s %-11s %-11s %-11s\n", 
          '-' x 30, '-' x 11, '-' x 11, '-' x 11, '-' x 11;
   foreach my $rset (@$result) {
      foreach my $r (@$rset) {
         printf " %-30s %-11s %-11s %-11s %-11s\n", 
                $r->{name}, $r->{minimum}, $r->{maximum}, 
                $r->{config_value}, $r->{run_value};
      }
   }

   # determine the system drive of the server so that we know
   # where to scan the boot.ini file on the server
   my $sysDrive = dbaRunOsql($server, 
                             "EXEC xp_cmdshell 'set systemdrive'", 
                             {'-E' => undef, '-d' => 'master'});
   if ($sysDrive =~ /\n\s*SystemDrive=(\w):/i) {
      $sysDrive = $1;

      # get boot.ini memory parameters /3gb and /pae
      $server =~ s/\\.+//;
      my $bootini = "\\\\$server\\$sysDrive\$\\boot.ini";
      print "\n boot.ini configurations:\n";
      open(BOOT, $bootini) or warn " ***Err: couldn't open $bootini.";
      while (<BOOT>) {
         print " $_" if /multi\(\d+\)disk/i;
      }
      close(BOOT);
   }
   else {
      warn "***Err: couldn't get the system drive via xp_cmshell.";
   }
}

__END__

=head1 NAME

findMemoryConfig - Finding the SQL Server memory configurations

=head1 SYNOPSIS

  cmd>perl findMemoryConfig.pl  <config file>
  

=head1 USAGE EXMAPLE

Assume that the file I<config.txt> includes two servers, SQL1 and SQL2:

 [SQL1]
 ...
 [SQL2]
 ...

The following is an example showing the result of running the I<findMemoryConfig.pl> script. 

 cmd>perl findmemoryConfig.pl config.txt
 ***
 ***Server: SQL1
 ***
  Version: 8.00.760
  PhysicalMemory: 4096 (MB)
  name                         minimum     maximum     config_value run_value  
  ---------------------------- ----------- ----------- ----------- -----------
  max server memory (MB)       4           2147483647  2147483647  2147483647 
  min server memory (MB)       0           2147483647  0           0          
  awe enabled                  0           1           0           0          
 
  boot.ini configurations:
  default=multi(0)disk(0)rdisk(0)partition(2)\WINNT
  multi(0)disk(0)rdisk(0)partition(2)\WINNT="Microsoft Windows 2000 ... /3GB /pae
 
 ***
 ***Server: SQL2
 ***
 
  Version: 8.00.679
  PhysicalMemory: 8192 (MB)
  name                         minimum     maximum     config_value run_value  
  ---------------------------- ----------- ----------- ----------- -----------
  max server memory (MB)       4           2147483647  5120        5120
  min server memory (MB)       0           2147483647  5120        5120        
  awe enabled                  0           1           0           0          
 
  boot.ini configurations:
  default=multi(0)disk(0)rdisk(0)partition(2)\WINNT
  multi(0)disk(0)rdisk(0)partition(2)\WINNT="Microsoft Windows 2000 ... /3GB /pae


=head1 DESCRIPTION

It's important that the DBA is up to date on the memory configurations in the SQL Server environments.
What server or SQL Server instance memory configuration parameters are of importance to the SQL Server 
DBA? The DBA should keep track of the following memory configurations:

=over

=item *

The total amount of physical memory.

=item *

The memory allocation in each SQL Server instance -- in other words, the values of the sp_configure 
options max server memory and min server memory.

=item *

The awe enabled option of sp_configure, which enables SQL Server 2000 Enterprise Edition or 
Developer Edition to support Windows 2000 Address Windowing Extensions (AWE).

=item *

The /3gb and /pae parameters in the boot.ini file. The /3gb parameter enables Windows 2000 Advanced 
Server and Windows 2000 Datacenter Server to support a 3GB virtual address space, and the /pae 
parameter enables them to use more than 4GB of physical memory.

=back

A report on these memory configuration parameters for all the SQL Server instances in your environment 
allows you to determine whether memory is properly configured for a given SQL Server instance, 
for all the SQL Server instances on a server, and for the SQL Server instances to take advantage 
of the physical memory beyond 4GB.

The script I<findMemoryConfig.pl> that loops through all the SQL Server instances listed 
in an INI file and produces a report that includes the information on these memory 
configuration parameters for each server on the list.

For each SQL Server instance, the script divides the work performed by the script into 
four tasks: 

=over

=item *

The script first determines the version of the SQL Server instance. Because some memory configuration 
parameters are applicable only to SQL Server 2000, it's important to ascertain the version first.

=item *

Then, the script retrieves the total amount of physical memory on the server through the T-SQL query 
I<xp_msver 'PhysicalMemory'>. The value is retrieved using the I<dbaRunQueryADO()> function imported 
from the module SQLDBA::Utility.

=item *

Next, the script retrieves the memory options of sp_configure. The two memory options are 
I<max server memory> and I<min server memory>. And for SQL Server 2000, the script retrieves the 
setting of awe enabled. Again, the script relies on the I<dbaRunQueryADO()> function to retrieve 
the option values from the SQL Server instance.

=item *

Finally, the script retrieves the content of the I<boot.ini> file from the server. The key step 
is to determine on which drive the boot.ini file resides. Note that this file always resides 
on the system drive. The script queries the SQL Server instance with I<xp_cmdshell 'set systemdrive'> 
and parses the result to identify the system drive.

=back



=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


use strict;
use SQLDBA::Utility qw( dbaReadINI dbaRunQueryADO dbaRunOsql );
use Getopt::Std;
use Data::Dumper;

my %opts;
getopts('c:d:', \%opts);
($opts{c} and $opts{d}) or printUsage();

my $sql = <<ENDSQL;
   SET NOCOUNT ON
   SELECT 'ServerName' = \@\@servername, 'DatabaseName' = d.name
     FROM master..sysdatabases d
    WHERE NOT EXISTS (SELECT * FROM msdb..backupset b
                       WHERE b.type = 'D'
                         AND datediff(day, b.backup_finish_date, getdate()) < $opts{d}
                         AND b.database_name = d.name)
      AND name NOT IN ('model', 'tempdb', 'pubs', 'Northwind', 'DBA')
ENDSQL

-f $opts{c} or die "***Err: $0 expects a configuration file.";
my $configRef = dbaReadINI($opts{c});

foreach my $server (sort keys %$configRef) {
   next if $server =~ /^CONTROL$/i;
   my $ver = dbaRunOsql($server, 'select @@version', {'-E' => 1});
   next unless $ver =~ /(7.00|8.00)/;

   print "\n\nServer: $server\n\n";
   if ($ver =~ /(\d.00.\d+)/) { print " Version: $1\n"; }

   my $result = dbaRunQueryADO($server, $sql);
   printf " %-36s %-36s\n", 'ServerName', 'DatabaseName';
   printf " %-36s %-36s\n", '-' x 36, '-' x 36;
   foreach my $rset (@$result) {
      foreach my $r (@$rset) {
         printf " %-36s %-36s\n", $r->{ServerName}, $r->{DatabaseName};
      }
   }
}

####################
sub printUsage {
   print <<__Usage__;
usage:
   cmd>perl $0 -c <Config file> -d <Cutoff days> 
__Usage__
   exit;
}

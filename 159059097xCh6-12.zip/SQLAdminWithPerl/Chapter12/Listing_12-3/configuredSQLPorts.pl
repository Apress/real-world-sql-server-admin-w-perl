# See the embedded POD or the HTML documentation

use strict;
use SQLDBA::Utility qw( dbaReadINI );       # import the function
use Win32::TieRegistry (Delimiter => '/');

# get the config file name
my $configFile = shift or die "***Err: $0 expects a file.";
# read the config file
my $configRef = dbaReadINI($configFile);

my $portRef;
foreach my $inst (sort keys %$configRef) {
   next if $inst =~ /^CONTROL$/i;      # skip the CONTROL section
   $inst =~ /^\s*(.+?)(\\(.+))?\s*$/;  # separate server from instance
   my ($server, $instance) = ($1, $3);
   $instance = $instance || 'MSSQLServer'; # it's the default instance

   my $MSRoot = "//$server/LMachine/Software/Microsoft/"; # MS root
   # get the root of the named instance
   my $namedRoot = $MSRoot . "Microsoft SQL Server/$instance";
   # get the root of the default instance
   my $defaultRoot = $MSRoot . "MSSQLServer/"; 

   my ($portPath, $verPath, $port, $version);
   # get verison of the instance
   if ($instance ne 'MSSQLServer') {   # named instance
      $verPath = $namedRoot . "/MSSQLServer/CurrentVersion/CurrentVersion";
   }
   else {                              # default instance
      $verPath = $defaultRoot . "MSSQLServer/CurrentVersion/CurrentVersion";
   }
   # get the version of the instance
   $version = $Registry->{$verPath};
   
   if ($version =~ /8\.00\./ ) {
      $portPath .= $namedRoot . "/MSSQLServer/SuperSocketNetLib/Tcp/TcpPort";
      $port = $Registry->{$portPath} or 
         warn "***Warning: couldn't read port for $portPath.";
   }
   else {
      $portPath = $defaultRoot . "MSSQLServer/ListenOn";
      
      $port = $Registry->{$portPath} 
         or warn "***Warning: couldn't read port for $portPath.";
      foreach (split(/\x0/, $port)) { # multiple ports are null separated
         if (/SSMSS/i) {
            $port = $_;
            last;
         }
      }
   }
   $portRef->{$server}->{$instance} = $port;
}

foreach my $srv (sort keys %$portRef) {
   print "Server: $srv\n";
   foreach my $instance (sort keys %{$portRef->{$srv}}) {
      print "\tInstance: $instance, Port: $portRef->{$srv}->{$instance}\n";
   }
}

__END__

=head1 NAME

configuredSQLPorts - Finding all the configured SQL Server TCP ports

=head1 SYNOPSIS

  cmd>perl configuredSQLPorts.pl <config file>
  

=head1 USAGE EXMAPLE

Assume that the file I<config.txt> has I<SQL1>, I<SQL1\APOLLO>, and I<SQL2\PANTHEON> listed in its section
headings. The following is an example of running the script I<configuredSQLPorts.pl>:

 cmd>perl configuredSQLPorts.pl config.txt
 Server: SQL1
     Instance: MSSQLServer, Port: 1433
     Instance: APOLLO, Port: 4752
 Server: SQL2
     Instance: PANTHEON, Port: 4009

=head1 DESCRIPTION

The script I<configuredSQLPorts.pl> loops through all the instances listed in the section headings of 
an INI file and, for each instance, retrieves the TCP port from the server by querying its registry 
entries with the module Win32::TieRegstry. 

For a named instance (for example, SQL1\APOLLO), you can find the TCP port under the registry 
value TcpPort in the registry key I<Microsoft SQL Server/APOLLO/MSSQLServer/SuperSocketNetLib/Tcp> 
in the Microsoft software root, which is I<HKEY_LOCAL_MACHINE/Software/Microsoft>.

For the default instance, the TCP port on which it listens is in the registry value 
I<MSSQLServer/MSSQLServer/ListenOn> in the same Microsoft software root.


=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


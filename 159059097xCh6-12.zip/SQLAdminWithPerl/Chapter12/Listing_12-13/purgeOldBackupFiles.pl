# See the embedded POD or the HTML documentation

use strict;
use SQLDBA::Utility qw( dbaReadINI );  # import the function
use Getopt::Std;
use Win32::OLE;

# Make these variables global for the function scriptDel() to use
my (%opts, $conn);

getopts('C:S:a:', \%opts); # get command-line arguments
unless (defined $opts{C} and defined $opts{S} and defined $opts{a}) {
   printUsage();
}

# establish the ADO connection to SQL instance to verify file format
$conn = Win32::OLE->new('ADODB.Connection') or 
   die "***Err: Win32::OLE->new() failed.";
$conn->{ConnectionTimeout} = 4;     # set connection timeout to 4 sec
$conn->Open("Provider=sqloledb;Server=$opts{S};Trusted_Connection=yes");
! Win32::OLE->LastError() or die Win32::OLE->LastError();

Main: {
   my $configRef = dbaReadINI($opts{C});
   
   # loop through all the servers
   foreach my $server (sort keys %$configRef) {
      $server =~ /^([^\\]+)\\/ and $server = $1;
      
      # get all the drive letters for the server
      my @srvinfo = `srvinfo \\\\$server`;
      my @drives;
      foreach my $line (@srvinfo) {
         if ($line =~ /\s*(\w)\$\s+\w+\s+\d+/) {
            push @drives, $1;
         }
      }
      unless (@drives) {
         warn "***Err: problem getting drive info from srvinfo.exe.";
      }

      # check each drive and all its subdirectories
      foreach my $dr (@drives) {
         my $dir = "\\\\$server\\$dr\$";
         print "Checking $dir ...\n";   
         
         # now recursively check each file in the directory 
         # and all its sub-directories
         walkDir($dir);
      }
   }   
} # Main

# close the ADO connection
$conn->Close();

#################
sub walkDir {
   my $dir = shift or die "***Err: walkDir() expects a reference.";

   opendir(DIR, $dir) or die "***Err: can't open $dir.";
   my @list = readdir(DIR);
   foreach my $dirfile (@list) {
      next if $dirfile =~ /^(\.\.|\.)$/;  # skip . and ..

      # now the real work of working with the file
      if (-f "$dir\\$dirfile") {
         # check the file and generate del command if the file
         # meets the criteria
         scriptDel("$dir\\$dirfile");
      }
      
      if (-d "$dir\\$dirfile") {
         # skip these before recursively call walkDir() again
         next if "$dir\\$dirfile" =~ /(c\$|e\$|d\$|g\$|f\$)/i;
         next if $dirfile =~ /system\s+volume\s+information/i;
         next if $dirfile =~ /documents and settings/i;
         next if $dirfile =~ /(recycler|sybase|oracle)/i;
         next if $dirfile =~ /(winnt|program files|platform sdk|binn)/i;

         print "\tChecking $dir\\$dirfile\n";
         walkDir("$dir\\$dirfile");
      }
   }
   close(DIR);
} # walkDir

#################
sub scriptDel {
   my $file = shift or die "***Err: scriptDel() expects a file.";
   my $size = 0;
   
   # if the file is older than the age threshold
   if (-M $file > $opts{a} ) { 
      # skip it if it has any of these file extension 
      return if /\.(mdf|ndf|ldf|exe|dll|htm|html|ini|gif|sql|bat)$/i;

      # construct the RESTORE FILELISTONLY statement
      my $sql = "RESTORE FILELISTONLY FROM disk=\'$file\'";
      if (my $rs = $conn->Execute($sql)) {     # if it returns a recordset
         while (!$rs->{EOF}) {
            # if LogicalName has a value, this is a backup file
            if ($rs->Fields('LogicalName')->{Value}) {
               # -b indicates that yon want to script the delete batch file
               # without actually performing any delete
               print "del \"$file\"\n";
               last;
            }
         } # while
      }  # Execute()
   } # -M
}  # scriptDel

####################
sub printUsage {
   print <<__Usage__;
usage:
   cmd>perl $0 -C <config file> -S <Server> -a <Age>
   
       -C accepts an INI file name
       -S accepts the name of the SQL Server which runs RESTORE FILELISTONLY
       -a sets the age threshold in days 
__Usage__
   exit;
}

__END__

=head1 NAME

purgeOldBackupFiles - Purging old SQL Server backup files

=head1 SYNOPSIS

   cmd>perl purgeOldBackupFiles.pl -C <config file> -S <Server> -a <Age>
   
       -C accepts a config file name
       -S accepts the name of the SQL Server which runs RESTORE FILELISTONLY
       -a sets the age threshold in days 

=head1 USAGE EXAMPLE

Assume that the I<config.txt> file includes two SQL Server instances, SQL1 and SQL2. The following
is a sample output of running the script I<purgeOldBackupFiles.pl>:

 cmd>perl purgeOldBackupFiles.pl -c config.txt -S SQL1\APOLLO -a 10

 Checking \\SQL1\C$ ...
 ...
 Checking \\SQL1\D$ ...
     Checking \\SQL1\D$\SQLData
     Checking \\SQL1\D$\SQLDBA
     Checking \\SQL1\D$\SQLDBA\logs
     Checking \\SQL1\D$\SQLDBA\scripts
     Checking \\SQL1\D$\SQLDumps

 del "\\SQL1\D$\SQLDumps\NuityDB_200304082100.BAK"
 del "\\SQL1\D$\SQLDumps\AuthorsDB_old.bkp"
     
     Checking \\SQL1\D$\SQLFTP
 Checking \\SQL1\E$ ...
 ...
 
 Checking \\SQL2\C$ ...
 ...
     Checking \\SQL2\D$\MSSQL
     Checking \\SQL2\D$\MSSQL\Backup
     Checking \\SQL2\D$\SQLDumps
 Checking \\SQL2\F$ ...

In this example, the script I<purgeOldBackupFiles.pl> scanned the drives and directories on 
both SQL1 and SQL2 for SQL Server backup files older than 10 days -- which was specified with the -a option. 
It found two such files on SQL1 and therefore constructed two Windows I<del> commands. 
Note that the output isn't in the proper batch file format because it includes the informational 
messages showing the directory paths that the script has scanned. If you remove all the lines 
that begin with the string I<Checking>, what you have left is a batch file that you can run to 
delete the old backup files.


=head1 DESCRIPTION

The script I<purgeOldBackupFiles.pl> implements the following strategy to find the old backup files that 
should be removed.

The strategy is to scan all the directories on each server (excluding some obvious directories such 
as the system directory) for the files that are older than the age threshold and then test each old 
file using the I<RESTORE FILELISTONLY> statement to determine whether it's a SQL Server backup file.

The script enumerates the drives on a server by parsing the result of I<srvinfo.exe>. The script obtains
the result of I<srvinfo.exe> with the backtick operator as follows:

    my @srvinfo = `srvinfo \\\\$server`;

This is obviously not the only way to get a list of drives for a server. But it is a convenient way.

The script then traverses recursively down the directory tree on each drive with the function I<walkDir()>, 
which is defined in the script. This function is similar to the I<find()> function exported from 
the module File::Find, which was discussed in Chapter 2, "Working with Commonly Used Perl Modules." 
The I<walkDir()> function takes a directory as its parameter. It relies on the two Perl built-in 
functions, I<opendir()> and I<readdir()>, to find the subdirectories and the files in the directories. 
The I<opendir()> function creates a handle to a directory, and the I<readdir()> function accepts the 
directory handle and returns all the entries in that directory. 

For each file, I<walkDir()> calls 
the function I<scriptDel()> to test the file and generate a I<del> command if the file meets 
the criteria. For each subdirectory, I<walkDir()> calls itself to recursively move down to the 
lower-level directories in the directory tree. 

Note that I<walkDir()> doesn't blindly traverses a directory tree. Before it calls itself on a 
subdirectory, it first checks whether the directory is considered unlikely to have any SQL 
Server backup files and therefore should be excluded from further examination. The function 
I<scriptDel()> then checks each file whether it's older than the age threshold specified on 
the command line with the option -a. A file is ignored if it's newer than the age threshold. 
The function further prunes its search by skipping any file with an extension such as I<exe>, 
I<dll>, I<mdf>, I<ldf> and I<bat>. The RESTORE FILELISTONLY statement for a file is then constructed as follows:

       my $sql = "RESTORE FILELISTONLY FROM disk=\'$file\'";

The script executes this statement on the SQL Server instance using ADO. The SQL Server instance 
is specified with the -S option on the command line. If the ADO Execute() method returns the expected 
resultset, the file is confirmed to be a SQL Server backup file, and the script prints a Windows 
I<del> command.



=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut

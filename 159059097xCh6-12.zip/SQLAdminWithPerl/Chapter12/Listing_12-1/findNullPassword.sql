set nocount on
go

select name from syslogins 
 where password is NULL
   and isntname = 0

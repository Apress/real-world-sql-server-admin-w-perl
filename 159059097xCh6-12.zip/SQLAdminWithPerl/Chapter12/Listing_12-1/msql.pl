# See the embedded POD or the HTML documentation

use strict;
use Getopt::Std;
use SQLDBA::Utility qw( dbaReadINI );  # import the function
use Data::Dumper;

my %opts;
# accept osql.exe arguments plus -C
getopts('C:U:P:S:H:d:l:t:h:s:w:a:L:c:D:q:Q:m:r:i:o:EeInpb', \%opts);
# store all the server instance names in $optRef->{S}
my $optRef = validateConfig(\%opts);

# run osql.exe on each server
foreach my $server (sort @{$optRef->{S}}) {
   print "Server: $server\n";
   my $optStr = ' ';
   foreach my $opt (keys %$optRef) {
      next if $opt eq 'S';
      $optStr .= '-' . $opt . $optRef->{$opt} . ' ';
   }
   my $osql = "osql -S$server $optStr 2>&1"; # direct STDERR to STDOUT

   # run osql and capture result in $rs
   my $rs = `$osql`;
   print $rs;
}

########################
sub validateConfig {
   my $optRef = shift or die "***Err: validateConfig() expects a reference.";
   if (!defined $optRef->{C} and !defined $optRef->{S}) {
      die "***Err: either -C or -S must be specified.";
   }
   # set the value of the options that don't accept arguments to undef
   # Getopt::Std assigns a numeric 1 to such an option. Since we concatenate
   # the option and its value to construct the osql command line, we can't
   # use the number 1.
   for my $opt ('E', 'e', 'I', 'n', 'p', 'b') {
      $optRef->{$opt} = undef if exists $optRef->{$opt};
   }
   if ($optRef->{S}) {
      $optRef->{S} = [ split /\s*,\s*/, $optRef->{S} ];
   }
   # move all the listed server instances to $optRef->{S}, and
   # remove $optRef->{C}
   if ($optRef->{C}) {
      my $configRef = dbaReadINI($optRef->{C});
      push @{$optRef->{S}}, keys %$configRef;
      delete $optRef->{C};
   }
   # for these options, we may need to put the double quotes back
   foreach my $opt ('q', 'Q', 'i') {
      if ($optRef->{$opt}) {
         $optRef->{$opt} =~ s/\"/\"\"/;
         $optRef->{$opt} = '"' . $optRef->{$opt} . '"';
      }
   }
   return $optRef;
} # validateConfig

__END__

=head1 NAME

msql - Multiple server osql

=head1 SYNOPSIS

  cmd>perl msql.pl <all options accepted by osql.exe plus the -C option and the modified -S option>
  
    -C  accepts a config file

=head1 USAGE EXMAPLES

For the following examples, assume that you have a I<config.txt> file listing all the SQL Server
instances in your environment:

 [SQL1\APOLLO]
 ...
 [SQL2]
 ...
 [SQL2\PANTHEON]
 ...

=head2 Finding a database in your environment

Place the following T-SQL in the file I<findDB.sql>:

 SET NOCOUNT ON
 
 SELECT name 
   FROM master..sysdatabases
  WHERE name = 'Orders'

and now run I<msql.pl> as follows to find the SQL Server instances with the database I<Orders>:

 cmd>perl msql.pl -C config.txt -i findDB.sql -E -n -h-1 -w1024
 Server: SQL1\APOLLO
  Orders                                                                                                                           
 
 Server: SQL2
 
 Server: SQL2\PANTHEON

This result shows that the I<Orders> database is found on the SQL Server instance SQL1\APOLLO.

=head2 Finding missing database backups

To identify all the non-trivial databases in your environment that haven't been backed up for 
more than five days, save the following query to the file I<findMissingBackups.sql>:

 SET NOCOUNT ON
 SELECT 'ServerName' = @@servername, 'DatabaseName' = d.name
   FROM master..sysdatabases d
  WHERE NOT EXISTS (
          SELECT * FROM msdb..backupset b
           WHERE b.type = 'D'   -- full database backup only
             AND DATEDIFF(day, b.backup_finish_date, GETDATE()) < 5  -- 5 days
             AND b.database_name = d.name)
    AND name NOT IN ('model', 'tempdb', 'pubs', 'Northwind', 'DBA')

And execute the SQL script with I<msql.pl> to produce the following output:

 cmd>perl msql.pl -C config.txt -ifindMissingBackups.sql -E -n -h-1 -w 2048
 Server: SQL1\APOLLO
  ServerName          DatabaseName  
  ------------------- --------------
  SQL1\APOLLO         distribution
  SQL1\APOLLO         master
  SQL1\APOLLO         msdb
 
 Server: SQL2
  ServerName          DatabaseName  
  ------------------- --------------
  SQL2                TradeDB
  SQL2                master

The databases I<distribution>, I<master>, and I<msdb> haven't been backed for five days 
on SQL\APOLLO. On SQL2, the I<TradeDB> and I<master> databases haven't been backed 
for five days.


=head1 DESCRIPTION

The script I<msql.pl> simulates the beloved command-line utility I<osql.exe>. But it expands osql.exe
to work on multiple SQL Server instances. If you need to run a query or a T-SQL script on many SQL
Server instances at once, this is the script for you.

The script I<msql.pl> accepts all the command-line arguments that I<osql.exe> accepts, and 
it introduces the following two extensions:

=over

=item *

The script extends the -S option to accept a comma-separated list of SQL Server instances.

=item *

The script accepts a new option, -C. This option expects an INI file that lists SQL Server 
instances in its section headings.

=back

Programmatically, the I<msql.pl> script loops through the SQL Server instances in the INI 
file. For each instance, the script invokes I<osql.exe> and passes all the other command-line 
arguments to I<osql.exe>.

The bulk of the code is in the function I<validateConfig()>, which prepares the command-line 
arguments to pass to I<osql.exe> for each SQL Server.

The function I<validateConfig()> splits the comma-separated SQL Server instance names -- 
specified with -S -- into an array and assigns its reference to $optRef->{S}. If more SQL 
Server instances are specified in the section headings of the INI file, which is specified on 
the command line with -C, I<validateConfig()> merges them into this array. 

In addition, the function puts the double quotes back to the values of the options, 
-q, -Q, and -i, before passing them to I<osql.exe>. Note that the function escapes each 
embedded double quote with another double.



=head1 AUTHOR

Linchi Shea

=head1 VERSION

 2003.02.25

=cut


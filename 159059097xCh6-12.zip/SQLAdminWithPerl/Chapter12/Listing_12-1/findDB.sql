SET NOCOUNT ON

SELECT name 
  FROM master..sysdatabases
 WHERE name = 'Orders'

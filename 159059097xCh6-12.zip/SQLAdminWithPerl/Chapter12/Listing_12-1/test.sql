set nocount on

select @@servername
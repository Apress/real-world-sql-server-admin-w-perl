set nocount on
go

sp_helpdb 'pubs'

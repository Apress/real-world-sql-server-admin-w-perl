use master
go

SET NOCOUNT ON
SELECT 'ServerName' = @@servername, 'DatabaseName' = d.name
  FROM master..sysdatabases d
 WHERE NOT EXISTS (
         SELECT * FROM msdb..backupset b
          WHERE b.type = 'D'
            AND DATEDIFF(day, b.backup_finish_date, GETDATE()) < 10
            AND b.database_name = d.name )
   AND name NOT IN ('model', 'tempdb', 'pubs', 'Northwind', 'DBA')

use master
go

set nocount on

if cast(substring(@@version, patindex('%8.00.%', @@version)+5, 3) as int) <= 760
begin
   select substring(@@version, patindex('%8.00.%', @@version), 8)
end

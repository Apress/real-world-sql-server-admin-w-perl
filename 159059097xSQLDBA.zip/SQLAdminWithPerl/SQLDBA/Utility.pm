package SQLDBA::Utility;

use Time::Local;
use Data::Dumper;
use Win32::OLE 'in';
use Win32::EventLog;
use Net::SMTP;
use Carp;

use strict;
use vars qw(@ISA @EXPORT $VERSION @EXPORT_OK);

use Exporter;
$VERSION=1.00;
@ISA = ('Exporter');
@EXPORT_OK = qw(
    &dbaReadConfig 
    &dbaReadConfig2
    &dbaReadConfig3
    &dbaReadINI

    &dbaTime2str
    &dbaStr2time 
    &dbaTime2dateStr
    &dbaDateDiff
    &dbaTimeDiff
    &dbaIsBetweenTime

    &dbaSetDiff 
    &dbaSetCommon 
    &dbaSetSame
    &dbaInSet 
    &dbaInStrList
    &dbaRemoveDuplicates

    &dbaReadSavedRef
    &dbaSaveRef
    &dbaSMTPSend 

    &dbaRunOsql
    &dbaRunQueryADO

    &dbaStringDiff

    &dbaGetTableStruct_sp_help

    &dbaReadEventLog
    &dbaFilterLogEntry

    &dbaGetTree
);

###############################
#  Read from the config file
sub dbaReadConfig {
###############################
   my ($configFile) = shift or
      croak "***Err: dbaReadConfig() expects a config file name.";
   my ($ref, $section);

   open(CONFIG, "$configFile") or
      croak "***Err: Could not open file $configFile for read.";
   while (<CONFIG>) {
     next if /^\s*\#/;                # skip comment line
     s/^((\\\#|\\\\|[^\#])*).*$/$1/;  # remove trailing comments

     if (/^\s*\[(.+)\]\s*$/) {   # read section heading
         $section = uc($1);      # convert to upper case
         $section =~ s/^\s*//;   # remove leading whitespaces
         $section =~ s/\s*$//;   # remove trailing whitespaces
         
         croak "***Err: $section is a duplicate section heading."
            if exists $ref->{$section};
         $ref->{$section} = {};
         next;
     }

     if ((/^\s*([^\s\[\]=]+)\s*=\s*(.+)\s*$/i) and $section) {
         my ($key, $value) = (uc($1), $2);
         $key =~ s/^\s*//; $key =~ s/\s*$//;
         $value =~ s/#.*//;
         $value = undef if $value =~ /^\s*$/;
         push @{$ref->{$section}->{$key}}, $value;
         next;
     }
   } # while

   return $ref;
}  # dbaReadConfig

###########################
# Read from an ini file
###########################
sub dbaReadINI {
   my ($iniFile) = shift 
      or croak "***Err: dbaReadINI() expects an INI file name.";
   my ($ref, $section);

   open(INI, "$iniFile") 
      or croak "***Err: could not open file $iniFile for read.";
   while (<INI>) {
      next if /^\s*#/;   # skip comment line
      s/\#.*//;          # remove trailing comments

      if (/^\s*\[(.+)\]\s*$/) {  # read section heading
         $section = uc($1);      # convert to upper case
         $section =~ s/^\s*//;   # remove leading whitespace
         $section =~ s/\s*$//;   # remove trailing whitespace
         
         croak "***Err: $section is a duplicate section heading."
            if exists $ref->{$section};
         $ref->{$section} = {};
         next;
      }

      if ((/^\s*([^=]+)\s*=\s*(.*)\s*$/i) and $section) {
         my ($key, $value) = (uc($1), $2);
         $key =~ s/^\s*//; $key =~ s/\s*$//;
         $value =~ s/^\s*//; $value =~ s/\s*$//;
         $value = undef if $value =~ /^\s*$/;

         croak "***Err: $key has a duplicate in $section."
            if exists $ref->{$section}->{$key};
         $ref->{$section}->{$key} = $value;
         next;
      }
   } # while
   return $ref;
} # dbaReadINI

###############################
#  Read from the config file
sub dbaReadConfig2 {
###############################
    my ($configFile) = shift 
         or croak "***Err: dbaReadConfig2() expects a config file name.";
    my ($ref, $section);

    open(CONFIG, "$configFile") 
        or croak "Error: Could not open file $configFile for read.";
    while (<CONFIG>) {
      next if /^\s*#/;   # skip comment line
      s/\#.*//;          # remove trailing comments

      if (/^\s*\[(.+)\]\s*$/) {  # read section heading
         $section = uc($1);      # convert to upper case
         $section =~ s/^\s*//;   # remove leading whitespace
         $section =~ s/\s*$//;   # remove trailing whitespace
         
         croak "***Err: $section is a duplicate section heading."
            if exists $ref->{$section};
         $ref->{$section} = {};
         next;
      }

      if ((/^\s*([^=]+)\s*=\s*(.*)\s*$/i) and $section) {
         my ($key, $value) = (uc($1), $2);
         $key =~ s/^\s*//; $key =~ s/\s*$//;
         $value =~ s/^\s*//; $value =~ s/\s*$//;
         next if $value =~ /^\s*$/;

         $ref->{$section}->{$key} = [ split /\s*,\s*/, $value ];
         next;
      }
    } # while

    return $ref;
}  # dbaReadConfig2

###############################
#  Read from the config file
sub dbaReadConfig3 {
###############################
    my ($configFile) = shift 
         or croak "***Err: dbaReadConfig3() expects a config file name.";
    my ($ref, $section);
    my $i;

    open(CONFIG, "$configFile") 
        or croak "Error: Could not open file $configFile for read.";
    while (<CONFIG>) {
        next if /^\s*#/;
        
        if (/^\s*\[(.+)\]\s*$/) {
            $section = uc($1);
            $section =~ s/^\s*//;
            $section =~ s/\s*$//;
            ++$i;
            next;
        }

        if ((/^\s*([^\s\[\]=]+)\s*=\s*(.+?)\s*$/i) and $section) {
            my ($key, $value) = ($1, $2);
            $value =~ s/#.*//;
            next if $value =~ /^\s*$/;
            $ref->{$i . '.' . $section}->{uc($key)} = $value;
            next;
        }
    } # while

    return $ref;
}  # dbaReadConfig3

###########################
sub dbaSaveRef {
###########################
   my ($file, $ref, $refVar) = @_;

   open(DOC, ">$file") or 
      croak "***Err: unable to open $file for write.";
   print DOC Data::Dumper->Dump([$ref], [$refVar]);
   close(DOC);
}  # dbaSaveRef

###########################
sub dbaReadSavedRef {
###########################
   my($file) = shift or croak "***Err: readSavedRef() expects a file name.";

   my $refStr;

   open(DOC, "$file") or do { carp "***Err: couldn't open $file."; return undef};
   read(DOC, $refStr, -s DOC);
   close(DOC);

   no strict 'vars';
   my $ref = eval $refStr;
   if ($@) {
      print "***Msg: problem reading file $file. $@\n";
      print Dumper($ref);
      return undef;
   }

   return $ref;
}  # dbaReadSavedRef

#####################
sub dbaTime2str {
#####################
    my $time = shift;
    $time = time() if ! defined $time;

    my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) 
                     = localtime($time);

    sprintf("%04d\/%02d\/%02d %02d:%02d:%02d", 
                 $year+1900, ++$mon, $mday, $hour, $min, $sec);
} # dbaTime2str

#########################
sub dbaTime2dateStr {
#########################
    my($time) = shift || time;
    my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime($time);

    sprintf("%04d\/%02d\/%02d", $year+1900, ++$mon, $mday);
} # dbaTime2dateStr


##########################
sub dbaStr2time {
##########################
#   Accepts time string in these formates:
#     2003-11-23 12:23:31.12
#     1999/12/23 15:21:35
#     2000-08-03 05:23:12
#     2002-08-13
#       
#   It peforms no error check, and is used primarily to accept output from dbaTime2str
#
   my($timestr) = @_;

   $timestr =~ /^\s*(\d\d\d\d)(\/|-)(\d\d|\d)(\/|-)(\d\d|\d)     # date
                    (\s+(\d\d|\d):(\d\d|\d) (?: :(\d\d|\d) )? )? # time
                 \s*
               /x;
   my @timeArray = ($9, $8, $7, $5, $3 - 1, $1 - 1900);
   unless ($timeArray[0] >= 0 and $timeArray[0] <= 59) {
      croak "***Err: sec - $timeArray[0] is out of bound (0..59).";
   }
   unless ($timeArray[1] >= 0 and $timeArray[1] <= 59) {
      croak "***Err: min - $timeArray[1] is out of bound (0..59).";
   }
   unless ($timeArray[2] >= 0 and $timeArray[2] <= 23) {
      croak "***Err: hours - $timeArray[2] is out of bound (0..23).";
   }
   unless ($timeArray[3] >= 1 and $timeArray[3] <= 31) {
      croak "***Err: mday - $timeArray[3] is out of bound (1..31).";
   }
   unless ($timeArray[4] >= 0 and $timeArray[4] <= 11) {
      croak "***Err: month - $timeArray[4] is out of bound (0..11).";
   }
   unless ($timeArray[5] >= 1 and $timeArray[5] <= 138) {
      croak "***Err: year - $timeArray[5] is out of bound (1..138).";
   }

   timelocal(@timeArray);
} # dbaStr2time

###################
sub dbaSetDiff {
###################
    my($setRef1, $setRef2) = @_;
    croak "***Err: dbaSetDiff() expects two references." unless ref($setRef1) && ref($setRef2);
    my %temp = ();
    my %diff = ();

    grep {$temp{$_}++} @$setRef2;
    grep {!$temp{$_} and $diff{$_}++} @$setRef1;
    keys %diff;
} # dbaSetDiff

###################
sub dbaSetSame {
###################
   my($ref1, $ref2) = @_;
    croak "***Err: dbaSetSame() expects two references." unless ref($ref1) && ref($ref2);

   return 0 if scalar dbaSetDiff($ref1, $ref2);
   return 0 if scalar dbaSetDiff($ref2, $ref1);
   return 1;
}

#####################
sub dbaSetCommon {
#####################
    my($setRef1, $setRef2) = @_;
    croak "***Err: dbaSetCommon() expects two references." unless ref($setRef1) && ref($setRef2);
    my %temp;
    my %common;

    grep($temp{$_}++, @$setRef2);
    map {$temp{$_} and $common{$_}++} @$setRef1;
    keys %common;
} # dbaSetCommon

#####################
sub dbaInSet {
#####################
    my($element, $setRef) = @_;
    $element = quotemeta($element);
    grep(/^$element$/, @$setRef);
} # dbaInSet

###########################
sub dbaInStrList {
###########################
   my ($e, $strList) = @_;
   
   my @list = split /[,;\s]/, $strList;
   return grep /^\s*$e\s*$/i, @list
} # dbaInStrList

###########################
sub dbaRemoveDuplicates {
###########################
   my ($setRef) = shift or
      croak "***Err: dbaRemoveDuplicates() expects a reference.";

   my %temp;
   map { $temp{$_} = 1 } @$setRef;
   return [ keys %temp ];
} # dbaRemoveDuplicates


###############################
sub dbaDateDiff {
###############################
    my($date1, $date2) = @_;
    my $diff;
 
    my($year1, $month1, $day1);
    if ($date1 =~ /^\s*(\d\d|\d\d\d\d)(\/|\-)(\d\d|\d)(\/|\-)(\d\d|\d)\s*$/) {
       $year1 = $1;
       $month1 = $3;
       $day1 = $5;

       if ($year1 =~ /^\d\d$/) {
          ($year1 > 50) ? $year1 += 1900 : $year1 += 2000;
       }
    } else {
        print "Err: $date1 is not in the expected format.\n";
        return;
    }

    my($year2, $month2, $day2);
    if ($date2 =~ /^\s*(\d\d|\d\d\d\d)(\/|\-)(\d\d|\d)(\/|\-)(\d\d|\d)\s*$/) {
       $year2 = $1;
       $month2 = $3;
       $day2 = $5;

       if ($year2 =~ /^\d\d$/) {
          ($year2 > 50) ? $year2 += 1900 : $year2 += 2000;
       }
    } else {
        print "Err: $date2 is not in the expected format.\n";
        return;
    }

#print "$year1\/$month1\/$day1\n";
#print "$year2\/$month2\/$day2\n";

    $diff = timelocal(0,0,0, $day2, --$month2, $year2) - timelocal(0,0,0, $day1, --$month1, $year1);
    $diff = $diff/(3600*24);
}

###############################
sub dbaTimeDiff {
###############################
    my ($ts1, $ts2) = @_;
    return dbaStr2time($ts2) - dbaStr2time($ts1);
}

#########################
sub dbaIsBetweenTime {
#########################
   my $q = shift || return 0;
   my ($this_hour) = (localtime)[2];
   my $isBetween = 0;

   my($start, $end) = ();

   if ($q =~ /(\d{1,2})\s*\-\s*(\d{1,2})/) {
      ($start, $end) = ($1, $2);
   } 
   else {
      return $isBetween;
   }

   if ($start < $end) {
      $isBetween = 1 if (($start <= $this_hour) && ($this_hour < $end));
   }
   elsif ($start == $end) {
      return $isBetween;
   }
   else {
      $isBetween = 1 if (   (($start <= $this_hour) && ($this_hour < 24)) 
                      || ((0 <= $this_hour) && ($this_hour < $end)));
   }
   return $isBetween;
} # dbaIsBetweenTime

#####################
sub dbaSMTPSend {
#####################
    my ($SMTPServer, $recipRef, $sender, $msg, $sub, $to, $from) = @_;

    my $smtp = Net::SMTP->new($SMTPServer) or
      croak "***Err: couldn't create new Net::SMTP object for $SMTPServer.\n";

    $smtp->mail($sender);
    $smtp->to(@$recipRef);
    $smtp->data();
    $smtp->datasend("Subject: $sub\n"); # $sub is sent in the subject
    $smtp->datasend("To: $to\n");       # will appear in To: header
    $smtp->datasend("From: $from\n");   # will appear in To: header
    $smtp->datasend("\n");
    $smtp->datasend("$msg\n");
    $smtp->datasend() or 
      croak "***Err: had problem sending message to the mail server.";
    $smtp->quit or 
      croak "***Err: couldn't close the connection to the mail server.";

    return 1;
} # dbaSMTPSend

########################
sub dbaRunOsql {
########################
    my ($instance, $sql, $optRef) = @_;
    return undef if (!defined $instance or !defined $sql);

    my $sqlfile = "sql_tmp_" . time() . "_" . int(rand()*100000) . 
                       int(rand()*100000) . ".sql";
    open(SQL, ">$sqlfile") or 
       croak "***Err: Could not open $sqlfile for write.\n";
    print SQL $sql;
    close(SQL);

    my $optStr = ' ';
    foreach my $opt (keys %$optRef) {
       $optStr .= $opt . $optRef->{$opt} . ' ';
    }

    my $osql = "osql -S$instance -i$sqlfile $optStr 2>&1";
    my $rs = `$osql`;
    unlink($sqlfile);
    return $rs;
}  # dbaRunOsql


#################################
sub dbaGetTableStruct_sp_help {
#################################
   my $spHelp = shift or croak "**Err: dbaGetTableStruct() expects the result of sp_help.\n";
   
   my $tbRef;
   my @spHelps = split /\n/, $spHelp;
   unless (@spHelps) {
      carp "***Err: This is not the result of sp_help.\n";      
      return;
   }
   while(defined(my $val = shift @spHelps)) {
      if ($val =~ /Name\s+Owner\s+Type/i) {
         shift @spHelps; 
         $val = shift @spHelps;
         if ($val =~ /([\w\@\#\$]+)\s+([\w\@\#\$]+)\s+user\s+table/i) {
            $tbRef->{TableName} = "$2\.$1";
         }
         else {
            carp "***Err: This is not the result of sp_help.\n";      
            return;
         }
         next;
      }
      if ($val =~ /Column_name\s+Type/i) {   # Column definition
         shift @spHelps;
         $val = shift @spHelps;
         my $colid = 0;
         while ($val !~ /Identity\s+seed\s+increment/i) {
            if ($val =~ /([\w\@\#\$]+)\s+([\w\@\#\$]+)\s+(yes|no)\s+(\d+)\s+(\d*)\s+(\d*)\s+(yes|no)/i) {
               $tbRef->{Columns}->{$1} = {
                                            colid => ++$colid,
                                            type => $2,
                                            computed => $3,
                                            length => $4,
                                            prec => $5,
                                            scale => $6,
                                            nullable => $7
                                         };
            }
            else {
               unless ($val =~ /^\s*$/) {
                  carp "***AssertErr: $val is not a column row.\n";
                  return;
               }
            }
            $val = shift @spHelps;
         }
      }
      if ($val =~ /Identity\s+seed\s+increment/i) {   # identity property
         shift @spHelps;
         $val = shift @spHelps;
         if ($val =~ /([\w\@\#\$]+)\s+(\d+)\s+(\d+)\s+(\d+)/i) {
            $tbRef->{Identity} = {
                                    column => $1,
                                    seed => $2,
                                    increment => $3,
                                    not_for_replication => $4
                                 };
         }
         next;
      }
      if ($val =~ /RowGuidCol/i) {   # RowGuidCol property
         shift @spHelps;
         $val = shift @spHelps;
         if ($val =~ /([\w\@\#\$]+)/i) {
            $tbRef->{RowGuidCol} = $1;
         }
         next;
      }
      if ($val =~ /Data_located_on_filegroup/i) {   # file group for data
         shift @spHelps;
         $val = shift @spHelps;
         if ($val =~ /(\w+)/i) {
            $tbRef->{Data_located_on_filegroup} = $1;
         }
         next;
      }
      if ($val =~ /index_name\s+index_description\s+index_keys/i) {
         shift @spHelps;
         $val = shift @spHelps;
         while ($val !~ /(  constraint_type\s+constraint_name\s+delete_action
                          | No\s+constraints\s+have\s+been\s+defined)/ix) {
            if ($val =~ /(.+?)\s+((clustered|nonclustered).+located on \w+)\s+(.+)/i) {
               my ($index_name, $index_descr, $index_keys) = ($1, $2, $4);
               $index_keys =~ s/\s*$//;
               $tbRef->{Indexes}->{$index_name} = {
                              UniqueKey => ($index_descr =~ /unique\s+key/i ? 1 : 0),
                              PrimaryKey => ($index_descr =~ /primary\s+key/i ? 1 : 0),
                              Clustered => ($index_descr =~ /\bclustered/i ? 1 : 0),
                              UniqueIndex => ($index_descr =~ /unique,/i ? 1 : 0)
                           };
            }
            else {
               unless ($val =~ /^\s*$/) {
                  carp "***AssertErr: $val is not an index row.\n";
                  return;
               }
            }
            $val = shift @spHelps;
         }
      }
      if ($val =~ /constraint_type\s+constraint_name\s+delete_action/i) {
         shift @spHelps;
         $val = shift @spHelps;
         while ($val !~ /(  Table\s+is\s+referenced\s+by\s+foreign\s+key
                          | No\s+foreign\s+keys\s+reference\s+this\s+table)/ix) {
            if ($val =~ / (CHECK\s+on\s+column\s+(\w+)|CHECK\s+Table\s+Level)\s+(\w+)\s+
                                 \(n\/a\)\s+\(n\/a\)\s+(enabled|disabled)\s+[^\s]+\s+(.+)
                        /ix) {
               my ($column, $name, $enabled, $constraint) = ($1, $3, $4, $5);
               $constraint =~ s/\s*$//;
               $tbRef->{Constraints}->{Check}->{$name} = {
                        ColumnLevel => (($column =~ /column/i)? 1 : 0),
                        Enabled => $enabled,
                        Constraint => $constraint
                     };
            }
            elsif ($val =~ /(DEFAULT\s+on\s+column\s+(\w+))\s+(\w+)\s+
                              \(n\/a\)\s+\(n\/a\)\s+\(n\/a\)\s+\(n\/a\)\s+(.+)
                           /ix) {
               my ($column, $name, $constraint) = ($2, $3, $4);
               $constraint =~ s/\s*$//;
               $tbRef->{Constraints}->{Default}->{$name} = {
                        Column => $column,
                        Constraint => $constraint
                     };
            }
            elsif ($val =~ / (PRIMARY\s+KEY\s+[^\s]+)\s+(\w+)\s+
                              \(n\/a\)\s+\(n\/a\)\s+\(n\/a\)\s+\(n\/a\)\s+(.+)
                           /ix) {
               my($clustered, $name, $constraint) = ($1, $2, $3);
               $constraint =~ s/\s*$//;
               $tbRef->{Constraints}->{PrimaryKey} = {
                        Name => $name,
                        Clustered => ($clustered =~ /(non-clustered|nonclustered)/i ? 0 : 1),
                        Constraint => $constraint
                     };
            }
            elsif ($val =~ /(UNIQUE\s+[^\s]+)\s+(\w+)\s+
                              \(n\/a\)\s+\(n\/a\)\s+\(n\/a\)\s+\(n\/a\)\s+(.+)
                           /ix) {
               my($clustered, $name, $constraint) = ($1, $2, $3);
               $constraint =~ s/\s*$//;
               $tbRef->{Constraints}->{UniqueKey} = {
                        Name => $name,
                        Clustered => ($clustered =~ /(non-clustered|nonclustered)/i ? 0 : 1),
                        Constraint => $constraint
                     };
            }
            elsif ($val =~ /FOREIGN\s+KEY\s+(\w+)\s+
                              (No\s+action|CASCADE)\s+(No\s+action|CASCADE)\s+
                              (enabled|disabled)\s+\w+\s+(.+)
                           /ix) {
               my($name, $deleteAction, $updateAction, $enabled, $constraint) = ($1, $2, $3, $4, $5);
               $constraint =~ s/\s*$//;
               $val = shift @spHelps;
               $val =~ s/^\s*//;
               $val =~ s/\s*$//;
               $constraint = "($constraint) " . $val;
               $tbRef->{Constraints}->{ForeignKey}->{$name} = {
                        DeleteAction => $deleteAction,
                        UpdateAction => $updateAction,
                        Enabled => $enabled,
                        Constraint => $constraint
                     };
            }
            else {
               unless ($val =~ /^\s*$/) {
                  carp "***AssertErr: $val is not a constraint row.\n";
                  return;
               }
            }
            $val = shift @spHelps;
         }
      }
   }
   return $tbRef;
} # dbaGetTableStruct_sp_help

######################
sub dbaRunQueryADO {
######################
   my ($server, $sql, $timeout) = @_;
   
   my @results;

   my $conn = Win32::OLE->new('ADODB.Connection') or 
      do {carp "***Err: Win32::OLE->new() failed."; return undef; };
   $conn->{ConnectionTimeout} = $timeout || 4;
#   $conn->Open("Driver={SQL Server};Server=$server;Trusted_Connection=yes");
   $conn->Open("Provider=sqloledb;Server=$server;Trusted_Connection=yes");
   ! Win32::OLE->LastError() or
      do { carp Win32::OLE->LastError(); return undef; };
      
   my $rs = $conn->Execute($sql) or
      do { carp Win32::OLE->LastError(); return undef; };

   while ($rs) {
      my @resultset = ();
      unless ( $rs->{State} ) {
         $rs = $rs->NextRecordSet();
         next;
      }
      while ( !$rs->{EOF} ) {
         my $ref;
         foreach my $col ( in($rs->Fields()) ) {
            $ref->{$col->{Name}} = $col->{Value};
         }
         push @resultset, $ref;
         $rs->MoveNext;
      }
      push @results, \@resultset;
      $rs = $rs->NextRecordSet();
   }
   $conn->Close();
   return \@results;
} # dbaRunQueryADO

#####################
sub dbaStringDiff {
#####################
   my($s1, $s2, $num, $case) = @_;
   $num = 20 unless $num =~ /\d+/;
   $case = $case == 1 ? 1 : 0;

   my @a1 = split(//, (length($s1) >= length($s2)) ? $s1: $s2);
   my @a2 = split(//, (length($s1) >= length($s2)) ? $s2: $s1);
   
   my $ref;
   my $longer = scalar @a1 > scalar @a2 ? scalar @a1 : scalar @a2;
   my $line = 1;
   for(my $i = 0; $i <= $longer; $i++) {
      ++$line if $a1[$i] eq "\n";
      if ( ($case ? $a1[$i] : lc($a1[$i])) ne 
           ($case ? $a2[$i] : lc($a2[$i])) ) {
         $ref = {
               pos  => $i,
               line => $line,
               diff => join('', '(1) ', @a1[$i..$i+$num], ' <> ', '(2) ', @a2[$i..$i+$num])
            };
         last;
      }
   }
   return $ref;
} # dbaStringDiff

#########################
sub dbaReadEventLog {
#########################
   my($server, $filterRef, $configRef) = @_;
   my($summaryRef, $element);

   # this hash is used to map numeric constants to meaningful strings
   my %types = ( EVENTLOG_ERROR_TYPE,        'ERROR', 
                 EVENTLOG_INFORMATION_TYPE,  'INFORMATION',
                 EVENTLOG_WARNING_TYPE,      'WARNING',
               );

   $Win32::EventLog::GetMessageText = 1;  # add Message key to $eventRef hash
   foreach my $log (@{$configRef->{$server}->{LOG}}) {
      my $cutoff = time() -  
                   ${$configRef->{$server}->{INCLUDEDAYS}}[0] * 24 * 3600;

      # get the handle to the event log
      my $handle = Win32::EventLog->new($log, $server) 
                or croak "Could not open $log on $server: $!\n";
      my $eventRef;
      
      # loop through the log backwards, one record a time
      while (    $handle->Read( EVENTLOG_BACKWARDS_READ | 
                                EVENTLOG_SEQUENTIAL_READ, 0, $eventRef)
              && $cutoff < $eventRef->{TimeGenerated} ) {

         # only process a record if it meets the criteria 
         if ( &$filterRef($server, $configRef, $eventRef) == 1 ) {
            # concatenate the event fields specified in the LogElement option
            foreach my $field (@{$configRef->{$server}->{LOGELEMENT}}) {
               if ($field eq 'TYPE') {
                  $element .= $types{$eventRef->{EventType}} . ', ';
               }
               elsif ($field eq 'SOURCE') {
                  $element .= 'Source: ' . $eventRef->{Source} . ', ';
               }
               elsif ($field eq 'EVENTID') {
                  $element .= 
                        'EventID: ' .($eventRef->{EventID} & 0xffff). ', ';
               }
               elsif ($field eq 'MESSAGE') {
                  my $msg = substr($eventRef->{Message}, 0, 100);
                  $msg =~ s/\s*$//;
                  $msg =~ s/[\n\r]/ /g;
                  $element .= 'Message: ' . $msg . ', ';
               }
            } # for each my $field
            
            # record the event fields in the summary hash if not there
            if (!exists $summaryRef->{$log}->{$element}) {
                $summaryRef->{$log}->{$element}->{Type} 
                                     = $types{$eventRef->{EventType}};
                $summaryRef->{$log}->{$element}->{Source} 
                                     = $eventRef->{Source};
                $summaryRef->{$log}->{$element}->{EventID} 
                                     = $eventRef->{EventID} & 0xffff;
                $summaryRef->{$log}->{$element}->{TimeGeneratedStr} 
                                     = dbaTime2str($eventRef->{TimeGenerated});
                $summaryRef->{$log}->{$element}->{TimeGenerated} 
                                     = $eventRef->{TimeGenerated};
            }
            $summaryRef->{$log}->{$element}->{No}++; # increment the tally
         } # if (&$filterRef(...) == 1)
         $element = '';
      } # while
      Win32::EventLog::CloseEventLog($handle);
   }  # foreach my $log
   return $summaryRef;
} # dbaReadEventLog

#########################
sub dbaFilterLogEntry {
#########################
   my ($server, $configRef, $eventRef) = @_;
   my $return = 0;

   my %types = ( EVENTLOG_ERROR_TYPE,        'ERROR', 
                 EVENTLOG_INFORMATION_TYPE,  'INFORMATION',
                 EVENTLOG_WARNING_TYPE,      'WARNING',
               );
   # check TYPE
   if (exists $configRef->{$server}->{INCLUDETYPE}) {
      return -1 if (!dbaInSet(uc($types{$eventRef->{EventType}}), 
                              $configRef->{$server}->{INCLUDETYPE}));
   }
   if (exists $configRef->{$server}->{EXCLUDETYPE}) {
      return -2 if (dbaInSet(uc($types{$eventRef->{EventType}}), 
                             $configRef->{$server}->{EXCLUDETYPE}));
   }
   # check SOURCE
   if (exists $configRef->{$server}->{INCLUDESOURCE}) {
      return -3 if (!dbaInSet(uc($eventRef->{Source}), 
                              $configRef->{$server}->{INCLUDESOURCE}));
   }
   if (exists $configRef->{$server}->{EXCLUDESOURCE}) {
      return -4 if (dbaInSet(uc($eventRef->{Source}), 
                             $configRef->{$server}->{EXCLUDESOURCE}));
   }
   # check EVENTID
   if (exists $configRef->{$server}->{INCLUDEEVENTID}) {
      return -5 if (!dbaInSet($eventRef->{EventID} & 0xffff, 
                              $configRef->{$server}->{INCLUDEEVENTID}));
   }
   if (exists $configRef->{$server}->{EXCLUDEEVENTID}) {
      return -6 if (dbaInSet($eventRef->{EventID} & 0xffff, 
                             $configRef->{$server}->{EXCLUDEEVENTID}));
   }
   # check message body
   if (exists $configRef->{$server}->{INCLUDEMESSAGE}) {
      foreach my $re (@{$configRef->{$server}->{INCLUDEMESSAGE}}) {
         next if ! defined $re;
         return -7 unless eval { 1 if $eventRef->{Message} =~ /$re/ };
      }
   }
   if (exists $configRef->{$server}->{EXCLUDEMESSAGE}) {
      foreach my $re (@{$configRef->{$server}->{EXCLUDEMESSAGE}}) {
         next if ! defined $re;
         return -8 if eval { 1 if $eventRef->{Message} =~ /$re/ }
      }
   }
   return 1;
} # dbaFilterLogEntry

##################
sub dbaGetTree {
##################
   my($lookupRef, $ref, $path) = @_;
   
   my $rc = {};
   foreach my $key (@$ref) {
      if (grep {$key eq $_} @$path) {
         push @$path, $key;
         croak "***Err: circular dependency. " . join(', ', @$path);
      }
      my $newPath = [ @$path ];
      push @$newPath, $key;
      $rc->{$key} = dbaGetTree($lookupRef, $lookupRef->{$key}, $newPath);
   }
   return $rc;
} # dbaGetTree

1;

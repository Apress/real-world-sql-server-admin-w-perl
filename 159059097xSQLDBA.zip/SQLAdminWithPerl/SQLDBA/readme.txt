This folder includes the following module files:

ParseSQL.pm
ScriptSQL.pm
Security.pm
SQLDMO.pm
Utility.pm

If you have installed Perl in D:\perl, you should place these module files in
the folder D:\perl\site\lib\SQLDBA. If this folder doesn't exist, create it.
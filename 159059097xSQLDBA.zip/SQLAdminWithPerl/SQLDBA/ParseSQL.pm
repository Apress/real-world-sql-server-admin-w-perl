package SQLDBA::ParseSQL;

use strict;
use Parse::RecDescent;
use Carp;

use vars qw(@ISA @EXPORT $VERSION @EXPORT_OK $TSQLReservedWords);

use Exporter;
$VERSION=1.00;
@ISA = ('Exporter');
@EXPORT_OK = qw(

    &dbaGetUniqueToken 
    &dbaNormalizeSQL 
    &dbaSplitBatch 
    &dbaRestoreSQL
    &dbaParseQDON

    $TSQLReservedWords
);

$TSQLReservedWords = qr/\b(  
      ADD | ALL | ALTER | AND | ANY |
      AS | ASC | AUTHORIZATION | BACKUP | BEGIN |
      BETWEEN | BREAK | BROWSE | BULK | BY | CASCADE | 
      CASE | CHECK | CHECKPOINT | CLOSE | CLUSTERED | 
      COALESCE | COLLATE | COLUMN | COMMIT | COMPUTE | 
      CONSTRAINT | CONTAINS | CONTAINSTABLE | CONTINUE |
      CONVERT | CREATE | CROSS | CURRENT | CURRENT_DATE |
      CURRENT_TIME | CURRENT_TIMESTAMP | CURRENT_USER | 
      CURSOR | DATABASE | DBCC | DEALLOCATE | DECLARE | 
      DEFAULT | DELETE | DENY | DESC | DISK | DISTINCT | 
      DISTRIBUTED | DOUBLE | DROP | DUMMY | DUMP | ELSE |
      END | ERRLVL | ESCAPE | EXCEPT | EXEC | EXECUTE | 
      EXISTS | EXIT | FETCH | FILE | FILLFACTOR | FOR | 
      FOREIGN | FREETEXT | FREETEXTTABLE | FROM | FULL | 
      FUNCTION | GOTO | GRANT | GROUP | HAVING | 
      HOLDLOCK | IDENTITY | IDENTITYCOL | 
      IDENTITY_INSERT | IF | IN | INDEX | INNER |
      INSERT | INTERSECT | INTO | IS | JOIN | KEY | KILL | 
      LEFT | LIKE | LINENO | LOAD | NATIONAL | NOCHECK | 
      NONCLUSTERED | NOT | NULL | NULLIF | OF | OFF | 
      OFFSETS | ON | OPEN | OPENDATASOURCE | OPENQUERY | 
      OPENROWSET | OPENXML | OPTION | OR | ORDER | OUTER |
      OVER | PERCENT | PLAN | PRECISION | PRIMARY |
      PRINT | PROC | PROCEDURE | PUBLIC | RAISERROR |
      READ | READTEXT | RECONFIGURE | REFERENCES | 
      REPLICATION | RESTORE | RESTRICT | RETURN | REVOKE | 
      RIGHT | ROLLBACK | ROWCOUNT | ROWGUIDCOL | RULE | 
      SAVE | SCHEMA | SELECT | SESSION_USER | SET | 
      SETUSER | SHUTDOWN | SOME | STATISTICS | 
      SYSTEM_USER | TABLE | TEXTSIZE | THEN | TO | TOP | 
      TRAN | TRANSACTION | TRIGGER | TRUNCATE | TSEQUAL | 
      UNION | UNIQUE | UPDATE | UPDATETEXT | USE | USER |
      VALUES | VARYING | VIEW | WAITFOR | WHEN |
      WHERE | WHILE | WITH | WRITETEXT 
   )\b/ix; 

##########################
sub dbaGetUniqueToken {
##########################
   my ($script) = shift or
      croak "***Err: dbaGetUNiqueToken() expects a string.";
   
   my $tokenSeed = 'ls_token_123456_';
   while ($script =~ /$tokenSeed/i) {
      $tokenSeed = 'ls_token' . '_' . int(rand(100000)) . '_';
   } 
   return $tokenSeed;
} # dbaGetUniqueToken

#######################
sub dbaNormalizeSQL {
#######################
   my ($script, $option) = @_;
   $script or croak "***Err: dbaNormalizeSQL() expects a string.";
   
# $option == 0   strip off the comments from the code
# $option == 1   normalize but preserve the comments

   my $tokenSeed = dbaGetUniqueToken($script);

   use vars qw( $seed $opt);
    
   $::RD_HINT = 0;
   my $Grammar=<<'SQLGRAMMAR';

      {  my $cnt;
         my $sqlRef = {  code          => '', 
                         double_ids    => { },
                         bracket_ids   => { },
                         comments      => { },
                         strings       => { }
                      };
      }

      program : <skip:''> part(s) /\z/ { $sqlRef }

      part    :   comment
                | string
                | double_identifier
                | bracket_identifier
                | rest_of_SQL_code

      comment : 
          ansi_comment
            { ++$cnt;
              if ($SQLDBA::ParseSQL::opt == 1) {  
                 $sqlRef->{code} .= "--" . $SQLDBA::ParseSQL::seed . $cnt . "\n";
              }
              else {
                 $sqlRef->{code} .= ' ';
              }
              $sqlRef->{comments}->{$SQLDBA::ParseSQL::seed . $cnt} = $item[1]; 
            }

        | delimited_comment
            { ++$cnt;
              if ($SQLDBA::ParseSQL::opt == 1) {
                 $sqlRef->{code} .= "/*" . $SQLDBA::ParseSQL::seed . $cnt . "*/";
              }
              else {
                 $sqlRef->{code} .= ' ';
              }
              $sqlRef->{comments}->{$SQLDBA::ParseSQL::seed . $cnt} = $item[1]; 
            }

      ansi_comment : m{ --([^\n]*)\n }x    { $1 }

      delimited_comment : simple_comment   { $item[1] }
                        | nested_comment   { $item[1] }                       

      simple_comment : 
           comment_opener pure_comment(s?) comment_closer   
               { $item[1] . join('', @{$item[2]}) . $item[3] }

      nested_comment : 
           comment_opener raw_comment(s) comment_closer 
               { $item[1] . join('', @{$item[2]}) . $item[3] }

      raw_comment : 
           pure_comment(?) delimited_comment pure_comment(?)
               { join('', @{$item[1]}) . $item[2] . join('', @{$item[3]}) }

      comment_opener : m{ /\* }x                
                         { '' }

      comment_closer : m{ \*/ }x                
                         { '' }

      pure_comment :
           m{ (?:  [^*/]+     # no * or /
                  | \*(?!/)     # if *, then not followed by /
                  | \/(?!\*)    # if /, then not followed by *
                )+
            }x
               { $item[1] }

      rest_of_SQL_code  : 
                  m{([^\"/'\-\[]+   # one or more non-delimiters 
                       (            # then (optionally)...
                          /[^*]     # not an actual comment opener
                        |           # or
                          -[^\-]
                       )?           # 
                     )+             # all repeated once or more
                    }x
                    { $sqlRef->{code} .= $item[1] }

      string  : m{\'(([^\'] | \'\')*)\'}x
                { ++$cnt; 
                  $sqlRef->{code} .= "\'" . $SQLDBA::ParseSQL::seed . $cnt . "\'"; 
                  $sqlRef->{strings}->{$SQLDBA::ParseSQL::seed . $cnt} = $1; #item[1]; 
                }

      double_identifier  : 
         m{\" (([^\"] | \"\")+) \" }x
             { ++$cnt; 
               $sqlRef->{code} .= $SQLDBA::ParseSQL::seed . $cnt; 
               $sqlRef->{double_ids}->{$SQLDBA::ParseSQL::seed . $cnt} = $1; #$item[1]; 
             }

      bracket_identifier : 
         m{ \[ (([^\]] | \]\])+) \] }x                                                                 
             { ++$cnt; 
               $sqlRef->{code} .= $SQLDBA::ParseSQL::seed . $cnt; 
               $sqlRef->{bracket_ids}->{$SQLDBA::ParseSQL::seed . $cnt} = $1; # $item[1]; 
             }
SQLGRAMMAR

   ($seed, $opt) = ($tokenSeed, $option);
   my $parser = new Parse::RecDescent $Grammar  or  
         croak "***Err: invalid TSQL grammar.";
   my $sqlRef = $parser->program($script) 
      or carp "***Err: malformed TSQL script.";
   
   return $sqlRef;
} # dbaNormalizeSQL

#####################
sub dbaSplitBatch {
#####################
  my ($sql) = shift or croak "***Err: dbaSplitBatch() expects a string.";
  
  $sql =~ s/^\s*\n//;
  $sql =~ s/\n\s*go\s*\n/\ngo\n/isg;
  $sql =~ s/\n\s*go\s+/\ngo\n/isg;
  $sql =~ s/\n+/\n/sg;
  
  my @batches = split(/\ngo\n/i, $sql);

  \@batches;  
} # dbaSplitBatch

######################
sub dbaRestoreSQL {
######################
   my $sqlRef = shift or 
      croak "***Err: dbaRestoreSQL() expects a reference.";

   foreach my $id (keys %{$sqlRef->{double_ids}}) {
      $sqlRef->{code} =~ s/\b$id\b/\"$sqlRef->{double_ids}->{$id}\"/i;
   }
   foreach my $id (keys %{$sqlRef->{bracket_ids}}) {
      $sqlRef->{code} =~ s/\b$id\b/\[$sqlRef->{bracket_ids}->{$id}\]/i;
   }
   foreach my $id (keys %{$sqlRef->{comments}}) {
      $sqlRef->{code} =~ s/\b$id\b/$sqlRef->{comments}->{$id}/i;
   }
   foreach my $id (keys %{$sqlRef->{strings}}) {
      $sqlRef->{code} =~ s/\b$id\b/$sqlRef->{strings}->{$id}/i;
   }
   return $sqlRef;
} # dbaRestoreSQL

######################
sub dbaParseQDON {
######################
   my $name = shift or croak "***Err: dbaParseQDON() expects a string.";
   my $obj = q/  [\w@#]+ 
                | \" (?: [^\"]|\"\")+ \" 
                | \[ (?: [^\]]|\]\])+ \]
              /;
   my $re = qr{   ($obj)\.($obj)?\.($obj)
                | (?:($obj)\.)?($obj)
             }ix;
   my $ref;
   if ($name =~ /^\s*$re\s*$/ix) {
      $ref = {
         db => $1,
         owner => (defined $2 ? $2 : $4),
         obj => (defined $3 ? $3 : $5)
      };
   }
   return $ref;
} # dbaParseQDON


1;

package SQLDBA::Security;

use strict;
use Win32::Lanman;
use Win32::ODBC;
use Win32::Perms;
use Carp;

use vars qw(@ISA @EXPORT $VERSION @EXPORT_OK);

use Exporter;
$VERSION=1.00;
@ISA = ('Exporter');
@EXPORT_OK = qw(

    &dbaGetServiceAccount
    &dbaGetLoginConfig
    &dbaGetSysadminMembers
    &dbaGetShares
    &dbaGetSQLRegistryPerms
);

#################################
sub dbaGetServiceAccount {
#################################
   my ($server, $service) = @_;
   
   my %srvConfig;
   if(!Win32::Lanman::QueryServiceConfig("\\\\$server", '', 
                                         $service,\%srvConfig)) {
      carp "***Err: Lanman::QueryServiceConfig encountered an error for " .
                   "$server and $service. " . Win32::Lanman::GetLastError();
      return;
   }
   $srvConfig{'account'} =~ s/\.\\/$server\\/;
   return $srvConfig{'account'};
} # dbaGetServiceAccount

#################################
sub dbaGetLoginConfig {
#################################
    my ($instance, $name) = @_;

    my $conn = "Driver={SQL Server};Server=$instance;" .
                  "Trusted_Connection=Yes;Database=master";
    my $db = new Win32::ODBC ($conn) or
        do { carp "***Err: failed to connect to $instance. ", 
                        Win32::ODBC::Error();
             return;
           };

    my $sql = "EXEC master..xp_loginconfig '" . $name . "'";
    my $config_value;
    if ($db->Sql( $sql )) {
       carp "***Err: could not execute $sql. ", Win32::ODBC::Error();
    }
    else {
        while ($db->FetchRow()) {
            ($name, $config_value) = $db->Data;
        }
    }
    return $config_value;
} # dbaGetLoginConfig

#################################
sub dbaGetSysadminMembers {
#################################
   my $instance = shift 
       or croak "***Err: dbaGetSysadminMembers() expects an instance.";

   my $conn = "Driver={SQL Server};Server=$instance;"  . 
                  "Trusted_Connection=Yes;Database=master";
   my $db = new Win32::ODBC ($conn) or 
        do { carp "***Err: failed to connect to $instance. ", 
                        Win32::ODBC::Error();
             return;
           };
  
   # get sysadmin members
   my @members = ();
   my $sql = q/SELECT loginname FROM master.dbo.syslogins
                       WHERE sysadmin = 1/;

   if (! $db->Sql( $sql )) {
       while ($db->FetchRow()) { @members = (@members, $db->Data); }
   } else {
       carp "***Err: problem executing $sql. ", Win32::ODBC::Error(); 
   }
   $db->Close();
   
   return \@members;
} # dbaGetSysadminMembers

#################################
sub dbaGetShares {
#################################
   my ($server) = shift or croak "***Err: dbaGetShares() expects a server name.";

   my @shares;
   Win32::Lanman::NetShareEnum($server, \@shares) or
        do { carp Win32::FormatMessage(Win32::Lanman::GetLastError());
               return;
         };
   my $shareRef;
   foreach my $share (@shares) {
      push @{$shareRef}, $share->{netname};
   }
   return $shareRef;
} # dbaGetShares


#################################
sub dbaGetSQLRegistryPerms {
#################################
   my ($server, $instance) = @_;
   my ($sqlPermRef, @aceList);

   my $key;
   if ($instance =~ /^MSSQLServer$/i) {
      $key = 'Reg://' . $server . 
                  '/HKEY_LOCAL_MACHINE\Software\Microsoft\MSSQLServer';
   }
   else {
       $key = 'Reg://' . $server . 
                   '/HKEY_LOCAL_MACHINE\Software\Microsoft\Microsoft SQL Server' .
                   "\\$instance";
   }
   
   my $perm = new Win32::Perms($key);
   if( $perm->Dump( \@aceList ) ) {
      my ($ace, @access, @M);

      foreach $ace ( @aceList ) {
         next if $ace->{'Entry'} =~ /^Owner$/i;
         next if $ace->{Account} eq '';
         DecodeMask( $ace, \@M, \@access );
         my $acct = $ace->{Domain} . "\\" . $ace->{Account};
         push @{$sqlPermRef->{$acct}}, @access if @access;
      }
   }
   return $sqlPermRef;
} # dbaGetSQLRegistryPerms


1;

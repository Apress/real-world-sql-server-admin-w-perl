package SQLDBA::SQLDMO;

use strict;
use Carp;
use Win32::OLE 'in';
use Win32::OLE::Const 'Microsoft SQLDMO';

use vars qw(@ISA @EXPORT $VERSION @EXPORT_OK);

use Exporter;
$VERSION=1.00;
@ISA = ('Exporter');
@EXPORT_OK = qw(

    &dbaScriptLoginsUsers 
    &dbaGetTableColumns 
    &dbaGetTableIndexes
    &dbaGetIndexInfo
    &dbaScriptSP
    &dbaGetTableConstraints 
    &dbaGetKeyConstraints 

    &dbaScriptSP2
    &dbaGetReferencedTables
);

#################################
sub dbaScriptLoginsUsers {
#################################
   my ($serverName, $dbNames, $fileName) = @_;
   (defined $serverName && defined $fileName) 
      or croak "***Err: dbaScriptLoginsUsers() expects a server name and a script file name.\n";
   
   my $server;
   $server = Win32::OLE->new('SQLDMO.SQLServer')
        or croak "**Err: Could not create SQLDMO.SQLServer object.";
   $server->{LoginSecure} = 1;

   $server->connect($serverName, '', '');
   if (Win32::OLE->LastError()) {
       croak "***Err: Could not connect to $serverName.";
   }

   my $logins = $server->Logins();
   if (Win32::OLE->LastError()) {
       croak "***Err: could not get the logins in $serverName.";
   }

   foreach my $login (in($logins)) {
      $login->Script(SQLDMOScript_Default | SQLDMOScript_AppendToFile | 
                     SQLDMOScript_Drops | SQLDMOScript_ToFileOnly |
                     SQLDMOScript_IncludeHeaders,
                     $fileName);
   }

   if (defined $dbNames) {
      foreach my $dbName (split /\s*,\s*/, $dbNames) {
         my $users = $server->Databases($dbName)->Users();
         if (Win32::OLE->LastError()) {
             croak "***Err: could not get the users in $dbName.";
         }
         
         open(SQL, ">>$fileName") or croak "***Err: could not append to $fileName.\n";
         print SQL "\n/****** Database:  $dbName ******/\n\n";
         close(SQL);
         foreach my $user (in($users)) {
            $user->Script(SQLDMOScript_Default | SQLDMOScript_AppendToFile | 
                          SQLDMOScript_Drops  | SQLDMOScript_ToFileOnly |
                          SQLDMOScript_IncludeHeaders,
                          $fileName);
         }
      }
   }
   $server->disconnect();
   $server->DESTROY();
} # dbaScriptLoginsUsers

##########################
sub dbaGetTableColumns {
##########################
   my $ref = shift or croak "***Err: dbaGetTableColumns() expects a reference.";
   
   my $server = Win32::OLE->new('SQLDMO.SQLServer')
     or croak "***Err: Could not create SQLDMO object.";
   $server->{LoginSecure} = 1;

   $server->connect($ref->{srvName}, '', '');
   ! Win32::OLE->LastError() or
       croak "***Err: Could not connect to $ref->{srvName}.";

   my $table = $server->Databases($ref->{dbName})->Tables($ref->{tbName});
   ! Win32::OLE->LastError() or
       croak "***Err: could not get the table object.";
   
   my $colRef;
   foreach my $col (in($table->Columns())) {  # enumerate columns
      $colRef->{$col->{Name}} = {             # record column properties
         Position          => $col->{ID},
         AllowNulls        => $col->{AllowNulls},
         AnsiPaddingStatus => $col->{AnsiPaddingStatus},
         Collation         => $col->{Collation},
         ComputedText      => $col->{ComputedText},
         DataType          => $col->{DataType},
         Identity          => $col->{Identity},
         InPrimaryKey      => $col->{InPrimaryKey},
         Length            => $col->{Length},
         NumericPrecision  => $col->{NumericPrecision},
         NumericScale      => $col->{NumericScale},
         PhysicalDatatype  => $col->{PhysicalDatatype},
      };
   }
   $server->disconnect();
   $server->DESTROY();
   return $colRef;
} # dbaGetTableColumns 

##########################
sub dbaGetTableIndexes {
##########################
   my $ref = shift or croak "***Err: dbaGetTableIndexes() expects a reference.";
   
   my $server = Win32::OLE->new('SQLDMO.SQLServer')
     or croak "***Err: Could not create SQLDMO object.";
   $server->{LoginSecure} = 1;

   $server->connect($ref->{srvName}, '', '');
   ! Win32::OLE->LastError() or
       croak "***Err: Could not connect to $ref->{srvName}.";
   
   my $table = $server->Databases($ref->{dbName})->Tables($ref->{tbName});
   ! Win32::OLE->LastError() or
       croak "***Err: could not get the table object.";
   
   my $idxRef;
   foreach my $idx (in($table->Indexes())) {
      next if $idx->{Type} & SQLDMOIndex_Hypothetical;

      my @cols;
      foreach my $col (in($idx->ListIndexedColumns())) {
         push @cols, $col->{Name}
      }
      $idxRef->{$idx->Name()} = {
         IndexedColumns => join(',', @cols),
         FillFactor     => $idx->FillFactor(),
         FileGroup      => $idx->FileGroup(),
         Clustered => ($idx->{Type} & SQLDMOIndex_Clustered) ? 'yes' : 'no',
         IgnoreDupKey => ($idx->{Type} & SQLDMOIndex_IgnoreDupKey) ? 'yes' : 'no',
         NoRecompute => ($idx->{Type} & SQLDMOIndex_NoRecompute) ? 'yes' : 'no',
         PadIndex => ($idx->{Type} & SQLDMOIndex_PadIndex) ? 'yes' : 'no',
         PrimaryKey => ($idx->{Type} & SQLDMOIndex_DRIPrimaryKey) ? 'yes' : 'no',
         Unique => ($idx->{Type} & SQLDMOIndex_Unique) ? 'yes' : 'no',
         UniqueKey => ($idx->{Type} & SQLDMOIndex_DRIUniqueKey) ? 'yes' : 'no',
      };
   }

   $server->disconnect();
   $server->DESTROY();
   return $idxRef;
} # dbaGetTableIndexes

##########################
sub dbaGetIndexInfo {
##########################
   my $ref = shift or croak "***Err: dbaGetIndexInfo() expects a reference.";
   my $idxRef;

   my $server = Win32::OLE->new('SQLDMO.SQLServer')
     or croak "***Err: Could not create SQLDMO object.";
   $server->{LoginSecure} = 1;

   $server->connect($ref->{srvName}, '', '');
   ! Win32::OLE->LastError() or
       croak "***Err: Could not connect to $ref->{srvName}.";
   
   my $table = $server->Databases($ref->{dbName})->Tables($ref->{tbName});
   ! Win32::OLE->LastError() or
       croak "***Err: could not get the table object.";

   my @indexes;
   foreach my $idx (in($table->Indexes())) {
        push @indexes, $idx->{Name};
   }
   return $idxRef unless grep /$ref->{idxName}/, @indexes; # exit if can't find the index

   my $idx = $table->Indexes($ref->{idxName});
   ! Win32::OLE->LastError() or
       croak "***Err: could not get the index object.";

   my @cols;
   foreach my $col (in($idx->ListIndexedColumns())) {
      push @cols, $col->{Name}
   }
   $idxRef = {
      IndexedColumns => join(',', @cols),
      FillFactor     => $idx->FillFactor(),
      FileGroup      => $idx->FileGroup(),
      Type           => $idx->{Type},
      Clustered => ($idx->{Type} & SQLDMOIndex_Clustered) ? 'yes' : 'no',
      IgnoreDupKey => ($idx->{Type} & SQLDMOIndex_IgnoreDupKey) ? 'yes' : 'no',
      NoRecompute => ($idx->{Type} & SQLDMOIndex_NoRecompute) ? 'yes' : 'no',
      PadIndex => ($idx->{Type} & SQLDMOIndex_PadIndex) ? 'yes' : 'no',
      PrimaryKey => ($idx->{Type} & SQLDMOIndex_DRIPrimaryKey) ? 'yes' : 'no',
      Unique => ($idx->{Type} & SQLDMOIndex_Unique) ? 'yes' : 'no',
      UniqueKey => ($idx->{Type} & SQLDMOIndex_DRIUniqueKey) ? 'yes' : 'no',
   };

   $server->disconnect();
   $server->DESTROY();
   return $idxRef;
} # dbaGetIndexInfo

###############################
sub dbaGetTableConstraints {
###############################
   my $ref = shift or croak "***Err: dbaGetTableConstraints() expects a reference.";
   
   my $server = Win32::OLE->new('SQLDMO.SQLServer')
     or croak "***Err: Could not create SQLDMO object.";
   $server->{LoginSecure} = 1;

   $server->connect($ref->{srvName}, '', '');
   ! Win32::OLE->LastError() or
       croak "***Err: Could not connect to $ref->{srvName}.";
   
   my $table = $server->Databases($ref->{dbName})->Tables($ref->{tbName});
   ! Win32::OLE->LastError() or
       croak "***Err: could not get the table object.";

   my $cRef;
   
   # Get info on PKs, FKs, UNIQUEs (key constraints)
   foreach my $key (in($table->Keys())) {
      my @keyCols;
      for(my $i = 1; $i <= $key->KeyColumns()->Count(); $i++) {
         push @keyCols, $key->KeyColumns($i);
      }

      my @refKeyCols;
      for(my $i = 1; $i <= $key->ReferencedColumns()->Count(); $i++) {
         push @refKeyCols, $key->ReferencedColumns($i);
      }

      my $id = join(',', @keyCols) . '/' . $key->{ReferencedTable} . '/';
      $id .= join(',', @refKeyCols) . '/';
      $id .= $key->{Type} & SQLDMOKey_Unique ? 'yes' : 'no';

      $cRef->{Keys}->{$id} = {
         Name => $key->{Name},
         KeyColumns => join(',', @keyCols),
         ReferencedKeyColumns => join(',', @refKeyCols),
         ReferencedTable => $key->{ReferencedTable},
         Checked => $key->{Checked},
         ExcludeReplication => $key->{ExcludeReplication},
         Foreign => ($key->{Type} == SQLDMOKey_Foreign) ? 'yes' : 'no',
         Primary => ($key->{Type} == SQLDMOKey_Primary) ? 'yes' : 'no',
         Unique => ($key->{Type} == SQLDMOKey_Unique) ? 'yes' : 'no',
      };
   }
   
   # Get info on DEFAULT constraints
   foreach my $col (in($table->Columns())) {
      if ($col->DRIDefault()->{Name}) {
         $cRef->{Defaults}->{$col->{Name}}->{Expression} = $col->DRIDefault()->Text();
      }
   }

   # Get CHECK constraints
   foreach my $check (in($table->Checks())) {
      $cRef->{Checks}->{$check->Text()} = {
         Checked => $check->{Checked},
         ExcludeReplication => $check->{ExcludeReplication},
      };
   }

   $server->disconnect();
   $server->DESTROY();
   return $cRef;
} # dbaGetTableConstraints

#########################
sub dbaGetKeyConstraints {
   my $ref = shift or die "***Err: getKeyConstraints() expects a reference.";
   
   my $server = Win32::OLE->new('SQLDMO.SQLServer')
     or die "***Err: Could not create SQLDMO object.";
   $server->{LoginSecure} = 1;

   $server->connect($ref->{srvName}, '', '');
   ! Win32::OLE->LastError() or
       die "***Err: Could not connect to $ref->{srvName}.";
   
   my $table = $server->Databases($ref->{dbName})->Tables($ref->{tbName});
   ! Win32::OLE->LastError() or
       die "***Err: could not get the table object.";

   my $cRef;
   
   # Get info on PKs, FKs, UNIQUEs (key constraints)
   foreach my $key (in($table->Keys())) {
      # construct a string of referencing columns
      my @keyCols;
      for(my $i = 1; $i <= $key->KeyColumns()->Count(); $i++) {
         push @keyCols, $key->KeyColumns($i);
      }

      # construct a string of referenced columns
      my @refKeyCols;
      for(my $i = 1; $i <= $key->ReferencedColumns()->Count(); $i++) {
         push @refKeyCols, $key->ReferencedColumns($i);
      }

      # construct the key id
      my $id = join(',', @keyCols) . '/' . $key->{ReferencedTable} . '/';
      $id .= join(',', @refKeyCols) . '/';
      $id .= $key->{Type} & SQLDMOKey_Unique ? 'yes' : 'no';

      $cRef->{$key->{Name}} = {
         ID   => $id,
         Name => $key->{Name},
         KeyColumns => join(',', @keyCols),
         ReferencedKeyColumns => join(',', @refKeyCols),
         ReferencedTable => $key->{ReferencedTable},
         Checked => $key->{Checked},
         ExcludeReplication => $key->{ExcludeReplication},
         Foreign => ($key->{Type} == SQLDMOKey_Foreign) ? 'yes' : 'no',
         Primary => ($key->{Type} == SQLDMOKey_Primary) ? 'yes' : 'no',
         Unique => ($key->{Type} == SQLDMOKey_Unique) ? 'yes' : 'no',
      };
   }
   return $cRef;
} # dbaGetKeyConstraints

##################
sub dbaScriptSP {
##################
   my $ref = shift or croak "***Err: dbaScriptSP() expects a reference.";
   
   my $server = Win32::OLE->new('SQLDMO.SQLServer')
     or croak "***Err: Could not create SQLDMO object.";
   $server->{LoginSecure} = 1;

   $server->connect($ref->{srvName}, '', '');
   ! Win32::OLE->LastError() or
       croak "***Err: Could not connect to $ref->{srvName}.";
   
   my $spName = $ref->{spName};
   my $sp = $server->Databases($ref->{dbName})->StoredProcedures($spName);
   ! Win32::OLE->LastError() or
       croak "***Err: could not get the table object.";
   
   my $spRef = {
        Owner  => $sp->{Owner},
        Startup  => $sp->{Startup},
        AnsiNullsStatus => $sp->{AnsiNullsStatus},
        QuotedIdentifierStatus => $sp->{QuotedIdentifierStatus},
        Script   => $sp->Script( SQLDMOScript_Default )
   };
   # remove settings in the code that are already captured in the hash
   $spRef->{Script} =~ s/set\s+quoted_identifier\s+(on|off)\s+go\s*//ig;
   $spRef->{Script} =~ s/set\s+ansi_nulls\s+(on|off)\s+go\s*//ig;

   $server->disconnect();
   $server->DESTROY();
   return $spRef;
} # dbaScriptSP

##################
sub dbaScriptSP2 {
##################
   my $ref = shift or croak "***Err: dbaScriptSP2() expects a reference.";

   my ($server, $dbName, $spName) = ( $ref->{srvObj},
                                      $ref->{dbName},
                                      $ref->{spName} );
   my $sp = $server->Databases($ref->{dbName})->StoredProcedures($spName);
   ! Win32::OLE->LastError() or
       do { carp "***Err: could not get the proc object for $spName.";
            return undef;
          };
   
   my $spRef = {
      Owner  => $sp->{Owner},
      Startup  => $sp->{Startup},
      AnsiNullsStatus => $sp->{AnsiNullsStatus},
      QuotedIdentifierStatus => $sp->{QuotedIdentifierStatus},
      Script   => $sp->Script( SQLDMOScript_Default )
   };
   # remove settings in the code that are already captured in the hash
   $spRef->{Script} =~ s/set\s+quoted_identifier\s+(on|off)\s+go\s*//ig;
   $spRef->{Script} =~ s/set\s+ansi_nulls\s+(on|off)\s+go\s*//ig;

   return $spRef;
} # dbaScriptSP2

##############################
sub dbaGetReferencedTables {
##############################
   my $ref = shift or croak "***Err: dbaGetReferencedTables() expects a reference.";
   
   my $server = Win32::OLE->new('SQLDMO.SQLServer')
     or croak "***Err: Could not create SQLDMO object.";
   $server->{LoginSecure} = 1;

   $server->connect($ref->{srvName}, '', '');
   ! Win32::OLE->LastError() or
       croak "***Err: Could not connect to $ref->{srvName}.";
   
   my $table = $server->Databases($ref->{dbName})->Tables($ref->{tbName});
   ! Win32::OLE->LastError() or
       croak "***Err: could not get the table object.";

   # Get referenced tables
   my @refTables;
   foreach my $key (in($table->Keys())) {
      push @refTables, $key->{ReferencedTable} if $key->{ReferencedTable};
   }
   
   $server->disconnect();
   return \@refTables;
} # dbaGetReferencedTables

1;

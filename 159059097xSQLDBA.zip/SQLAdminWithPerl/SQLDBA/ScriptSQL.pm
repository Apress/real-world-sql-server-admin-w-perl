package SQLDBA::ScriptSQL;

use strict;
use Win32::OLE 'in';
use Win32::OLE::Const 'Microsoft SQLDMO';
use Carp;

use vars qw(@ISA @EXPORT $VERSION @EXPORT_OK);

use Exporter;
$VERSION=1.00;
@ISA = ('Exporter');
@EXPORT_OK = qw(

    &dbaScriptLoginsUsers 

    &dbaScriptCreateTable
    &dbaScriptConversion
);

#################################
sub dbaScriptLoginsUsers {
#################################
   my ($serverName, $dbNames, $fileName) = @_;
   (defined $serverName && defined $fileName) 
      or croak "***Err: dbaScriptLoginsUsers() expects a server name and a script file name.\n";
   
   my $server;
   $server = Win32::OLE->new('SQLDMO.SQLServer')
        or croak "**Err: Could not create SQLDMO.SQLServer object.";
   $server->{LoginSecure} = 1;

   $server->connect($serverName, '', '');
   if (Win32::OLE->LastError()) {
       croak "***Err: Could not connect to $serverName.";
   }

   my $logins = $server->Logins();
   if (Win32::OLE->LastError()) {
       croak "***Err: could not get the logins in $serverName.";
   }

   foreach my $login (in($logins)) {
      $login->Script(SQLDMOScript_Default | SQLDMOScript_AppendToFile | 
                     SQLDMOScript_Drops | SQLDMOScript_ToFileOnly |
                     SQLDMOScript_IncludeHeaders,
                     $fileName);
   }

   if (defined $dbNames) {
      foreach my $dbName (split /\s*,\s*/, $dbNames) {
         my $users = $server->Databases($dbName)->Users();
         if (Win32::OLE->LastError()) {
             croak "***Err: could not get the users in $dbName.";
         }
         
         open(SQL, ">>$fileName") or croak "***Err: could not append to $fileName.\n";
         print SQL "\n/****** Database:  $dbName ******/\n\n";
         close(SQL);
         foreach my $user (in($users)) {
            $user->Script(SQLDMOScript_Default | SQLDMOScript_AppendToFile | 
                          SQLDMOScript_Drops  | SQLDMOScript_ToFileOnly |
                          SQLDMOScript_IncludeHeaders,
                          $fileName);
         }
      }
   }
   $server->disconnect();
   $server->DESTROY();
} # dbaScriptLoginsUsers

#################################
sub dbaScriptCreateTable {
#################################
   my $tbRef = shift;
   unless (ref($tbRef)) {
      croak "***Err: dbaScriptCreateTable() expects a reference.\n";
   }
   my $tbName = $tbRef->{TableName} or croak "**Err: cannot find the table name.\n";
   my $sql = "CREATE TABLE $tbName (\n";
   
   foreach my $column (sort {$tbRef->{Columns}->{$a}->{colid}
                             <=>
                             $tbRef->{Columns}->{$b}->{colid}
                            } keys %{$tbRef->{Columns}}) {
      $sql .= "   $column " . $tbRef->{Columns}->{$column}->{type};
      if ($tbRef->{Columns}->{$column}->{type} =~ /^( char|varchar|binary|varbinary
                                                     |nchar|nvarchar)/ix) {
         $sql .= " ( $tbRef->{Columns}->{$column}->{length} ) ";
      }                                                     
      if ($tbRef->{Columns}->{$column}->{type} =~ /^( decimal|numeric)/ix) {
         $sql .= " ( " . $tbRef->{Columns}->{$column}->{prec} . ", " . 
                         $tbRef->{Columns}->{$column}->{scale} . 
                 " ) ";
      }      
      $sql .= $tbRef->{Columns}->{$column}->{nullable} =~ /yes/i ? 
                  " NULL" : " NOT NULL";
      if (exists $tbRef->{Identity}) {
         if ($tbRef->{Identity}->{column} eq $column) {
            $sql .= " IDENTITY (" . $tbRef->{Identity}->{seed} . ", " .
                                 $tbRef->{Identity}->{increment} . ") ";
            if ($tbRef->{Identity}->{not_for_replication}) {
               $sql .= " NOT FOR REPLICATION";
            }
         }
      }
      $sql .= ",\n";
   }
   $sql .= ")\n";
   return $sql;
} # dbaScriptCreateTable

#################################
sub dbaScriptConversion {
#################################
   my ($newRef, $oldRef) = @_;
   unless (ref($newRef) && ref($oldRef)) {
      croak "***Err: dbaScriptConversion() expects two references.\n";
   }

   my $newTB = $newRef->{TableName};
   my $oldTB = $oldRef->{TableName};
   
   my $sql = dbaScriptCreateTable($newRef);
   $sql .= "GO\n";

   if (exists $newRef->{Identity}) {
      $sql .= "SET IDENTITY_INSERT $newTB ON\nGO\n";
   }
   $sql .= "IF EXISTS (SELECT * FROM $oldTB)\n";
   $sql .= "    INSERT INTO $newTB (\n";

   # order the columns by colid
   my @newColumns = (sort { $newRef->{Columns}->{$a}->{colid}
                            <=>
                            $newRef->{Columns}->{$b}->{colid}
                          } keys %{$newRef->{Columns}});
   
   # construct column list for INSERT
   $sql .= "\t" . join(",\n\t", @newColumns) . "\n";
   $sql .= "    )\n";

   # now for each column in the new table, decide how to 
   # include the column on the SELECT list
   my $column = shift @newColumns;
   $sql .= "    SELECT " . (exists($oldRef->{Columns}->{$column}) ? 
                              $column : '?');
   foreach $column (@newColumns) {
      $sql .= ",\n           " . (exists($oldRef->{Columns}->{$column}) ? 
                                   $column : '?');
   }
   $sql .= "\n      FROM $oldTB\nGO\n";
   if (exists $newRef->{Identity}) {
      $sql .= "SET IDENTITY_INSERT $newTB OFF\nGO\n";
   }
   $sql .= "DROP TABLE $oldTB\nGO\n";
   return $sql;
} # dbaScriptConversion

1;
